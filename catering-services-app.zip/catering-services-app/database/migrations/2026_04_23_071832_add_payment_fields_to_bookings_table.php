<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('bookings', function (Blueprint $table) {
            $table->decimal('total_amount', 10, 2)->nullable()->after('status');
            $table->decimal('advance_amount', 10, 2)->nullable()->after('total_amount');
            $table->string('payment_status', 50)->default('pending')->after('advance_amount'); 
            $table->string('payment_method', 50)->default('none')->after('payment_status');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('bookings', function (Blueprint $table) {
            $table->dropColumn(['total_amount', 'advance_amount', 'payment_status', 'payment_method']);
        });
    }
};
