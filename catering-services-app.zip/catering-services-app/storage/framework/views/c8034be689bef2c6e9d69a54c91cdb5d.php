<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Catering Services'); ?> - <?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600|playfair-display:900italic,900" rel="stylesheet" />

    <!-- Alpine.js -->
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

    <!-- Styles / Scripts -->
    <?php if(file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot'))): ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/css/custom.css', 'resources/js/app.js']); ?>
    <?php else: ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
        <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <?php endif; ?>
</head>
<body class="antialiased">
    <div class="min-h-screen flex flex-col">
        <!-- Navigation -->
        <header class="main-header">
            <!-- Top Branding Bar -->
            <div class="header-top">
                <div class="header-inner container">
                    <div class="branding-group">
                        
                            <span class="logo-text">A.V Caterers</span>
                            <div class="logo-ribbon">
                                <span>Established in 2026</span>
                            </div>
                        
                        <p class="tagline">Choose A.V For A Catering!</p>
                    </div>

                    

                    <div class="mascot-container">
                        <!-- Mascot placeholder - using high quality icon/image -->
                        <div class="chef-mascot">
                            <img src="<?php echo e(asset('images/A.V logo.webp')); ?>" alt="A.V Chef" style="height: 40px;">
                        </div>
                    </div>
                </div>
            </div>

            <!-- Main Navigation Bar -->
            <div class="header-main">
                <div class="header-inner container">
                    <nav class="nav-links">
                        <a href="<?php echo e(url('/')); ?>" class="nav-link">Home</a>
                        <a href="<?php echo e(url('/menu')); ?>" class="nav-link">Menu</a>
                        <a href="<?php echo e(url('/services')); ?>" class="nav-link">Services</a>
                        <a href="<?php echo e(url('/gallery')); ?>" class="nav-link">Gallery</a>
                        <a href="<?php echo e(url('/about')); ?>" class="nav-link">About Us</a>
                        <a href="<?php echo e(url('/package')); ?>" class="nav-link">Packages</a>
                        <a href="<?php echo e(url('/contact')); ?>" class="nav-link">Contact</a>
                        <a href="<?php echo e(route('bookings.create')); ?>" class="btn-primary-sm" style="background: var(--gala-blue); margin-left: 1rem;">Book Now</a>
                    </nav>

                    <div class="auth-links">
                        <?php if(auth()->guard()->check()): ?>
                            <?php if(auth()->user()->is_admin): ?>
                                <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-link admin-link">Admin</a>
                            <?php endif; ?>
                            <a href="<?php echo e(url('/calendar')); ?>" class="nav-link">Calendar</a>
                            <a href="<?php echo e(route('dashboard')); ?>" class="btn-primary-sm">Portal</a>
                            <form action="<?php echo e(route('logout')); ?>" method="POST" class="inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="nav-link logout-btn">Logout</button>
                            </form>
                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>" class="login-btn">Login</a>
                            <a href="<?php echo e(route('register')); ?>" class="btn-primary-sm">Register</a>
                        <?php endif; ?>
                    </div>
            </div>
        </header>

        <!-- Page Content -->
        <main class="flex-grow">
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <!-- Footer -->
        <footer class="main-footer">
            <div class="container">
                <div class="footer-grid">
                    <div class="footer-section">
                        <span class="footer-logo">A.V CATERING</span>
                        <p class="footer-tagline">
                            Exquisite flavors and professional service for your most memorable moments.
                        </p>
                    </div>
                    <div class="footer-section">
                        <h3 class="footer-heading">Quick Links</h3>
                        <ul class="footer-links">
                            <li><a href="<?php echo e(url('/menu')); ?>">Menu</a></li>
                            <li><a href="<?php echo e(url('/services')); ?>">Services</a></li>
                            <li><a href="<?php echo e(url('/gallery')); ?>">Gallery</a></li>
                        </ul>
                    </div>
                    <div class="footer-section">
                        <h3 class="footer-heading">Connect</h3>
                        <ul class="footer-links">
                            <li><a href="#">Instagram</a></li>
                            <li><a href="#">Facebook</a></li>
                            <li><a href="<?php echo e(url('/contact')); ?>">Contact Us</a></li>
                        </ul>
                    </div>
                </div>
                <div class="footer-bottom">
                    &copy; <?php echo e(date('Y')); ?> Catering Services App. All rights reserved.
                </div>
            </div>
        </footer>
    </div>

    <!-- Success Notification Popup -->
    <?php if(session('success')): ?>
    <div x-data="{ show: true }" 
         x-show="show" 
         x-init="setTimeout(() => show = false, 5000)"
         x-transition:enter="notification-enter"
         x-transition:enter-start="notification-enter-start"
         x-transition:enter-end="notification-enter-end"
         x-transition:leave="notification-leave"
         x-transition:leave-start="notification-leave-start"
         x-transition:leave-end="notification-leave-end"
         class="success-popup"
         style="display: none;">
        <div class="success-popup-content">
            <div class="success-icon">✓</div>
            <div class="success-message">
                <h4>Success!</h4>
                <p><?php echo e(session('success')); ?></p>
            </div>
            <button @click="show = false" class="success-close">&times;</button>
        </div>
        <div class="success-progress"></div>
    </div>
    <?php endif; ?>

    <script>
        // Reveal animation on scroll
        function reveal() {
            var reveals = document.querySelectorAll(".reveal");
            for (var i = 0; i < reveals.length; i++) {
                var windowHeight = window.innerHeight;
                var elementTop = reveals[i].getBoundingClientRect().top;
                var elementVisible = 150;
                if (elementTop < windowHeight - elementVisible) {
                    reveals[i].classList.add("active");
                }
            }
        }
        window.addEventListener("scroll", reveal);
        window.addEventListener("load", reveal);
    </script>
</body>
</html>

                </div><?php /**PATH D:\project\catering-services-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>