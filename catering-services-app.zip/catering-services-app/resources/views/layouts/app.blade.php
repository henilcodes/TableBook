<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'Catering Services') - {{ config('app.name', 'Laravel') }}</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600|playfair-display:900italic,900" rel="stylesheet" />

    <!-- Alpine.js -->
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

    <!-- Styles / Scripts -->
    @if (file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot')))
        @vite(['resources/css/app.css', 'resources/css/custom.css', 'resources/js/app.js'])
    @else
        <link rel="stylesheet" href="{{ asset('css/style.css') }}">
        <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    @endif
</head>
<body class="antialiased">
    <div class="min-h-screen flex flex-col">
        <!-- Navigation -->
        <header class="main-header">
            <!-- Top Branding Bar -->
            <div class="header-top">
                <div class="header-inner container">
                    <div class="branding-group">
                        
                            <span class="logo-text">A.V Caterers</span>
                            <div class="logo-ribbon">
                                <span>Established in 2026</span>
                            </div>
                        
                        <p class="tagline">Choose A.V For A Catering!</p>
                    </div>

                    

                    <div class="mascot-container">
                        <!-- Mascot placeholder - using high quality icon/image -->
                        <div class="chef-mascot">
                            <img src="{{asset('images/A.V logo.webp')}}" alt="A.V Chef" style="height: 40px;">
                        </div>
                    </div>
                </div>
            </div>

            <!-- Main Navigation Bar -->
            <div class="header-main">
                <div class="header-inner container">
                    <nav class="nav-links">
                        <a href="{{ url('/') }}" class="nav-link">Home</a>
                        <a href="{{ url('/menu') }}" class="nav-link">Menu</a>
                        <a href="{{ url('/services') }}" class="nav-link">Services</a>
                        <a href="{{ url('/gallery') }}" class="nav-link">Gallery</a>
                        <a href="{{ url('/about') }}" class="nav-link">About Us</a>
                        <a href="{{ url('/package') }}" class="nav-link">Packages</a>
                        <a href="{{ url('/contact') }}" class="nav-link">Contact</a>
                        <a href="{{ route('bookings.create') }}" class="btn-primary-sm" style="background: var(--gala-blue); margin-left: 1rem;">Book Now</a>
                    </nav>

                    <div class="auth-links">
                        @auth
                            @if(auth()->user()->is_admin)
                                <a href="{{ route('admin.dashboard') }}" class="nav-link admin-link">Admin</a>
                            @endif
                            <a href="{{ url('/calendar') }}" class="nav-link">Calendar</a>
                            <a href="{{ route('dashboard') }}" class="btn-primary-sm">Portal</a>
                            <form action="{{ route('logout') }}" method="POST" class="inline">
                                @csrf
                                <button type="submit" class="nav-link logout-btn">Logout</button>
                            </form>
                        @else
                            <a href="{{ route('login') }}" class="login-btn">Login</a>
                            <a href="{{ route('register') }}" class="btn-primary-sm">Register</a>
                        @endauth
                    </div>
            </div>
        </header>

        <!-- Page Content -->
        <main class="flex-grow">
            @yield('content')
        </main>

        <!-- Footer -->
        <footer class="main-footer">
            <div class="container">
                <div class="footer-grid">
                    <div class="footer-section">
                        <span class="footer-logo">A.V CATERING</span>
                        <p class="footer-tagline">
                            Exquisite flavors and professional service for your most memorable moments.
                        </p>
                    </div>
                    <div class="footer-section">
                        <h3 class="footer-heading">Quick Links</h3>
                        <ul class="footer-links">
                            <li><a href="{{ url('/menu') }}">Menu</a></li>
                            <li><a href="{{ url('/services') }}">Services</a></li>
                            <li><a href="{{ url('/gallery') }}">Gallery</a></li>
                        </ul>
                    </div>
                    <div class="footer-section">
                        <h3 class="footer-heading">Connect</h3>
                        <ul class="footer-links">
                            <li><a href="#">Instagram</a></li>
                            <li><a href="#">Facebook</a></li>
                            <li><a href="{{ url('/contact') }}">Contact Us</a></li>
                        </ul>
                    </div>
                </div>
                <div class="footer-bottom">
                    &copy; {{ date('Y') }} Catering Services App. All rights reserved.
                </div>
            </div>
        </footer>
    </div>

    <!-- Success Notification Popup -->
    @if(session('success'))
    <div x-data="{ show: true }" 
         x-show="show" 
         x-init="setTimeout(() => show = false, 5000)"
         x-transition:enter="notification-enter"
         x-transition:enter-start="notification-enter-start"
         x-transition:enter-end="notification-enter-end"
         x-transition:leave="notification-leave"
         x-transition:leave-start="notification-leave-start"
         x-transition:leave-end="notification-leave-end"
         class="success-popup"
         style="display: none;">
        <div class="success-popup-content">
            <div class="success-icon">✓</div>
            <div class="success-message">
                <h4>Success!</h4>
                <p>{{ session('success') }}</p>
            </div>
            <button @click="show = false" class="success-close">&times;</button>
        </div>
        <div class="success-progress"></div>
    </div>
    @endif

    <script>
        // Reveal animation on scroll
        function reveal() {
            var reveals = document.querySelectorAll(".reveal");
            for (var i = 0; i < reveals.length; i++) {
                var windowHeight = window.innerHeight;
                var elementTop = reveals[i].getBoundingClientRect().top;
                var elementVisible = 150;
                if (elementTop < windowHeight - elementVisible) {
                    reveals[i].classList.add("active");
                }
            }
        }
        window.addEventListener("scroll", reveal);
        window.addEventListener("load", reveal);
    </script>
</body>
</html>

                </div>