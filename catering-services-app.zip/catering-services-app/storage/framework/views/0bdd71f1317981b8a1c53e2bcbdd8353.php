<?php $__env->startSection('title', 'Private Packages'); ?>

<?php $__env->startSection('content'); ?>
<!-- Hero -->
<section class="about-hero" style="background-image: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url('https://images.unsplash.com/photo-1549488344-1f9b8d2bd1f3?q=80&w=2070&auto=format&fit=crop');">
    <div class="container text-center reveal">
        <a href="<?php echo e(url('/packages')); ?>" style="color: var(--gala-orange); font-weight: 700; text-decoration: none; margin-bottom: 2rem; display: inline-block;">← Back to All Categories</a>
        <h1 class="text-white mb-6">Private <span class="accent">Event Catering</span></h1>
        <p class="text-white opacity-90 max-w-2xl mx-auto text-lg">
            Personalized dining experiences for your most intimate family gatherings and home celebrations.
        </p>
    </div>
</section>

<div class="container py-24">
    <div class="max-w-5xl mx-auto" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 2rem;">
        <!-- Basic -->
        <div class="package-column reveal">
            <div class="package-column-header tier-basic text-white">
                <h3 class="text-white">Cozy Dinner</h3>
                <span class="text-white" style="opacity: 0.8; font-size: 0.9rem;">Home Gathering</span>
            </div>
            <div class="package-column-features">
                <ul class="package-features">
                    <li>Home Style Recipes</li>
                    <li>Standard Serving</li>
                </ul>
                <ul class="package-features">
                    <li>Minimal Setup</li>
                    <li>Quick Cleanup</li>
                </ul>
            </div>
            <div class="package-column-action">
                <div class="price-tag" style="margin:0; color: var(--text-main);">Rs. 400 <span style="font-size: 0.8rem;">/plate</span></div>
                <a href="<?php echo e(route('bookings.create')); ?>" class="btn-secondary-sm">Book Now</a>
            </div>
        </div>

        <!-- Standard -->
        <div class="package-column reveal" style="transition-delay: 0.1s">
            <div class="package-column-header tier-standard text-white">
                <h3 class="text-white">Housewarming</h3>
                <span class="text-white" style="opacity: 0.8; font-size: 0.9rem;">Welcoming Guests</span>
            </div>
            <div class="package-column-features">
                <ul class="package-features">
                    <li>Variety Buffet</li>
                    <li>Welcome Drinks</li>
                </ul>
                <ul class="package-features">
                    <li>Elegant Buffet Decor</li>
                    <li>Floor Protection</li>
                </ul>
            </div>
            <div class="package-column-action">
                <div class="price-tag" style="margin:0; color: var(--text-main);">Rs. 700 <span style="font-size: 0.8rem;">/plate</span></div>
                <a href="<?php echo e(route('bookings.create')); ?>" class="btn-secondary-sm">Book Now</a>
            </div>
        </div>

        <!-- Premium -->
        <div class="package-column reveal" style="transition-delay: 0.2s">
            <div class="package-column-header tier-premium text-white">
                <h3 class="text-white">Anniversary</h3>
                <span class="text-white" style="opacity: 0.8; font-size: 0.9rem;">Milestone Romance</span>
            </div>
            <div class="package-column-features">
                <ul class="package-features">
                    <li>3-Course Plated</li>
                    <li>Luxury Floral Decor</li>
                </ul>
                <ul class="package-features">
                    <li>Personal Server</li>
                    <li>Mood Enhancers</li>
                </ul>
            </div>
            <div class="package-column-action">
                <div class="price-tag" style="margin:0; color: var(--text-main);">Rs. 1100 <span style="font-size: 0.8rem;">/plate</span></div>
                <a href="<?php echo e(route('bookings.create')); ?>" class="btn-secondary-sm">Book Now</a>
            </div>
        </div>

        <!-- Luxury -->
        <div class="package-column reveal" style="transition-delay: 0.3s">
            <div class="package-column-header tier-luxury text-white">
                <h3 class="text-white">Bespoke Exclusive</h3>
                <span class="text-white" style="opacity: 0.8; font-size: 0.9rem;">Only for You</span>
            </div>
            <div class="package-column-features">
                <ul class="package-features">
                    <li>Tailor-Made Menu</li>
                    <li>Private Chef On-site</li>
                </ul>
                <ul class="package-features">
                    <li>VVIP Butler Service</li>
                    <li>Custom Table Art</li>
                </ul>
            </div>
            <div class="package-column-action">
                <div class="price-tag" style="margin:0; color: var(--text-main);">Rs. 2000 <span style="font-size: 0.8rem;">/plate</span></div>
                <a href="<?php echo e(route('bookings.create')); ?>" class="btn-secondary-sm">Book Now</a>
            </div>
        </div>
    </div>

    <!-- Comparison Section -->
    <div class="comparison-section reveal">
        <div class="text-center mb-12">
            <h2 class="text-4xl font-bold mb-4">Private Event <span class="accent">Comparison</span></h2>
            <p class="text-gray-600">Tailored catering for your most intimate celebrations.</p>
        </div>

        <div class="comparison-table-wrapper">
            <table class="comparison-table">
                <thead>
                    <tr>
                        <th class="feature-label">Features</th>
                        <th>Cozy Dinner</th>
                        <th>Housewarming</th>
                        <th>Anniversary</th>
                        <th>Bespoke Exclusive</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="feature-label">Dining Experience</td>
                        <td>Home Style</td>
                        <td>Casual Buffet</td>
                        <td>Elegant 3-Course</td>
                        <td>Private Chef Experience</td>
                    </tr>
                    <tr>
                        <td class="feature-label">Chef Interaction</td>
                        <td>Pre-Prepared</td>
                        <td>Service Staff</td>
                        <td>Personal Server</td>
                        <td>Exclusive On-site Chef</td>
                    </tr>
                    <tr>
                        <td class="feature-label">Welcome Experience</td>
                        <td>Standard Serving</td>
                        <td>Welcome Drinks Bar</td>
                        <td>Champagne/Juice Toast</td>
                        <td>Bespoke Ambiance</td>
                    </tr>
                    <tr>
                        <td class="feature-label">Decor Setup</td>
                        <td>Minimalist</td>
                        <td>Themed Buffet</td>
                        <td>Luxury Floral</td>
                        <td>Custom Table Art</td>
                    </tr>
                    <tr>
                        <td class="feature-label">Cleanup</td>
                        <td>Quick Express</td>
                        <td>Detailed</td>
                        <td>Full Restoration</td>
                        <td>White Glove Service</td>
                    </tr>
                    <tr>
                        <td class="feature-label">Price per Plate</td>
                        <td class="font-bold">Rs. 400</td>
                        <td class="font-bold">Rs. 700</td>
                        <td class="font-bold">Rs. 1100</td>
                        <td class="font-bold">Rs. 2000</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\catering-services-app\resources\views/packages/private.blade.php ENDPATH**/ ?>