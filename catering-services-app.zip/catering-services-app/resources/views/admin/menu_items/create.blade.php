@extends('layouts.admin')

@section('header', 'Create Menu Item')

@section('content')
<div class="card" style="max-width: 600px;">
    <form action="{{ route('admin.menu_items.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div style="margin-bottom: 1.5rem;">
            <label style="display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5rem;">Category</label>
            <select name="category_id" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;" required>
                <option value="">Select Category</option>
                @foreach($categories as $category)
                    <option value="{{ $category->id }}">{{ $category->name }}</option>
                @endforeach
            </select>
        </div>

        <div style="margin-bottom: 1.5rem;">
            <label style="display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5rem;">Item Name</label>
            <input type="text" name="name" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;" required>
        </div>

        <div style="margin-bottom: 1.5rem;">
            <label style="display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5rem;">Type</label>
            <select name="type" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;" required>
                <option value="main">Main Course</option>
                <option value="appetizer">Appetizer</option>
                <option value="dessert">Dessert</option>
                <option value="drink">Drink</option>
                <option value="snack">Snack</option>
            </select>
        </div>

        <div style="margin-bottom: 1.5rem;">
            <label style="display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5rem;">Description</label>
            <textarea name="description" rows="3" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;"></textarea>
        </div>

        <div style="margin-bottom: 1.5rem;">
            <label style="display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5rem;">Price (Optional)</label>
            <input type="number" name="price" value="0" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;">
        </div>

        <div style="margin-bottom: 2rem;">
            <label style="display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5rem;">Item Image</label>
            <input type="file" name="image" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;">
        </div>

        <div style="display: flex; gap: 1rem;">
            <button type="submit" class="btn btn-primary">Create Item</button>
            <a href="{{ route('admin.menu_items.index') }}" class="btn btn-outline">Cancel</a>
        </div>
    </form>
</div>
@endsection
