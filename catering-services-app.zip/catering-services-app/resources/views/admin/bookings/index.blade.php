@extends('layouts.admin')

@section('header', 'Booking Management')

@section('content')
<div class="card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
        <h3 style="margin: 0;">Order History</h3>
    </div>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Client</th>
                    <th>Event Date</th>
                    <th>Type</th>
                    <th>Status</th>
                    <th>Payment</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach($bookings as $booking)
                <tr>
                    <td>#{{ $booking->id }}</td>
                    <td>
                        <div style="font-weight: 600;">{{ $booking->full_name }}</div>
                        <div style="font-size: 0.75rem; color: var(--text-muted);">{{ $booking->phone }}</div>
                    </td>
                    <td>{{ \Carbon\Carbon::parse($booking->event_start_date)->format('M d, Y') }}</td>
                    <td><span class="badge badge-outline" style="border: 1px solid var(--border);">{{ ucfirst($booking->event_type) }}</span></td>
                    <td>
                        <span class="badge badge-{{ $booking->status == 'confirmed' ? 'success' : ($booking->status == 'pending' ? 'warning' : 'danger') }}">
                            {{ ucfirst($booking->status) }}
                        </span>
                    </td>
                    <td>
                        <form action="{{ route('admin.bookings.update_payment', $booking) }}" method="POST" style="display: flex; align-items: center; gap: 0.25rem;">
                            @csrf
                            @method('PATCH')
                            <select name="payment_status" onchange="this.form.submit()" style="font-size: 0.8rem; border: none; background: {{ $booking->payment_status == 'fully_paid' ? '#dcfce7' : ($booking->payment_status == 'advance_paid' ? '#e0f2fe' : '#fef9c3') }}; color: {{ $booking->payment_status == 'fully_paid' ? '#166534' : ($booking->payment_status == 'advance_paid' ? '#0369a1' : '#854d0e') }}; padding: 0.3rem 0.6rem; border-radius: 8px; font-weight: 700; cursor: pointer;">
                                <option value="pending" {{ $booking->payment_status == 'pending' ? 'selected' : '' }}>PENDING</option>
                                <option value="advance_paid" {{ $booking->payment_status == 'advance_paid' ? 'selected' : '' }}>ADVANCE PAID</option>
                                <option value="fully_paid" {{ $booking->payment_status == 'fully_paid' ? 'selected' : '' }}>FULLY PAID</option>
                            </select>
                        </form>
                    </td>
                    <td>
                        <a href="{{ route('admin.bookings.show', $booking) }}" class="btn btn-outline" style="padding: 0.5rem; font-size: 0.75rem;">Details</a>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    <div style="margin-top: 1.5rem;">
        {{ $bookings->links() }}
    </div>
</div>
@endsection
