@extends('layouts.admin')

@section('header', 'Create Category')

@section('content')
<div class="card" style="max-width: 600px;">
    <form action="{{ route('admin.categories.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div style="margin-bottom: 1.5rem;">
            <label style="display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5rem;">Category Name</label>
            <input type="text" name="name" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;" required placeholder="e.g., Wedding Catering">
        </div>

        <div style="margin-bottom: 1.5rem;">
            <label style="display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5rem;">Description</label>
            <textarea name="description" rows="4" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;" placeholder="Brief description of this category"></textarea>
        </div>

        <div style="margin-bottom: 2rem;">
            <label style="display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5rem;">Category Image</label>
            <input type="file" name="image" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;">
        </div>

        <div style="display: flex; gap: 1rem;">
            <button type="submit" class="btn btn-primary">Create Category</button>
            <a href="{{ route('admin.categories.index') }}" class="btn btn-outline">Cancel</a>
        </div>
    </form>
</div>
@endsection
