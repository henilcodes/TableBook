<?php $__env->startSection('title', 'Catering Packages'); ?>

<?php $__env->startSection('content'); ?>
<!-- Hero Section -->
<section class="hero-section contact-hero" style="background-image: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('<?php echo e(asset('images/slider 2.jfif')); ?>');">
    <div class="container hero-content-overlay reveal">
        <div class="hero-text-box" style="margin: 0 auto; text-align: center;">
            <h1 style="font-size: 3.5rem;">Catering <span class="accent">Packages</span></h1>
            <p style="font-size: 1.25rem;">
                Explore our curated tiers designed for exquisite dining experiences.
            </p>
        </div>
    </div>
</section>


<!--------type of package start----->
<section class="categories-package">
    <div class="package-container">
        <div class="package-birthday">
            <h3>Birthday Package</h3>
            <p>Perfect for birthday celibration package</p>
            <button>view Details</button>
        </div>
        <div class="package-wedding">
            <h3>wedding package</h3>
            <p> perfect for weddingcelibration</p>
            <button>View Detail</button>
        </div>
        <div class="package-corprate">
            <h3>corprate-package</h3>
            <p>perfect for corprate celibration</p>
            <button>View more details</button>
        </div>
        <div class="package-private">
            <h3>Private package</h3>
            <p>perfect for private celibration</p>
            <button>view more details</button>
        </div>
        <div class="package-outdoor">
            <h3>Outdoor Package</h3>
            <p>perfect for outdoor package</p>
            <button>view more details</button>
        </div>
        <div class="package-party">
            <h3>party Package</h3>
            <p>perfect for Party package</p>
            <button>view more details</button>
        </div>
    </div>
</section>
<!--------type of package end------->

<!-- Pricing Cards Section -->
<section class="features-section bg-gray-50" style="background-color: #f9fafb;">
    <div class="container">
        <div class="section-header reveal">
            <h2>Select Your Tier</h2>
            <p>Transparent pricing, unmatched quality.</p>
        </div>
        <div class="pricing-grid">
            <div class="pricing-card reveal">
                <h3>Standard</h3>
                <div class="price">Rs. 450<span>/plate</span></div>
                <ul class="pricing-features">
                    <li>3 Appetizers</li>
                    <li>2 Main Courses</li>
                    <li>Standard Decor Setup</li>
                    <li>Buffet Service</li>
                    <li>Basic Cutlery</li>
                </ul>
                <a href="<?php echo e(url('/contact')); ?>" class="btn-gala-outline" style="color: var(--text-main); border-color: var(--text-main); display: inline-block;">Select Standard</a>
            </div>
            <div class="pricing-card popular reveal" style="transition-delay: 0.1s">
                <div class="popular-badge">Most Popular</div>
                <h3>Premium</h3>
                <div class="price">Rs. 850<span>/plate</span></div>
                <ul class="pricing-features">
                    <li>5 Premium Appetizers</li>
                    <li>4 Main Courses</li>
                    <li>Live Food Counters</li>
                    <li>Elegant Dining Setup</li>
                    <li>Dedicated Service Staff</li>
                </ul>
                <a href="<?php echo e(url('/contact')); ?>" class="btn-gala" style="width: 100%; border: none; display: inline-block;">Select Premium</a>
            </div>
            <div class="pricing-card reveal" style="transition-delay: 0.2s">
                <h3>Platinum Collection</h3>
                <div class="price">Rs. 1500<span>/plate</span></div>
                <ul class="pricing-features">
                    <li>Custom Chef-Tasting Menu</li>
                    <li>Unlimited Imported Beverages</li>
                    <li>Bespoke Themed Decor</li>
                    <li>1-to-3 Staff Ratio</li>
                    <li>Valet Service Option</li>
                </ul>
                <a href="<?php echo e(url('/contact')); ?>" class="btn-gala-outline" style="color: var(--text-main); border-color: var(--text-main); display: inline-block;">Select Platinum</a>
            </div>
        </div>
    </div>
</section>

<!-- Comparison Table Section -->
<section class="features-section" style="background-color: white;">
    <div class="container">
        <div class="section-header reveal">
            <h2>Feature Comparison</h2>
            <p>Compare the detailed inclusions of each package.</p>
        </div>
        <div class="comparison-container reveal">
            <table class="comparison-table">
                <thead>
                    <tr>
                        <th class="feature-col">Features</th>
                        <th>Standard</th>
                        <th class="highlight-header">Premium</th>
                        <th>Platinum</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="feature-name">Appetizers (Veg/Non-Veg Options)</td>
                        <td>3 Items</td>
                        <td class="highlight-col">5 Items</td>
                        <td>7 Items</td>
                    </tr>
                    <tr>
                        <td class="feature-name">Main Courses</td>
                        <td>2 Items</td>
                        <td class="highlight-col">4 Items</td>
                        <td>Chef's Custom Menu</td>
                    </tr>
                    <tr>
                        <td class="feature-name">Live Cooking Counters</td>
                        <td><span class="cross">✕</span></td>
                        <td class="highlight-col"><span class="check">✓</span> (2 Counters)</td>
                        <td><span class="check">✓</span> (Unlimited)</td>
                    </tr>
                    <tr>
                        <td class="feature-name">Staffing Ratio</td>
                        <td>1 Waiter per 45 Pax</td>
                        <td class="highlight-col">1 Waiter per 20 Pax</td>
                        <td>1 Waiter per 10 Pax</td>
                    </tr>
                    <tr>
                        <td class="feature-name">Premium Crockery & Cutlery</td>
                        <td>Standard Steel</td>
                        <td class="highlight-col"><span class="check">✓</span> Bone China</td>
                        <td><span class="check">✓</span> Imported Ceramic</td>
                    </tr>
                    <tr>
                        <td class="feature-name">Themed Event Decor</td>
                        <td><span class="cross">✕</span></td>
                        <td class="highlight-col">Standard Setup</td>
                        <td><span class="check">✓</span> Fully Bespoke</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</section>

<!-- Benefits / Features Section -->
<section class="features-section bg-gray-50" style="background-color: #f9fafb;">
    <div class="container">
        <div class="section-header reveal">
            <h2>Why Choose Our Packages</h2>
        </div>
        <div class="benefits-grid">
            <div class="benefit-card reveal">
                <div class="benefit-icon">🌿</div>
                <div class="benefit-content">
                    <h3>Farm Fresh Produce</h3>
                    <p>We source ingredients locally to ensure maximum flavor and sustainability.</p>
                </div>
            </div>
            <div class="benefit-card reveal" style="transition-delay: 0.1s">
                <div class="benefit-icon">⏱️</div>
                <div class="benefit-content">
                    <h3>Punctual Setup</h3>
                    <p>Our team arrives hours early, ensuring the buffet is hot and ready precisely on time.</p>
                </div>
            </div>
            <div class="benefit-card reveal" style="transition-delay: 0.2s">
                <div class="benefit-icon">🎨</div>
                <div class="benefit-content">
                    <h3>Culinary Artistry</h3>
                    <p>Our chefs pay extreme attention to food styling and buffet presentation.</p>
                </div>
            </div>
            <div class="benefit-card reveal" style="transition-delay: 0.3s">
                <div class="benefit-icon">🤝</div>
                <div class="benefit-content">
                    <h3>Dedicated Manager</h3>
                    <p>Every event gets a dedicated floor manager so you can relax entirely.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- How It Works Section -->
<section class="features-section" style="background-color: white;">
    <div class="container">
        <div class="section-header reveal">
            <h2>How It Works</h2>
        </div>
        <div class="process-grid">
            <div class="process-step reveal">
                <div class="step-number">1</div>
                <h3>Choose a Tier</h3>
                <p>Select a package that fits your estimated guest count and budget.</p>
            </div>
            <div class="process-step reveal" style="transition-delay: 0.1s">
                <div class="step-number">2</div>
                <h3>Book a Tasting</h3>
                <p>Schedule a personal tasting session to finalize the flavor profiles.</p>
            </div>
            <div class="process-step reveal" style="transition-delay: 0.2s">
                <div class="step-number">3</div>
                <h3>Finalize Details</h3>
                <p>We perform site visits and finalize the logistic flow for the big day.</p>
            </div>
            <div class="process-step reveal" style="transition-delay: 0.3s">
                <div class="step-number">4</div>
                <h3>Experience Magic</h3>
                <p>Enjoy a flawless event executed by our professional team.</p>
            </div>
        </div>
    </div>
</section>

<!-- FAQ Section -->
<section class="features-section bg-gray-50" style="background-color: #f9fafb;">
    <div class="container">
        <div class="section-header reveal">
            <h2>Package FAQs</h2>
        </div>
        <div class="faq-container reveal">
            <details class="faq-item">
                <summary>Can we mix features from different packages?</summary>
                <div class="faq-content">Yes! We offer a la carte add-ons if you wish to select the Premium package but add the imported beverages from the Platinum tier.</div>
            </details>
            <details class="faq-item">
                <summary>Is there a minimum guest count for Platinum?</summary>
                <div class="faq-content">For Platinum packages, we generally require a minimum of 50 guests. For standard and premium, the minimum is 100 guests.</div>
            </details>
            <details class="faq-item">
                <summary>Do children count towards the plate pricing?</summary>
                <div class="faq-content">Children under 5 eat free. Children between 5 and 12 are charged at 50% of the adult plate cost.</div>
            </details>
        </div>
    </div>
</section>

<!-- CTA & Contact Form Section -->
<section class="features-section" style="background-color: white; padding-bottom: 80px;">
    <div class="container">
        <div class="cta-banner reveal">
            <div class="cta-content">
                <h2>Ready to book your package?</h2>
                <p>Fill out the form to grab a free consultation and tentative quote based on your preferred tier.</p>
                <div style="display: flex; gap: 1rem; align-items: center; margin-top: 1rem;">
                    <div style="width: 50px; height: 50px; border-radius: 50%; background: rgba(255,255,255,0.2); display: flex; align-items: center; justify-content: center; font-size: 1.5rem;">📞</div>
                    <div>
                        <p style="margin: 0; font-size: 0.85rem; opacity: 0.8;">Call us directly</p>
                        <p style="margin: 0; font-weight: bold; font-size: 1.25rem;">+91 7874395170</p>
                    </div>
                </div>
            </div>
            <div class="cta-form-container">
                <h3 style="margin-bottom: 2rem; font-size: 1.5rem; color: var(--text-main);">Request a Quote</h3>
                <form action="#" class="cta-form">
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Your Name" required>
                    </div>
                    <div class="form-group">
                        <select class="form-control" required style="color: #666;">
                            <option value="" disabled selected>Select Package Tier</option>
                            <option value="standard">Standard</option>
                            <option value="premium">Premium</option>
                            <option value="platinum">Platinum</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <input type="number" class="form-control" placeholder="Estimated Guests" required>
                    </div>
                    <button type="submit" class="btn-submit">Submit Request</button>
                </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\catering-services-app\resources\views/package.blade.php ENDPATH**/ ?>