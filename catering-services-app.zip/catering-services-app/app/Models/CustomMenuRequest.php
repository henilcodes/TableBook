<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CustomMenuRequest extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'menu_details',
        'additional_notes',
        'status',
        'admin_comment',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
