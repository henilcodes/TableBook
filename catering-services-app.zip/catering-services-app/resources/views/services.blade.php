@extends('layouts.app')

@section('title', 'Our Services')

@section('content')
<section class="hero-section contact-hero" style="background-image: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('{{ asset('images/services images.jfif') }}');">
    <div class="container hero-content-overlay reveal">
        <div class="hero-text-box">
            <h1>
                Bespoke <br>
                <span class="accent">Event Packages</span>
            </h1>
            <p>
                We believe every event is unique. Explore our curated packages designed to bring a touch of elegance and flavor to your special day.
            </p>
        </div>
    </div>
</section>

<!-- Detailed Packages Section -->
<section class="features-section" style="background: white;">
    <div class="container">
        <div class="section-header reveal">
            <h2>Select Your Experience</h2>
            <p class="hero-description" style="margin: 1rem auto;">Tailored solutions for every scale and style of celebration.</p>
        </div>

        <div class="features-grid">
            <!-- Wedding Package -->
            <div class="feature-card reveal" style="text-align: left; padding: 2.5rem;">
                <span style="font-size: 3rem; margin-bottom: 1.5rem; display: block;">💍</span>
                <h3 style="font-size: 1.5rem; margin-bottom: 1rem;">Wedding Celebration</h3>
                <p style="margin-bottom: 2rem; color: var(--text-muted);">A timeless experience for your most important day. We manage everything from the toast to the final dance.</p>
                <ul class="footer-links" style="margin-bottom: 2.5rem;">
                    <li style="margin-bottom: 0.5rem;">• 4-Course Formal Dining</li>
                    <li style="margin-bottom: 0.5rem;">• Premium Open Bar Service</li>
                    <li style="margin-bottom: 0.5rem;">• Elegant Table & Decor Setup</li>
                    <li style="margin-bottom: 0.5rem;">• Professional Wait Staff</li>
                </ul>
                <a href="{{ url('/contact') }}" class="btn-primary" style="width: 100%;">Enquire Now</a>
            </div>

            <!-- Corporate Package -->
            <div class="feature-card reveal" style="text-align: left; padding: 2.5rem; transition-delay: 0.1s">
                <span style="font-size: 3rem; margin-bottom: 1.5rem; display: block;">💼</span>
                <h3 style="font-size: 1.5rem; margin-bottom: 1rem;">Corporate Excellence</h3>
                <p style="margin-bottom: 2rem; color: var(--text-muted);">Impress your clients and team with professional midday caterings that fuel productivity and networking.</p>
                <ul class="footer-links" style="margin-bottom: 2.5rem;">
                    <li style="margin-bottom: 0.5rem;">• Networking Buffet Boards</li>
                    <li style="margin-bottom: 0.5rem;">• Continuous Coffee & Snack Bar</li>
                    <li style="margin-bottom: 0.5rem;">• Healthy Executive Bowls</li>
                    <li style="margin-bottom: 0.5rem;">• Discreet Professional Service</li>
                </ul>
                <a href="{{ url('/contact') }}" class="btn-primary" style="width: 100%;">Get Quote</a>
            </div>

            <!-- Birthday Package -->
            <div class="feature-card reveal" style="text-align: left; padding: 2.5rem; transition-delay: 0.2s">
                <span style="font-size: 3rem; margin-bottom: 1.5rem; display: block;">🎈</span>
                <h3 style="font-size: 1.5rem; margin-bottom: 1rem;">Birthday Bash</h3>
                <p style="margin-bottom: 2rem; color: var(--text-muted);">Celebrate another year with fun, vibrant flavors and an atmosphere that gets everyone talking.</p>
                <ul class="footer-links" style="margin-bottom: 2.5rem;">
                    <li style="margin-bottom: 0.5rem;">• Themed Food Stations</li>
                    <li style="margin-bottom: 0.5rem;">• Bespoke Celebration Cake</li>
                    <li style="margin-bottom: 0.5rem;">• Interactive Dessert Bar</li>
                    <li style="margin-bottom: 0.5rem;">• Casual Staffing & Drinks</li>
                </ul>
                <a href="{{ url('/contact') }}" class="btn-primary" style="width: 100%;">Plan Party</a>
            </div>

            <!-- Private Package -->
            <div class="feature-card reveal" style="text-align: left; padding: 2.5rem; transition-delay: 0.3s">
                <span style="font-size: 3rem; margin-bottom: 1.5rem; display: block;">🏠</span>
                <h3 style="font-size: 1.5rem; margin-bottom: 1rem;">Private Boutique</h3>
                <p style="margin-bottom: 2rem; color: var(--text-muted);">Bring the fine dining experience home. Perfect for intimate anniversaries and family celebrations.</p>
                <ul class="footer-links" style="margin-bottom: 2.5rem;">
                    <li style="margin-bottom: 0.5rem;">• Chef-Led Tasting Menu</li>
                    <li style="margin-bottom: 0.5rem;">• Curated Wine Pairings</li>
                    <li style="margin-bottom: 0.5rem;">• Complete Home Setup</li>
                    <li style="margin-bottom: 0.5rem;">• Personalized Concierge</li>
                </ul>
                <a href="{{ url('/contact') }}" class="btn-primary" style="width: 100%;">Book Private</a>
            </div>
<!-----outdoor package---->


             <div class="feature-card reveal" style="text-align: left; padding: 2.5rem; transition-delay: 0.3s">
                <span style="font-size: 3rem; margin-bottom: 1.5rem; display: block;">🏕</span>
                <h3 style="font-size: 1.5rem; margin-bottom: 1rem;">Outdoor Boutique</h3>
                <p style="margin-bottom: 2rem; color: var(--text-muted);">Bring the fine dining experience home. Perfect for intimate anniversaries and family celebrations.</p>
                <ul class="footer-links" style="margin-bottom: 2.5rem;">
                    <li style="margin-bottom: 0.5rem;">• Chef-Led Tasting Menu</li>
                    <li style="margin-bottom: 0.5rem;">• Curated Wine Pairings</li>
                    <li style="margin-bottom: 0.5rem;">• Complete Home Setup</li>
                    <li style="margin-bottom: 0.5rem;">• Personalized Concierge</li>
                </ul>
                <a href="{{ url('/contact') }}" class="btn-primary" style="width: 100%;">Book Outdoor</a>
            </div>
        </div>
    </div>
</section>

<section class="features-section" style="padding-top: 0;">
    <div class="container">
        <div class="section-header reveal">
            <h2>Our Standards</h2>
        </div>
        <div class="features-grid">
            <div class="feature-card reveal">
                <span class="feature-icon">🥂</span>
                <h3>Premium Quality</h3>
                <p>Only the freshest ingredients sourced from artisanal producers.</p>
            </div>
            <div class="feature-card reveal" style="transition-delay: 0.1s">
                <span class="feature-icon">✨</span>
                <h3>Expert Setup</h3>
                <p>Our team handles every detail of presentation and service.</p>
            </div>
            <div class="feature-card reveal" style="transition-delay: 0.2s">
                <span class="feature-icon">🧹</span>
                <h3>Cleanliness</h3>
                <p>Impeccable hygiene and seamless post-event cleanup.</p>
            </div>
        </div>
    </div>
</section>

<!-- How it Works / Process Section -->
<section class="features-section bg-gray-50" style="background-color: #f9fafb;">
    <div class="container">
        <div class="section-header reveal">
            <h2>How It Works</h2>
            <p>Our seamless process ensures your event is flawless from start to finish.</p>
        </div>
        <div class="process-grid">
            <div class="process-step reveal">
                <div class="step-number">1</div>
                <h3>Consultation</h3>
                <p>We discuss your vision, preferences, and understand the scale of your event.</p>
            </div>
            <div class="process-step reveal" style="transition-delay: 0.1s">
                <div class="step-number">2</div>
                <h3>Tasting & Menu</h3>
                <p>Curate your bespoke menu with our executive chefs at a private tasting session.</p>
            </div>
            <div class="process-step reveal" style="transition-delay: 0.2s">
                <div class="step-number">3</div>
                <h3>Planning & Logistics</h3>
                <p>Our team handles the venue layout, staffing needs, and timeline generation.</p>
            </div>
            <div class="process-step reveal" style="transition-delay: 0.3s">
                <div class="step-number">4</div>
                <h3>The Event</h3>
                <p>Relax and enjoy as our professional team executes your flawless event.</p>
            </div>
        </div>
    </div>
</section>

<!-- Portfolio Section -->
<section class="features-section" style="background-color: white;">
    <div class="container">
        <div class="section-header reveal">
            <h2>Event Portfolio</h2>
            <p>A glimpse into our beautifully executed events.</p>
        </div>
        <div class="portfolio-grid">
            <div class="portfolio-item reveal">
                <img src="https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&q=80&w=800" alt="Wedding Setup">
                <div class="portfolio-overlay">
                    <h4>Grand Wedding</h4>
                    <p>Floral Canopy & Dining</p>
                </div>
            </div>
            <div class="portfolio-item reveal" style="transition-delay: 0.1s">
                <img src="https://images.unsplash.com/photo-1530103043960-ef38714abb15?auto=format&fit=crop&q=80&w=800" alt="Corporate Buffet">
                <div class="portfolio-overlay">
                    <h4>Corporate Buffet</h4>
                    <p>Premium Grazing Table</p>
                </div>
            </div>
            <div class="portfolio-item reveal" style="transition-delay: 0.2s">
                <img src="https://images.unsplash.com/photo-1555244162-803834f70033?auto=format&fit=crop&q=80&w=800" alt="Private Dining">
                <div class="portfolio-overlay">
                    <h4>Intimate Anniversary</h4>
                    <p>Chef's Tasting Menu</p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Detailed Packages Grid Section -->
<section class="features-section bg-gray-50" style="padding: 80px 0;">
    <div class="container">
        <div class="section-header reveal text-center mb-12">
            <h2>Our Featured <span class="accent">Packages</span></h2>
            <p>Explore our most popular catering solutions for every occasion.</p>
        </div>
        <div class="features-grid">
            <div class="package-column reveal" style="transition-delay: 0.1s">
                <div class="package-column-header tier-standard">
                    <h3>Teen Bash</h3>
                    <span style="opacity: 0.8; font-size: 0.9rem;">Modern & Trendy</span>
                </div>
                <div class="package-column-features">
                    <ul class="package-features">
                        <li>Italian & Chinese Starters</li>
                        <li>Mocktail Bar</li>
                    </ul>
                    <ul class="package-features">
                        <li>Pasta & Pizza Station</li>
                        <li>Selfie Booth Decor</li>
                    </ul>
                </div>
                <div class="package-column-action">
                    <div class="price-tag" style="margin:0; color: var(--text-main);">Rs. 450 <span style="font-size: 0.8rem;">/plate</span></div>
                    <a href="{{ route('bookings.create') }}" class="btn-secondary-sm">Book Now</a>
                </div>
            </div>

            <div class="package-column reveal" style="transition-delay: 0.1s">
                <div class="package-column-header tier-standard text-white">
                    <h3 class="text-white">Seminar Snack</h3>
                    <span class="text-white" style="opacity: 0.8; font-size: 0.9rem;">Networking Bites</span>
                </div>
                <div class="package-column-features">
                    <ul class="package-features">
                        <li>High-Tea Assortment</li>
                        <li>Cookies & Pastries</li>
                    </ul>
                    <ul class="package-features">
                        <li>Coffee Station</li>
                        <li>Buffet Presentation</li>
                    </ul>
                </div>
                <div class="package-column-action">
                    <div class="price-tag" style="margin:0; color: var(--text-main);">Rs. 350 <span style="font-size: 0.8rem;">/plate</span></div>
                    <a href="{{ route('bookings.create') }}" class="btn-secondary-sm">Book Now</a>
                </div>
            </div>

            <div class="package-column reveal" style="transition-delay: 0.1s">
                <div class="package-column-header tier-standard text-white">
                    <h3 class="text-white">Park Buffet</h3>
                    <span class="text-white" style="opacity: 0.8; font-size: 0.9rem;">Themed Outdoor</span>
                </div>
                <div class="package-column-features">
                    <ul class="package-features">
                        <li>Hot Food Warmers</li>
                        <li>Street Food Counter</li>
                    </ul>
                    <ul class="package-features">
                        <li>Shaded Dining Area</li>
                        <li>On-site Cleaning</li>
                    </ul>
                </div>
                <div class="package-column-action">
                    <div class="price-tag" style="margin:0; color: var(--text-main);">Rs. 550 <span style="font-size: 0.8rem;">/plate</span></div>
                    <a href="{{ route('bookings.create') }}" class="btn-secondary-sm">Book Now</a>
                </div>
            </div>

            <div class="package-column reveal" style="transition-delay: 0.1s">
                <div class="package-column-header tier-standard text-white">
                    <h3 class="text-white">Classic Shadi</h3>
                    <span class="text-white" style="opacity: 0.8; font-size: 0.9rem;">Traditional Splendor</span>
                </div>
                <div class="package-column-features">
                    <ul class="package-features">
                        <li>Multi-Cuisine Buffet</li>
                        <li>Live Mithai Counter</li>
                    </ul>
                    <ul class="package-features">
                        <li>Fruit Display</li>
                        <li>Standard Crockery</li>
                    </ul>
                </div>
                <div class="package-column-action">
                    <div class="price-tag" style="margin:0; color: var(--text-main);">Rs. 850 <span style="font-size: 0.8rem;">/plate</span></div>
                    <a href="{{ route('bookings.create') }}" class="btn-secondary-sm">Book Now</a>
                </div>
            </div>

            <div class="package-column reveal" style="transition-delay: 0.2s">
                <div class="package-column-header tier-premium text-white">
                    <h3 class="text-white">Grand Utsav</h3>
                    <span class="text-white" style="opacity: 0.8; font-size: 0.9rem;">Exquisite Celebration</span>
                </div>
                <div class="package-column-features">
                    <ul class="package-features">
                        <li>Continental & Pan Asian</li>
                        <li>Live Pasta Counter</li>
                    </ul>
                    <ul class="package-features">
                        <li>Cold Pressed Juices</li>
                        <li>Premium Silver Service</li>
                    </ul>
                </div>
                <div class="package-column-action">
                    <div class="price-tag" style="margin:0; color: var(--text-main);">Rs. 1500 <span style="font-size: 0.8rem;">/plate</span></div>
                    <a href="{{ route('bookings.create') }}" class="btn-secondary-sm">Book Now</a>
                </div>
            </div>
        </div>
    </div>
</section>



<!-------package section end------>

<!-- Testimonials Section -->
<section class="features-section" style="background-color: white;">
    <div class="container">
        <div class="section-header reveal">
            <h2>Client Love</h2>
            <p>Don't just take our word for it.</p>
        </div>
        <div class="testimonials-grid">
            <div class="testimonial-card reveal">
                <p class="testimonial-text">"A.V Catering transformed our wedding night! The live counters were a massive hit and the presentation was simply stunning."</p>
                <div class="client-info">
                    <img src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=100&q=80" alt="Client Avatar" class="client-avatar">
                    <div class="client-details">
                        <h4>Priya & Rahul</h4>
                        <p>Wedding Clients</p>
                    </div>
                </div>
            </div>
            <div class="testimonial-card reveal" style="transition-delay: 0.1s">
                <p class="testimonial-text">"Flawless corporate service. They handled a 500-person conference with incredible efficiency and the food quality remained top-notch."</p>
                <div class="client-info">
                    <img src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=100&q=80" alt="Client Avatar" class="client-avatar">
                    <div class="client-details">
                        <h4>Vikram Desai</h4>
                        <p>TechCorp India</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- FAQ Section -->
<section class="features-section bg-gray-50" style="background-color: #f9fafb;">
    <div class="container">
        <div class="section-header reveal">
            <h2>Frequently Asked Questions</h2>
        </div>
        <div class="faq-container reveal">
            <details class="faq-item">
                <summary>How far in advance should we secure our date?</summary>
                <div class="faq-content">We highly recommend booking at least 3 to 6 months in advance, especially for the busy wedding season (November to February). However, we can accommodate smaller events with a 2-week notice depending on availability.</div>
            </details>
            <details class="faq-item">
                <summary>Do you offer customized menus for dietary restrictions?</summary>
                <div class="faq-content">Absolutely. We can fully customize our menus to cater to vegan, gluten-free, Jain, or any specific allergy requirements without compromising on taste or presentation.</div>
            </details>
            <details class="faq-item">
                <summary>Is table decor and cutlery included in the pricing?</summary>
                <div class="faq-content">Our Premium and Platinum packages include elegant table decor and high-quality crockery/cutlery. For standard packages, these can be added as an optional upgrade.</div>
            </details>
        </div>
    </div>
</section>

<!-- CTA & Contact Form Section -->
<section class="features-section" style="background-color: white; padding-bottom: 80px;">
    <div class="container">
        <div class="cta-banner reveal">
            <div class="cta-content">
                <h2>Ready to host an unforgettable event?</h2>
                <p>Reach out to our experts today to start planning your perfect menu, setup, and experience.</p>
                <div style="display: flex; gap: 1rem; align-items: center; margin-top: 1rem;">
                    <div style="width: 50px; height: 50px; border-radius: 50%; background: rgba(255,255,255,0.2); display: flex; align-items: center; justify-content: center; font-size: 1.5rem;">📞</div>
                    <div>
                        <p style="margin: 0; font-size: 0.85rem; opacity: 0.8;">Call us directly</p>
                        <p style="margin: 0; font-weight: bold; font-size: 1.25rem;">+91 7874395170</p>
                    </div>
                </div>
            </div>
            <div class="cta-form-container">
                <h3 style="margin-bottom: 2rem; font-size: 1.5rem; color: var(--text-main);">Request a Free Quote</h3>
                <form action="#" class="cta-form">
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Your Name" required>
                    </div>
                    <div class="form-group">
                        <input type="email" class="form-control" placeholder="Email Address" required>
                    </div>
                    <div class="form-group">
                        <select class="form-control" required style="color: #666;">
                            <option value="" disabled selected>Select Event Type</option>
                            <option value="wedding">Wedding</option>
                            <option value="corporate">Corporate</option>
                            <option value="party">Private Party</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                    <button type="submit" class="btn-submit">Submit Inquiry</button>
                </form>
            </div>
        </div>
    </div>
</section>
@endsection
