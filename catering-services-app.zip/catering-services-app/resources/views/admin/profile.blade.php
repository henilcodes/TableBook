@extends('layouts.admin')

@section('title', 'Profile Settings')
@section('header', 'Account Settings')

@section('content')
<div class="container-fluid">
    <div class="max-w-2xl">
        @if(session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif

        <div class="card shadow-sm border-0 rounded-3">
            <div class="card-body p-5">
                <div class="d-flex align-items-center gap-4 mb-5 pb-4 border-b border-light">
                    <div class="user-avatar" style="width: 80px; height: 80px; font-size: 2rem;">
                        {{ substr($user->name, 0, 1) }}
                    </div>
                    <div>
                        <h2 class="h4 mb-1">{{ $user->name }}</h2>
                        <p class="text-muted mb-0">Administrator since {{ $user->created_at->format('M Y') }}</p>
                    </div>
                </div>

                <form action="{{ route('admin.profile.update') }}" method="POST">
                    @csrf
                    @method('PATCH')

                    <div class="mb-4">
                        <label for="name" class="form-label font-bold">Full Name</label>
                        <input type="text" name="name" id="name" class="form-control form-control-lg @error('name') is-invalid @enderror" value="{{ old('name', $user->name) }}" required>
                        @error('name')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-4">
                        <label for="email" class="form-label font-bold">Email Address</label>
                        <input type="email" name="email" id="email" class="form-control form-control-lg @error('email') is-invalid @enderror" value="{{ old('email', $user->email) }}" required>
                        @error('email')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <hr class="my-5 border-light">

                    <div class="mb-4">
                        <div class="d-flex justify-content-between">
                            <label for="password" class="form-label font-bold">New Password</label>
                            <small class="text-muted">Leave blank to keep current password</small>
                        </div>
                        <input type="password" name="password" id="password" class="form-control form-control-lg @error('password') is-invalid @enderror">
                        @error('password')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-5">
                        <label for="password_confirmation" class="form-label font-bold">Confirm New Password</label>
                        <input type="password" name="password_confirmation" id="password_confirmation" class="form-control form-control-lg">
                    </div>

                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary btn-lg py-3">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection

@push('styles')
<style>
    .form-control-lg {
        border-radius: 0.75rem;
        padding: 0.75rem 1.25rem;
        border-color: #e2e8f0;
        font-size: 1rem;
    }
    .form-control-lg:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 4px rgba(79, 70, 229, 0.1);
    }
    .font-bold {
        font-weight: 600;
        color: var(--text-main);
    }
</style>
@endpush
