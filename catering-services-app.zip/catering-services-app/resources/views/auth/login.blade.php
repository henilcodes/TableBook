@extends('layouts.app')

@section('title', 'Login')

@section('content')
<div class="auth-page">
    <div class="auth-card reveal">
        <div class="auth-header">
            <h2>Welcome Back</h2>
            <p class="hero-description" style="font-size: 0.9rem; margin-top: 0.5rem;">Sign in to manage your catering events.</p>
        </div>

        <form action="{{ route('login') }}" method="POST" class="space-y-6">
            @csrf
            
            <div class="form-group">
                <label for="email" class="form-label">Email Address</label>
                <input id="email" name="email" type="email" required class="form-input" placeholder="you@example.com">
                @error('email') <p class="mt-1 text-xs text-[#f53003]">{{ $message }}</p> @enderror
            </div>

            <div class="form-group">
                <label for="password" class="form-label">Password</label>
                <input id="password" name="password" type="password" required class="form-input" placeholder="••••••••">
            </div>

            <div class="flex justify-between items-center text-sm mt-4">
                <label class="flex items-center cursor-pointer">
                    <input id="remember" name="remember" type="checkbox" style="margin-right: 0.5rem;">
                    <span>Remember me</span>
                </label>
                <a href="#" style="color: var(--primary); text-decoration: none; font-weight: 500;">Forgot password?</a>
            </div>

            <div class="mt-8">
                <button type="submit" class="btn-primary w-full">Sign In</button>
            </div>
        </form>

        <div class="mt-8 text-center text-sm">
            <span style="color: var(--text-muted);">Don't have an account?</span>
            <a href="{{ route('register') }}" style="color: var(--primary); text-decoration: none; font-weight: 600; margin-left: 0.25rem;">Create Account</a>
        </div>
    </div>
</div>
@endsection
