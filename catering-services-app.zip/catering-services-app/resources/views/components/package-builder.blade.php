<div class="package-builder auth-card" style="max-width: 800px; padding: 0; overflow: hidden; margin: 2rem auto;" x-data="{ 
    basePrice: 25, 
    guestCount: 50,
    addons: [
        { id: 1, name: 'Dessert Bar', price: 5, selected: false },
        { id: 2, name: 'Late Night Snacks', price: 8, selected: false },
        { id: 3, name: 'Premium Bar Service', price: 15, selected: false }
    ],
    getTotal() {
        let addonTotal = this.addons.reduce((sum, a) => sum + (a.selected ? a.price : 0), 0);
        return (this.basePrice + addonTotal) * this.guestCount;
    }
}">
    <div class="p-8" style="background: var(--primary); color: white;">
        <h3 class="text-2xl font-bold">Build Your Custom Package</h3>
        <p class="mt-2 opacity-90">Select your menu and add-ons for an instant estimate.</p>
    </div>

    <div class="p-8 space-y-8">
        <!-- Guest Count -->
        <div>
            <label class="form-label">Number of Guests</label>
            <input type="range" min="10" max="500" step="10" x-model="guestCount" class="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer" style="accent-color: var(--primary);">
            <div class="mt-4 flex justify-between text-sm" style="color: var(--text-muted);">
                <span>10 Guests</span>
                <span class="font-bold" style="color: var(--primary);" x-text="guestCount + ' Guests'"></span>
                <span>500 Guests</span>
            </div>
        </div>

        <!-- Add-ons -->
        <div>
            <label class="form-label" style="margin-bottom: 1rem;">Enhance Your Event</label>
            <div class="grid grid-cols-1 gap-4">
                <template x-for="addon in addons" :key="addon.id">
                    <button 
                        @click="addon.selected = !addon.selected"
                        class="flex items-center justify-between p-4 rounded-lg border-2 transition-all"
                        :style="addon.selected ? 'border-color: var(--primary); background: var(--primary-light);' : 'border-color: var(--border-color); background: white;'"
                    >
                        <div class="flex items-center gap-4">
                            <span class="text-xl" x-text="addon.selected ? '✅' : '➕'"></span>
                            <span class="font-medium" x-text="addon.name"></span>
                        </div>
                        <span style="color: var(--text-muted);" x-text="'+ Rs.' + addon.price + '/pp'"></span>
                    </button>
                </template>
            </div>
        </div>

        <!-- Total Estimate -->
        <div class="pt-8 border-t flex justify-between items-center">
            <div>
                <p class="uppercase tracking-wider font-bold text-sm" style="color: var(--text-muted);">Estimated Total</p>
                <p class="text-4xl font-black mt-1" style="margin: 0;">
                    Rs. <span x-text="getTotal().toLocaleString()"></span>
                </p>
            </div>
            <a href="{{ url('/contact') }}" class="btn-primary">
                Book This
            </a>
        </div>
    </div>
</div>
