<?php $__env->startSection('header', 'Create Package'); ?>

<?php $__env->startSection('content'); ?>
<div class="card" style="max-width: 600px;">
    <form action="<?php echo e(route('admin.packages.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div style="margin-bottom: 1.5rem;">
            <label style="display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5rem;">Category</label>
            <select name="category_id" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;" required>
                <option value="">Select Category</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div style="margin-bottom: 1.5rem;">
            <label style="display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5rem;">Package Name</label>
            <input type="text" name="name" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;" required>
        </div>

        <div style="margin-bottom: 1.5rem;">
            <label style="display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5rem;">Description</label>
            <textarea name="description" rows="4" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;"></textarea>
        </div>

        <div style="margin-bottom: 2rem;">
            <label style="display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5rem;">Price Per Plate (Rs.)</label>
            <input type="number" name="price_per_plate" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;" required>
        </div>

        <div style="display: flex; gap: 1rem;">
            <button type="submit" class="btn btn-primary">Create Package</button>
            <a href="<?php echo e(route('admin.packages.index')); ?>" class="btn btn-outline">Cancel</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\catering-services-app\resources\views/admin/packages/create.blade.php ENDPATH**/ ?>