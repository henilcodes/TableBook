@extends('layouts.app')

@section('title', 'Manage Custom Menu Requests')

@section('content')
<div class="container py-12">
    <div class="mb-10 flex justify-between items-center">
        <h1 class="text-3xl font-bold text-gray-800">Custom Menu <span class="text-accent">Requests</span></h1>
        <div class="text-sm bg-white px-4 py-2 rounded-lg border border-gray-100 shadow-sm">
            Total Requests: {{ $requests->total() }}
        </div>
    </div>

    @if(session('success'))
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-8" role="alert">
            <span class="block sm:inline">{{ session('success') }}</span>
        </div>
    @endif

    <div class="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100">
        <table class="w-full text-left border-collapse">
            <thead class="bg-gray-50 text-gray-600 text-sm font-semibold uppercase tracking-wider">
                <tr>
                    <th class="px-6 py-4">User</th>
                    <th class="px-6 py-4">Requested Content</th>
                    <th class="px-6 py-4">Status</th>
                    <th class="px-6 py-4">Date</th>
                    <th class="px-6 py-4 text-center">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                @forelse($requests as $request)
                    <tr class="hover:bg-gray-50/50 transition-all">
                        <td class="px-6 py-4">
                            <div class="font-medium text-gray-900">{{ $request->user->name }}</div>
                            <div class="text-xs text-gray-500">{{ $request->user->email }}</div>
                        </td>
                        <td class="px-6 py-4">
                            <div class="max-w-xs truncate" title="{{ $request->menu_details }}">
                                {{ $request->menu_details }}
                            </div>
                        </td>
                        <td class="px-6 py-4">
                            @if($request->status == 'pending')
                                <span class="px-2 py-1 text-xs font-bold rounded-full bg-yellow-100 text-yellow-700">Pending</span>
                            @elseif($request->status == 'provided')
                                <span class="px-2 py-1 text-xs font-bold rounded-full bg-green-100 text-green-700">Available</span>
                            @elseif($request->status == 'not_available')
                                <span class="px-2 py-1 text-xs font-bold rounded-full bg-red-100 text-red-700">Not Available</span>
                            @endif
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-500">
                            {{ $request->created_at->format('M d, Y') }}
                        </td>
                        <td class="px-6 py-4 text-center">
                            <button onclick="openModal('{{ $request->id }}')" class="bg-blue-50 text-blue-600 px-3 py-1 rounded-lg font-semibold hover:bg-blue-100 transition-all">
                                Update
                            </button>
                        </td>
                    </tr>

                    <!-- Modal for each request -->
                    <div id="modal-{{ $request->id }}" class="hidden fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
                        <div class="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-0 relative shadow-2xl">
                            <div class="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50 rounded-t-2xl">
                                <h3 class="text-xl font-bold">Manage Request #{{ $request->id }}</h3>
                                <button onclick="closeModal('{{ $request->id }}')" class="text-gray-400 hover:text-gray-600">
                                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                                </button>
                            </div>
                            
                            <div class="p-8">
                                <div class="grid grid-cols-2 gap-8 mb-8">
                                    <div>
                                        <p class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">User details</p>
                                        <p class="font-semibold">{{ $request->user->name }}</p>
                                        <p class="text-sm text-gray-600">{{ $request->user->email }}</p>
                                    </div>
                                    <div>
                                        <p class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Requested On</p>
                                        <p class="font-semibold">{{ $request->created_at->format('l, F j, Y') }}</p>
                                    </div>
                                </div>

                                <div class="mb-6">
                                    <p class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Requested Menu Items</p>
                                    <div class="p-4 bg-gray-50 rounded-xl border border-gray-100 whitespace-pre-wrap text-gray-800">
                                        {{ $request->menu_details }}
                                    </div>
                                </div>

                                @if($request->additional_notes)
                                <div class="mb-8">
                                    <p class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Additional Notes</p>
                                    <div class="p-4 bg-gray-50 rounded-xl border border-gray-100 whitespace-pre-wrap text-gray-700">
                                        {{ $request->additional_notes }}
                                    </div>
                                </div>
                                @endif

                                <form action="{{ route('admin.custom_menus.update_status', $request->id) }}" method="POST">
                                    @csrf
                                    @method('PATCH')
                                    
                                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                                        <div>
                                            <label for="status" class="block text-sm font-semibold mb-2">Update Status</label>
                                            <select name="status" id="status" class="w-full p-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-500 outline-none">
                                                <option value="pending" {{ $request->status == 'pending' ? 'selected' : '' }}>Pending</option>
                                                <option value="provided" {{ $request->status == 'provided' ? 'selected' : '' }}>Available / Provided</option>
                                                <option value="not_available" {{ $request->status == 'not_available' ? 'selected' : '' }}>Not Available</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="mb-8">
                                        <label for="admin_comment" class="block text-sm font-semibold mb-2">Admin Comment / Feedback</label>
                                        <textarea name="admin_comment" id="admin_comment" rows="3" class="w-full p-4 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Add a note for the user...">{{ $request->admin_comment }}</textarea>
                                    </div>

                                    <div class="flex justify-end">
                                        <button type="submit" class="bg-blue-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-200">
                                            Update Request
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                @empty
                    <tr>
                        <td colspan="5" class="px-6 py-12 text-center text-gray-500 italic">No custom menu requests found.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    
    <div class="mt-6">
        {{ $requests->links() }}
    </div>
</div>

<script>
    function openModal(id) {
        document.getElementById('modal-' + id).classList.remove('hidden');
        document.body.style.overflow = 'hidden';
    }
    function closeModal(id) {
        document.getElementById('modal-' + id).classList.add('hidden');
        document.body.style.overflow = 'auto';
    }
</script>

<style>
    .text-accent { color: #ff6b6b; }
</style>
@endsection
