<?php $__env->startSection('title', 'Contact Us'); ?>

<?php $__env->startSection('content'); ?>
<!-- Contact Hero Section -->
<section class="hero-section contact-hero" style="background-image: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('<?php echo e(asset('images/images 2.jfif')); ?>');">
    <div class="container hero-content-overlay reveal">
        <div class="hero-text-box">
            <h1>Contact<br> <span class="accent"> Us</span></h1>
            <p>
                We are here to help you plan something amazing..
            </p>
        </div>
    </div>
</section>

<section class="contact-details-section">
    <div class="container">
        <div class="contact-us-tagline text-center mb-12">
            <span class="script-font" style="color: var(--gala-orange); font-size: 2.5rem; font-family: 'Playfair Display', serif; font-style: italic;">Get in touch</span>
        </div>

        <div class="contact-grid">
            <!-- Left Side: Contact Details -->
            <div class="contact-info-column reveal">
                <h2 class="mb-8" style="font-weight: 700; color: #1a1a1a;">Contact Details</h2>
                
                <div class="info-list">
                    <div class="info-item mb-6">
                        <span class="info-icon">🏠</span>
                        <div class="info-text">
                            <p>123,valsad<br>NH.48 Valsad-3961501</p>
                        </div>
                    </div>
                    
                    <div class="info-item mb-6">
                        <span class="info-icon">📞</span>
                        <div class="info-text">
                            <p>+91 7874395170</p>
                        </div>
                    </div>
                    
                    <div class="info-item mb-6">
                        <span class="info-icon">✉️</span>
                        <div class="info-text">
                            <p>info@avcaterers.com</p>
                        </div>
                    </div>
                    
                    <div class="info-item mb-8">
                        <span class="info-icon">🕙</span>
                        <div class="info-text">
                            <p>Mon - Fri: 11:00 AM - 08:00 PM<br>SAT - SUN: 10:00 AM - 02:00 PM</p>
                        </div>
                    </div>
                </div>

                <div class="mascot-container mt-12">
                    <img src="https://img.freepik.com/free-vector/customer-service-concept-illustration_114360-3129.jpg" alt="Support Mascot" class="contact-mascot" style="max-width: 300px;">
                    <div class="social-tree mt-4">
                        <!-- Social items could go here as specialized icons -->
                    </div>
                </div>
            </div>

            <!-- Right Side: Contact Form -->
            <div class="contact-form-column reveal" style="transition-delay: 0.2s">
                <form action="#" class="styled-contact-form">
                    <div class="form-group mb-4">
                        <input type="email" placeholder="Email" class="form-input" required>
                    </div>
                    <div class="form-group mb-4">
                        <input type="text" placeholder="Subject" class="form-input" required>
                    </div>
                    <div class="form-group mb-4">
                        <input type="text" placeholder="Phone" class="form-input" required>
                    </div>
                    <div class="form-group mb-4">
                        <textarea placeholder="Message" class="form-input" style="height: 150px;" required></textarea>
                    </div>
                    <button type="submit" class="btn-primary">Send Message</button>

                </form>
                <style>
button {
    width: 100%;
    height: 50px;
    font-size: 18px;
    background-color: #ff6600;
    color: white;
    border: none;
    border-radius: 8px;
    cursor: pointer;
}

button:hover {
    background-color: #c29272;
}
</style>
            </div>
        </div>
    </div>
   <div style="width:100%">
    
        
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2327.1111352921234!2d72.76658490829588!3d22.824308879226916!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e608dfdfbebcd%3A0x9411844c556039f!2sD%20A%20Degree%20Engineering%20and%20Technology!5e1!3m2!1sen!2sin!4v1776925567198!5m2!1sen!2sin" width="100%" height="350" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" >
        </iframe>
        
    
</div>
</section>

<!-- WhatsApp Floating Button -->
<a href="https://wa.me/919879000200" class="whatsapp-float" target="_blank">
    <img src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" alt="WhatsApp">
</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\catering-services-app\resources\views/contact.blade.php ENDPATH**/ ?>