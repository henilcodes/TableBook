<?php $__env->startSection('title', 'About Us'); ?>

<?php $__env->startSection('content'); ?>
<!-- Section 1: Introduction (Hero) -->
<section class="about-hero" style="background-image: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('https://images.unsplash.com/photo-1555244162-803834f70033?q=80&w=2070&auto=format&fit=crop');">
    <div class="container text-center reveal">
        <h1 class="text-white mb-6">Crafting <span class="accent">Memorable Moments</span></h1>
        <p class="text-white opacity-90 max-w-2xl mx-auto text-lg">
            At A.V Catering, we believe that great food is the soul of every event. 
            For over a decade, we've been Surat's premier choice for exquisite tastes and flawless service.
        </p>
    </div>
</section>

<!-- Section 2: Our Story -->
<section class="story-section bg-white">
    <div class="container">
        <div class="story-grid">
            <div class="reveal">
                <span class="accent" style="font-weight: 700; text-transform: uppercase;">Since 2012</span>
                <h2 class="mb-6 mt-2" style="font-size: 2.5rem; font-weight: 800;">Our Journey</h2>
                <p class="mb-6 leading-relaxed text-gray-600">
                    What started as a small family passion for authentic flavors has grown into one of Surat's most trusted catering brands. Founded on the principles of quality, hygiene, and hospitality, A.V Catering has transformed thousands of events into culinary celebrations.
                </p>
                <p class="mb-8 leading-relaxed text-gray-600">
                    From our humble beginnings, we have expanded our expertise from traditional local delicacies to international cuisines, always keeping our "Guest is God" philosophy at the heart of everything we do.
                </p>
            </div>
            <div class="story-image reveal" style="transition-delay: 0.2s">
                <img src="https://images.unsplash.com/photo-1552664730-d307ca884978?q=80&w=2070&auto=format&fit=crop" alt="Our Team Collaboration">
            </div>
        </div>
    </div>
</section>

<!-- Section 3: What We Offer -->
<section class="py-24 bg-gray-50">
    <div class="container">
        <div class="text-center mb-16 reveal">
            <h2 style="font-size: 2.5rem; font-weight: 800;">What We Offer</h2>
            <p class="text-gray-600">Comprehensive catering solutions tailored for every occasion.</p>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div class="value-card reveal">
                <span style="font-size: 2.5rem;">💍</span>
                <h3 class="my-4">Wedding Catering</h3>
                <p class="text-sm text-gray-600">Exquisite multi-course meals and grand buffets for your big day.</p>
            </div>
            <div class="value-card reveal" style="transition-delay: 0.1s">
                <span style="font-size: 2.5rem;">🏢</span>
                <h3 class="my-4">Corporate Events</h3>
                <p class="text-sm text-gray-600">Professional lunches and networking snacks for your business needs.</p>
            </div>
            <div class="value-card reveal" style="transition-delay: 0.2s">
                <span style="font-size: 2.5rem;">🎉</span>
                <h3 class="my-4">Private Parties</h3>
                <p class="text-sm text-gray-600">Intimate gatherings and birthday celebrations with a personal touch.</p>
            </div>

            <div class="value-card reveal" style="transition-delay: 0.2s">
                <span style="font-size: 2.5rem;">🍽</span>
                <h3 class="my-4">Outdoor Event</h3>
                <p class="text-sm text-gray-600">Intimate gatherings and birthday celebrations with a personal touch.</p>
            </div>

            <div class="value-card reveal" style="transition-delay: 0.2s">
                <span style="font-size: 2.5rem;">🎂</span>
                <h3 class="my-4">Birthday Parties</h3>
                <p class="text-sm text-gray-600">Intimate gatherings and birthday celebrations with a personal touch.</p>
            </div>
        </div>
    </div>
</section>

<!-- Section 4: Our Food Specialities -->
<section class="py-24 bg-white">
    <div class="container">
        <div class="text-center mb-16 reveal">
            <h2 style="font-size: 2.5rem; font-weight: 800;">Our Specialities</h2>
            <p class="text-gray-600">A fusion of traditional roots and modern culinary art.</p>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div class="speciality-card reveal">
                <img src="<?php echo e(asset('images/traditional_thali.png')); ?>" alt="Traditional Indian">
                <div class="speciality-overlay">
                    <h4>Traditional Thali</h4>
                </div>
            </div>
            <div class="speciality-card reveal" style="transition-delay: 0.1s">
                <img src="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?q=80&w=2080&auto=format&fit=crop" alt="Continental">
                <div class="speciality-overlay">
                    <h4>Gourmet Salads</h4>
                </div>
            </div>
            <div class="speciality-card reveal" style="transition-delay: 0.2s">
                <img src="https://images.unsplash.com/photo-1512621776951-a57141f2eefd?q=80&w=2070&auto=format&fit=crop" alt="Chinese">
                <div class="speciality-overlay">
                    <h4>Asian Fusion</h4>
                </div>
            </div>
            <div class="speciality-card reveal" style="transition-delay: 0.3s">
                <img src="https://images.unsplash.com/photo-1551024601-bec78aea704b?q=80&w=1964&auto=format&fit=crop" alt="Desserts">
                <div class="speciality-overlay">
                    <h4>Signature Sweets</h4>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Section 5: Why Choose Us -->
<section class="py-24 bg-gray-50">
    <div class="container">
        <div class="text-center mb-16 reveal">
            <h2 style="font-size: 2.5rem; font-weight: 800;">Why Choose Us</h2>
            <p class="text-gray-600">The standards that set us apart in the industry.</p>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div class="flex gap-6 mb-12 reveal">
                <div style="font-size: 2.5rem; color: var(--gala-orange);">✨</div>
                <div>
                    <h3 class="mb-2">Obsessive Quality</h3>
                    <p class="text-gray-600">We source only the freshest organic ingredients and maintain the highest hygiene standards.</p>
                </div>
            </div>
            <div class="flex gap-6 mb-12 reveal" style="transition-delay: 0.1s">
                <div style="font-size: 2.5rem; color: var(--gala-orange);">👨‍🍳</div>
                <div>
                    <h3 class="mb-2">Expert Chefs</h3>
                    <p class="text-gray-600">Our culinary team consists of award-winning chefs with global experience.</p>
                </div>
            </div>
            <div class="flex gap-6 mb-12 reveal" style="transition-delay: 0.2s">
                <div style="font-size: 2.5rem; color: var(--gala-orange);">📋</div>
                <div>
                    <h3 class="mb-2">Customized Menus</h3>
                    <p class="text-gray-600">We don't believe in one-size-fits-all. Every menu is tailored to your taste and budget.</p>
                </div>
            </div>
            <div class="flex gap-6 mb-12 reveal" style="transition-delay: 0.3s">
                <div style="font-size: 2.5rem; color: var(--gala-orange);">🤝</div>
                <div>
                    <h3 class="mb-2">Full-Service Staff</h3>
                    <p class="text-gray-600">Professional waiters, cleaners, and coordinators to handle every detail of your event.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Section 6: Our Team -->
<section class="py-24 bg-white">
    <div class="container">
        <div class="text-center mb-16 reveal">
            <h2 style="font-size: 2.5rem; font-weight: 800;">Meet Our Experts</h2>
            <p class="text-gray-600">The dedicated professionals making your events spectacular.</p>
        </div>
        <div class="team-grid">
            <div class="team-card reveal">
                <div class="team-image-wrapper">
                    <img src="<?php echo e(asset('images/amit_varma.png')); ?>" alt="Executive Chef">
                </div>
                <h4 class="mb-1">Amit Varma</h4>
                <span class="team-role">Executive & Founder</span>
                <p class="text-sm text-gray-500 mt-4 px-6">Visionary leader with 15+ years in culinary arts.</p>
            </div>
            <div class="team-card reveal" style="transition-delay: 0.1s">
                <div class="team-image-wrapper">
                    <img src="<?php echo e(asset('images/rajesh_solanki.png')); ?>" alt="Head Chef">
                </div>
                <h4 class="mb-1">Rajesh Solanki</h4>
                <span class="team-role">Head Chef</span>
                <p class="text-sm text-gray-500 mt-4 px-6">Master of fusion cuisines and traditional spices.</p>
            </div>
            <div class="team-card reveal" style="transition-delay: 0.2s">
                <div class="team-image-wrapper">
                    <img src="https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?q=80&w=800&auto=format&fit=crop" alt="Event Manager">
                </div>
                <h4 class="mb-1">Priya Mehta</h4>
                <span class="team-role">Events Coordinator</span>
                <p class="text-sm text-gray-500 mt-4 px-6">Ensuring every event runs like clockwork.</p>
            </div>
            <div class="team-card reveal" style="transition-delay: 0.3s">
                <div class="team-image-wrapper">
                    <img src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=800&auto=format&fit=crop" alt="Service Head">
                </div>
                <h4 class="mb-1">Vikram Singh</h4>
                <span class="team-role">Operations Manager</span>
                <p class="text-sm text-gray-500 mt-4 px-6">Logistics and quality control expert.</p>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\catering-services-app\resources\views/about.blade.php ENDPATH**/ ?>