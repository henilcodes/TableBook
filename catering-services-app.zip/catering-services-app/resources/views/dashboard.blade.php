@extends('layouts.app')

@section('title', 'Customer Portal')

@section('content')
<section class="hero-section" style="padding: 60px 0;">
    <div class="container reveal">
        <h1>
            Customer <span class="accent">Portal</span>
        </h1>
        <p class="hero-description" style="max-width: 100%;">Manage your events, invoices, and menus in one place.</p>
    </div>
</section>

<!-- Statistics Overview -->
<div class="container py-8 reveal">
    <div class="stats-grid">
        <div class="card stat-card" style="background: white; border-radius: 1.5rem; padding: 2rem;">
            <span class="stat-label" style="color: #64748b; font-size: 0.875rem;">Total Bookings</span>
            <h3 class="stat-value" style="font-size: 2.5rem; margin: 0.5rem 0; color: var(--text-main);">{{ $bookings->count() }}</h3>
            <p style="margin: 0; color: #10b981; font-size: 0.875rem; font-weight: 600;">Active Accounts</p>
        </div>
        <div class="card stat-card" style="background: white; border-radius: 1.5rem; padding: 2rem;">
            <span class="stat-label" style="color: #64748b; font-size: 0.875rem;">Menu Requests</span>
            <h3 class="stat-value" style="font-size: 2.5rem; margin: 0.5rem 0; color: var(--text-main);">{{ $customMenuRequests->count() }}</h3>
            <p style="margin: 0; color: var(--gala-orange); font-size: 0.875rem; font-weight: 600;">Pending Feedback</p>
        </div>
        <div class="card stat-card" style="background: var(--primary); border-radius: 1.5rem; padding: 2rem; color: white;">
            <span class="stat-label" style="color: rgba(255,255,255,0.8); font-size: 0.875rem;">Next Event</span>
            @php $nextBooking = $bookings->where('status', 'confirmed')->first(); @endphp
            <h3 class="stat-value" style="font-size: 1.5rem; margin: 0.5rem 0;">{{ $nextBooking ? $nextBooking->event_start_date->format('M d, Y') : 'No upcoming' }}</h3>
            <p style="margin: 0; opacity: 0.9; font-size: 0.875rem;">{{ $nextBooking ? $nextBooking->event_type : 'Schedule now' }}</p>
        </div>
    </div>
</div>

<div class="container py-12 reveal">
    <div class="dashboard-layout" style="display: grid; grid-template-columns: 2fr 1fr; gap: 3rem; align-items: start;">
        
        <!-- Main Content: My Bookings -->
        <div class="bookings-section">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                <h2 style="margin:0; font-size: 1.75rem;">My <span class="accent">Events</span></h2>
                <div style="display: flex; gap: 1rem;">
                    <a href="{{ route('profile.edit') }}" class="btn-outline" style="padding: 0.6rem 1.25rem; font-size: 0.875rem; text-decoration: none;">⚙️ Settings</a>
                    <a href="{{ url('/packages') }}" class="btn-primary" style="padding: 0.6rem 1.25rem; font-size: 0.875rem;">New Booking</a>
                </div>
            </div>

            @if($bookings->isEmpty())
                <div class="feature-card" style="text-align: center; padding: 4rem 2rem;">
                    <div style="font-size: 3rem; margin-bottom: 1rem;">📅</div>
                    <h3>No Bookings Yet</h3>
                    <p style="color: #64748b; margin-bottom: 2rem;">Ready to host a memorable event? Explore our packages below.</p>
                    <a href="{{ url('/packages') }}" class="btn-primary">Explore Packages</a>
                </div>
            @else
                @foreach($bookings as $booking)
                <div class="feature-card" style="padding: 1.5rem; margin-bottom: 1.5rem; border: 1px solid var(--border-color); position: relative; {{ $booking->status == 'cancelled' ? 'opacity: 0.7; grayscale(0.5);' : '' }}">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1.5rem;">
                        <div>
                            <div style="font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.05em; color: var(--primary); font-weight: 700; margin-bottom: 0.25rem;">
                                {{ $booking->event_type }}
                            </div>
                            <h3 style="margin: 0; font-size: 1.25rem;">{{ $booking->event_start_date->format('l, F j, Y') }}</h3>
                            <p style="margin: 0.25rem 0 0; color: #64748b; font-size: 0.875rem;">{{ $booking->venue_address }} • {{ $booking->guest_count }} Guests</p>
                        </div>
                        <div style="text-align: right;">
                            <span class="badge badge-{{ $booking->status == 'confirmed' ? 'success' : ($booking->status == 'pending' ? 'warning' : ($booking->status == 'cancelled' ? 'danger' : 'secondary')) }}" style="padding: 0.4rem 0.8rem; border-radius: 8px; font-size: 0.75rem; font-weight: 700; text-transform: uppercase;">
                                {{ $booking->status }}
                            </span>
                            <div style="margin-top: 0.5rem; font-weight: 700; color: var(--text-main);">
                                Rs. {{ number_format($booking->total_amount) }}
                            </div>
                        </div>
                    </div>

                    <div style="display: flex; gap: 1rem; align-items: center; border-top: 1px solid #f1f5f9; padding-top: 1.25rem;">
                        <div style="flex-grow: 1;">
                            <div style="display: flex; align-items: center; gap: 0.5rem; font-size: 0.8125rem;">
                                <span style="color: #64748b;">Payment Status:</span>
                                <span style="font-weight: 600; color: {{ $booking->payment_status == 'fully_paid' ? '#10b981' : '#f59e0b' }};">
                                    {{ str_replace('_', ' ', strtoupper($booking->payment_status)) }}
                                </span>
                            </div>
                        </div>
                        
                        @if($booking->status == 'confirmed' && $booking->payment_status != 'fully_paid')
                        <div x-data="{ openPay: false, payMethod: '' }">
                            <button @click="openPay = !openPay" class="btn-primary" style="padding: 0.5rem 1rem; font-size: 0.8125rem;">Pay Now</button>
                            
                            <!-- Payment Options Modal/Dropdown -->
                            <div x-show="openPay" x-transition class="payment-options" style="margin-top: 1rem; padding: 1.5rem; background: #ffffff; border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1); position: absolute; z-index: 10; right: 0; min-width: 300px;">
                                <h4 style="margin: 0 0 1.25rem; font-size: 1rem; font-weight: 700;">Select Payment Method</h4>
                                
                                <div style="display: flex; flex-direction: column; gap: 1rem;">
                                    <!-- QR Scan Option -->
                                    <div style="border: 1px solid #eef2ff; border-radius: 8px; padding: 1rem;">
                                        <label style="display: flex; align-items: flex-start; gap: 0.75rem; cursor: pointer; margin-bottom: 0;">
                                            <input type="radio" x-model="payMethod" value="qr_scan" style="margin-top: 0.25rem;">
                                            <div style="text-align: left;">
                                                <div style="font-weight: 700; font-size: 0.9rem;">Pay via UPI / QR Scan</div>
                                                <div style="font-size: 0.75rem; color: #64748b;">Instant payment via GPay, PhonePe, or Paytm</div>
                                            </div>
                                        </label>
                                        
                                        <div x-show="payMethod == 'qr_scan'" x-collapse style="margin-top: 1rem; text-align: center;">
                                            <p style="font-size: 0.8125rem; background: #eef2ff; color: var(--primary); padding: 0.5rem; border-radius: 6px; margin-bottom: 1rem;">
                                                Scan the QR code below and pay <strong>Rs. {{ number_format($booking->total_amount) }}</strong>
                                            </p>
                                            <img src="{{ asset('images/scanner.jpeg') }}" alt="QR Scanner" style="max-width: 100%; border-radius: 12px; border: 4px solid #f8fafc; margin-bottom: 1rem;">
                                            
                                            <form action="{{ route('bookings.pay', $booking) }}" method="POST">
                                                @csrf
                                                <input type="hidden" name="payment_method" value="qr_scan">
                                                <button type="submit" class="btn-primary" style="width: 100%; padding: 0.75rem;">I Have Completed Payment</button>
                                            </form>
                                        </div>
                                    </div>

                                    <!-- Offline Option -->
                                    <div style="border: 1px solid #f8fafc; border-radius: 8px; padding: 1rem;">
                                        <label style="display: flex; align-items: flex-start; gap: 0.75rem; cursor: pointer; margin-bottom: 0;">
                                            <input type="radio" x-model="payMethod" value="offline" style="margin-top: 0.25rem;">
                                            <div style="text-align: left;">
                                                <div style="font-weight: 700; font-size: 0.9rem;">Pay at Office</div>
                                                <div style="font-size: 0.75rem; color: #64748b;">Visit us and pay by cash or card</div>
                                            </div>
                                        </label>
                                        
                                        <div x-show="payMethod == 'offline'" x-collapse style="margin-top: 1rem;">
                                            <form action="{{ route('bookings.pay', $booking) }}" method="POST">
                                                @csrf
                                                <input type="hidden" name="payment_method" value="offline">
                                                <button type="submit" class="btn-outline" style="width: 100%; padding: 0.75rem;">Request Offline Payment</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endif

                        @if($booking->status == 'pending')
                        <form action="{{ route('bookings.cancel', $booking) }}" method="POST" onsubmit="return confirm('Are you sure you want to cancel this booking?')">
                            @csrf
                            <button type="submit" class="btn-outline" style="padding: 0.5rem 1rem; font-size: 0.8125rem; color: #ef4444; border-color: #fecaca;">Cancel Booking</button>
                        </form>
                        @endif
                        
                        <a href="#" class="btn-outline" style="padding: 0.5rem 1rem; font-size: 0.8125rem;">View Details</a>
                    </div>
                </div>
                @endforeach
            @endif
        </div>

        <!-- Sidebar: Custom Menu Requests -->
        <div class="requests-section">
            <h2 style="margin-bottom: 2rem; font-size: 1.75rem;">Custom <span class="accent">Menus</span></h2>
            
            @if($customMenuRequests->isEmpty())
                <div class="feature-card" style="text-align: center; padding: 2rem;">
                    <p style="color: #64748b; font-size: 0.875rem;">No menu requests yet.</p>
                    <a href="{{ url('/menu') }}" style="color: var(--primary); font-size: 0.875rem; font-weight: 600; text-decoration: none;">Create Custom Menu →</a>
                </div>
            @else
                @foreach($customMenuRequests as $request)
                <div class="feature-card" style="padding: 1.25rem; margin-bottom: 1rem; border: 1px solid var(--border-color); border-left: 4px solid {{ $request->status == 'provided' ? '#10b981' : ($request->status == 'pending' ? '#f59e0b' : '#ef4444') }};">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.75rem;">
                        <span style="font-weight: 700; font-size: 0.875rem;">Request #{{ $request->id }}</span>
                        <span style="font-size: 0.75rem; color: #64748b;">{{ $request->created_at->diffForHumans() }}</span>
                    </div>
                    <div style="font-size: 0.875rem; font-weight: 600; color: var(--text-main);">
                        Status: <span style="color: {{ $request->status == 'provided' ? '#10b981' : ($request->status == 'pending' ? '#f59e0b' : '#ef4444') }};">{{ ucfirst($request->status) }}</span>
                    </div>
                    @if($request->admin_comment)
                        <div style="margin-top: 0.75rem; padding: 0.75rem; background: #f1f5f9; border-radius: 8px; font-size: 0.8125rem; color: #475569;">
                            <strong>Admin Note:</strong> {{ $request->admin_comment }}
                        </div>
                    @endif
                </div>
                @endforeach
            @endif
        </div>
    </div>
</div>

<style>
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 2rem;
    }
    .badge-success { background-color: #dcfce7; color: #166534; }
    .badge-warning { background-color: #fef9c3; color: #854d0e; }
    .badge-danger { background-color: #fee2e2; color: #991b1b; }
</style>
@endsection
