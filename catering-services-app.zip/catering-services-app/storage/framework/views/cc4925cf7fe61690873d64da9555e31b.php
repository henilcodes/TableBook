<?php $__env->startSection('title', 'Corporate Packages'); ?>

<?php $__env->startSection('content'); ?>
<!-- Hero -->
<section class="about-hero" style="background-image: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url('https://images.unsplash.com/photo-1505373633560-fa5a52865463?q=80&w=2070&auto=format&fit=crop');">
    <div class="container text-center reveal">
        <a href="<?php echo e(url('/packages')); ?>" style="color: var(--gala-orange); font-weight: 700; text-decoration: none; margin-bottom: 2rem; display: inline-block;">← Back to All Categories</a>
        <h1 class="text-white mb-6">Corporate <span class="accent">Dining Solutions</span></h1>
        <p class="text-white opacity-90 max-w-2xl mx-auto text-lg">
            Professional, timely, and delicious catering solutions for your business events and office needs.
        </p>
    </div>
</section>

<div class="container py-24">
    <div class="max-w-5xl mx-auto" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 2rem;">
        <!-- Basic -->
        <div class="package-column reveal">
            <div class="package-column-header tier-basic text-white">
                <h3 class="text-white">Office Lunch</h3>
                <span class="text-white" style="opacity: 0.8; font-size: 0.9rem;">Daily Essentials</span>
            </div>
            <div class="package-column-features">
                <ul class="package-features">
                    <li>Nutritious Thali</li>
                    <li>Beverage (Tea/Juice)</li>
                </ul>
                <ul class="package-features">
                    <li>Disposable Setup</li>
                    <li>Timely Delivery</li>
                </ul>
            </div>
            <div class="package-column-action">
                <div class="price-tag" style="margin:0; color: var(--text-main);">Rs. 200 <span style="font-size: 0.8rem;">/plate</span></div>
                <a href="<?php echo e(route('bookings.create')); ?>" class="btn-secondary-sm">Book Now</a>
            </div>
        </div>

        <!-- Standard -->
        <div class="package-column reveal" style="transition-delay: 0.1s">
            <div class="package-column-header tier-standard text-white">
                <h3 class="text-white">Seminar Snack</h3>
                <span class="text-white" style="opacity: 0.8; font-size: 0.9rem;">Networking Bites</span>
            </div>
            <div class="package-column-features">
                <ul class="package-features">
                    <li>High-Tea Assortment</li>
                    <li>Cookies & Pastries</li>
                </ul>
                <ul class="package-features">
                    <li>Coffee Station</li>
                    <li>Buffet Presentation</li>
                </ul>
            </div>
            <div class="package-column-action">
                <div class="price-tag" style="margin:0; color: var(--text-main);">Rs. 350 <span style="font-size: 0.8rem;">/plate</span></div>
                <a href="<?php echo e(route('bookings.create')); ?>" class="btn-secondary-sm">Book Now</a>
            </div>
        </div>

        <!-- Premium -->
        <div class="package-column reveal" style="transition-delay: 0.2s">
            <div class="package-column-header tier-premium text-white">
                <h3 class="text-white">Annual Meet</h3>
                <span class="text-white" style="opacity: 0.8; font-size: 0.9rem;">Corporate Celebration</span>
            </div>
            <div class="package-column-features">
                <ul class="package-features">
                    <li>Gourmet Indian Buffet</li>
                    <li>Fresh Fruit Platter</li>
                </ul>
                <ul class="package-features">
                    <li>Mineral Water/Sodas</li>
                    <li>Professional Crew</li>
                </ul>
            </div>
            <div class="package-column-action">
                <div class="price-tag" style="margin:0; color: var(--text-main);">Rs. 600 <span style="font-size: 0.8rem;">/plate</span></div>
                <a href="<?php echo e(route('bookings.create')); ?>" class="btn-secondary-sm">Book Now</a>
            </div>
        </div>

        <!-- Luxury -->
        <div class="package-column reveal" style="transition-delay: 0.3s">
            <div class="package-column-header tier-luxury text-white">
                <h3 class="text-white">VIP Retreat</h3>
                <span class="text-white" style="opacity: 0.8; font-size: 0.9rem;">Executive Grade</span>
            </div>
            <div class="package-column-features">
                <ul class="package-features">
                    <li>Organic Fusion Menu</li>
                    <li>Health Shot Bar</li>
                </ul>
                <ul class="package-features">
                    <li>Exquisite Crockery</li>
                    <li>Event Coordination</li>
                </ul>
            </div>
            <div class="package-column-action">
                <div class="price-tag" style="margin:0; color: var(--text-main);">Rs. 1000 <span style="font-size: 0.8rem;">/plate</span></div>
                <a href="<?php echo e(route('bookings.create')); ?>" class="btn-secondary-sm">Book Now</a>
            </div>
        </div>
    </div>

    <!-- Comparison Section -->
    <div class="comparison-section reveal">
        <div class="text-center mb-12">
            <h2 class="text-4xl font-bold mb-4">Corporate Package <span class="accent">Comparison</span></h2>
            <p class="text-gray-600">Tailored catering solutions for your business success.</p>
        </div>

        <div class="comparison-table-wrapper">
            <table class="comparison-table">
                <thead>
                    <tr>
                        <th class="feature-label">Features</th>
                        <th>Office Lunch</th>
                        <th>Seminar Snack</th>
                        <th>Annual Meet</th>
                        <th>VIP Retreat</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="feature-label">Menu Type</td>
                        <td>Daily Indian Thali</td>
                        <td>High-Tea Assortment</td>
                        <td>Gourmet Buffet</td>
                        <td>Organic Fusion</td>
                    </tr>
                    <tr>
                        <td class="feature-label">Beverages</td>
                        <td>Tea/Coffee/Juice</td>
                        <td>Interactive Coffee Stn</td>
                        <td>Wide Assortment</td>
                        <td>Premium Health Shots</td>
                    </tr>
                    <tr>
                        <td class="feature-label">Presentation</td>
                        <td>Disposable Kits</td>
                        <td>Buffet Display</td>
                        <td>Professional Setup</td>
                        <td>Exquisite Crockery</td>
                    </tr>
                    <tr>
                        <td class="feature-label">Service Staff</td>
                        <td>Delivery Only</td>
                        <td>1 Staff Member</td>
                        <td>Professional Crew</td>
                        <td>Event Manager on-site</td>
                    </tr>
                    <tr>
                        <td class="feature-label">Timeliness</td>
                        <td>Express Delivery</td>
                        <td>Setup 30m Prior</td>
                        <td>Full Coordination</td>
                        <td>Dedicated Timeline</td>
                    </tr>
                    <tr>
                        <td class="feature-label">Price per Plate</td>
                        <td class="font-bold">Rs. 200</td>
                        <td class="font-bold">Rs. 350</td>
                        <td class="font-bold">Rs. 600</td>
                        <td class="font-bold">Rs. 1000</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\catering-services-app\resources\views/packages/corporate.blade.php ENDPATH**/ ?>