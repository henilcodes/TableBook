<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('bookings', function (Blueprint $table) {
            $table->date('event_start_date')->after('event_detail')->nullable();
            $table->date('event_end_date')->after('event_start_date')->nullable();
            $table->dropColumn('event_date');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('bookings', function (Blueprint $table) {
            $table->date('event_date')->after('event_detail')->nullable();
            $table->dropColumn(['event_start_date', 'event_end_date']);
        });
    }
};
