<?php $__env->startSection('header', 'Dashboard Overview'); ?>

<?php $__env->startSection('content'); ?>
<div class="stats-grid">
    <div class="card stat-card">
        <span class="stat-label">Total Revenue</span>
        <h3 class="stat-value">Rs. <?php echo e(number_format($stats['total_revenue'])); ?></h3>
        <div class="stat-trend trend-up">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline></svg>
            <span>12.5% VS last month</span>
        </div>
    </div>
    <div class="card stat-card">
        <span class="stat-label">Monthly Income</span>
        <h3 class="stat-value">Rs. <?php echo e(number_format($stats['monthly_income'])); ?></h3>
        <div class="stat-trend trend-up">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline></svg>
            <span>8.2% VS last month</span>
        </div>
    </div>
    <div class="card stat-card">
        <span class="stat-label">Total Savings</span>
        <h3 class="stat-value">Rs. <?php echo e(number_format($stats['total_savings'])); ?></h3>
        <div class="stat-trend trend-up">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline></svg>
            <span>5.4% VS last month</span>
        </div>
    </div>
</div>

<div class="card" style="margin-bottom: 2rem;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
        <h3 style="margin: 0;">Earning Summary</h3>
        <div style="display: flex; gap: 0.5rem;">
            <button class="btn btn-outline" style="font-size: 0.75rem;">Monthly</button>
            <button class="btn btn-primary" style="font-size: 0.75rem;">Yearly</button>
        </div>
    </div>
    <div style="height: 300px;">
        <canvas id="earningChart"></canvas>
    </div>
</div>

<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 2rem; align-items: start;">
    <!-- Recent Transactions -->
    <div class="card">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
            <h3 style="margin: 0;">Recent Transactions</h3>
            <a href="<?php echo e(route('admin.bookings.index')); ?>" class="btn btn-outline" style="font-size: 0.75rem;">View All</a>
        </div>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Customer</th>
                        <th>Date</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Payment</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $stats['recent_bookings']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <div style="display: flex; align-items: center; gap: 0.75rem;">
                                <div class="user-avatar" style="width: 28px; height: 28px; font-size: 0.7rem;"><?php echo e(substr($booking->user->name, 0, 1)); ?></div>
                                <span><?php echo e($booking->user->name); ?></span>
                            </div>
                        </td>
                        <td><?php echo e($booking->event_start_date ? $booking->event_start_date->format('M d, Y') : 'N/A'); ?></td>
                        <td>Rs. <?php echo e(number_format($booking->total_amount)); ?></td>
                        <td>
                            <span class="badge badge-<?php echo e($booking->status == 'confirmed' ? 'success' : ($booking->status == 'pending' ? 'warning' : 'danger')); ?>">
                                <?php echo e(ucfirst($booking->status)); ?>

                            </span>
                        </td>
                        <td>
                            <form action="<?php echo e(route('admin.bookings.update_payment', $booking)); ?>" method="POST" style="display: flex; align-items: center; gap: 0.25rem;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <select name="payment_status" onchange="this.form.submit()" style="font-size: 0.7rem; border: none; background: <?php echo e($booking->payment_status == 'fully_paid' ? '#dcfce7' : ($booking->payment_status == 'advance_paid' ? '#e0f2fe' : '#fef9c3')); ?>; color: <?php echo e($booking->payment_status == 'fully_paid' ? '#166534' : ($booking->payment_status == 'advance_paid' ? '#0369a1' : '#854d0e')); ?>; padding: 0.2rem 0.4rem; border-radius: 6px; font-weight: 700; cursor: pointer;">
                                    <option value="pending" <?php echo e($booking->payment_status == 'pending' ? 'selected' : ''); ?>>PENDING</option>
                                    <option value="advance_paid" <?php echo e($booking->payment_status == 'advance_paid' ? 'selected' : ''); ?>>ADVANCE</option>
                                    <option value="fully_paid" <?php echo e($booking->payment_status == 'fully_paid' ? 'selected' : ''); ?>>PAID</option>
                                </select>
                            </form>
                        </td>
                        <td>
                            <a href="<?php echo e(route('admin.bookings.show', $booking)); ?>" class="btn btn-outline" style="padding: 0.2rem 0.4rem; font-size: 0.7rem;">Details</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- User Activity Feed -->
    <div class="card">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
            <h3 style="margin: 0;">User Activity</h3>
            <a href="<?php echo e(route('admin.activities')); ?>" class="btn btn-outline" style="font-size: 0.75rem;">View All</a>
        </div>
        <div class="activity-feed">
            <?php $__currentLoopData = $stats['activities']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="activity-item">
                <div class="activity-icon-wrapper">
                    <div class="activity-icon" style="background-color: var(--<?php echo e($activity['color']); ?>-light, <?php echo e($activity['color'] == 'green' ? '#dcfce7' : ($activity['color'] == 'blue' ? '#e0f2fe' : '#ffedd5')); ?>); color: var(--<?php echo e($activity['color']); ?>, <?php echo e($activity['color'] == 'green' ? '#16a34a' : ($activity['color'] == 'blue' ? '#0284c7' : '#ea580c')); ?>);">
                        <?php echo e($activity['icon']); ?>

                    </div>
                    <?php if(!$loop->last): ?>
                    <div class="activity-line"></div>
                    <?php endif; ?>
                </div>
                <div class="activity-content">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                        <span style="font-weight: 600; font-size: 0.875rem; color: var(--text-main);"><?php echo e($activity['user_name']); ?></span>
                        <span style="font-size: 0.75rem; color: var(--text-muted);"><?php echo e($activity['time']->diffForHumans()); ?></span>
                    </div>
                    <p style="margin: 0.1rem 0 0; font-size: 0.8125rem; color: var(--text-muted);"><?php echo e($activity['description']); ?></p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<style>
    .activity-feed {
        display: flex;
        flex-direction: column;
        gap: 1.25rem;
    }
    .activity-item {
        display: flex;
        gap: 1rem;
    }
    .activity-icon-wrapper {
        display: flex;
        flex-direction: column;
        align-items: center;
        flex-shrink: 0;
    }
    .activity-icon {
        width: 32px;
        height: 32px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1rem;
        z-index: 1;
    }
    .activity-line {
        width: 2px;
        flex-grow: 1;
        background-color: #f1f5f9;
        margin-top: 0.5rem;
        margin-bottom: -0.75rem;
    }
    .activity-content {
        flex-grow: 1;
        padding-bottom: 0.5rem;
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const ctx = document.getElementById('earningChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                datasets: [{
                    label: 'Income',
                    data: [350, 320, 380, 420, 450, 430, 480, 410, 390, 440, 460, 490],
                    borderColor: '#4f46e5',
                    backgroundColor: 'rgba(79, 70, 229, 0.1)',
                    fill: true,
                    tension: 0.4,
                    borderWidth: 3,
                    pointRadius: 0,
                    pointHoverRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { borderDash: [5, 5], color: '#e2e8f0' },
                        ticks: { color: '#64748b', font: { family: 'Outfit' } }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { color: '#64748b', font: { family: 'Outfit' } }
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                }
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\catering-services-app\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>