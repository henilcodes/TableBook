<?php $__env->startSection('header'); ?>
    <div style="display: flex; align-items: center; gap: 1rem;">
        <a href="<?php echo e(route('admin.bookings.index')); ?>" class="btn btn-outline" style="padding: 0.5rem;">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"></polyline></svg>
        </a>
        <span>Booking #<?php echo e($booking->id); ?></span>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 1.5rem; align-items: start;">
    
    <!-- Main Info -->
    <div class="card">
        <h3 style="margin: 0 0 1.5rem; border-bottom: 1px solid var(--border); padding-bottom: 1rem;">Event Information</h3>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
            <div>
                <p style="font-size: 0.75rem; font-weight: 600; color: var(--text-muted); margin-bottom: 0.25rem; text-transform: uppercase;">Client Name</p>
                <p style="font-weight: 600;"><?php echo e($booking->full_name); ?></p>
            </div>
            <div>
                <p style="font-size: 0.75rem; font-weight: 600; color: var(--text-muted); margin-bottom: 0.25rem; text-transform: uppercase;">Event Type</p>
                <p style="font-weight: 600;"><span class="badge badge-warning" style="background-color: #fefcf1; color: #854d0e; border: 1px solid #fef08a;"><?php echo e(ucfirst($booking->event_type)); ?></span></p>
            </div>
            <div>
                <p style="font-size: 0.75rem; font-weight: 600; color: var(--text-muted); margin-bottom: 0.25rem; text-transform: uppercase;">Start Date</p>
                <p style="font-weight: 600;"><?php echo e(\Carbon\Carbon::parse($booking->event_start_date)->format('M d, Y')); ?></p>
            </div>
            <div>
                <p style="font-size: 0.75rem; font-weight: 600; color: var(--text-muted); margin-bottom: 0.25rem; text-transform: uppercase;">End Date</p>
                <p style="font-weight: 600;"><?php echo e(\Carbon\Carbon::parse($booking->event_end_date)->format('M d, Y')); ?></p>
            </div>
            <div>
                <p style="font-size: 0.75rem; font-weight: 600; color: var(--text-muted); margin-bottom: 0.25rem; text-transform: uppercase;">Time Slot</p>
                <p style="font-weight: 600;"><?php echo e($booking->start_time); ?> - <?php echo e($booking->end_time); ?></p>
            </div>
            <div>
                <p style="font-size: 0.75rem; font-weight: 600; color: var(--text-muted); margin-bottom: 0.25rem; text-transform: uppercase;">Guest Count</p>
                <p style="font-weight: 600;"><?php echo e($booking->guest_count); ?> Total</p>
                <p style="font-size: 0.7rem; color: var(--text-muted);">(A: <?php echo e($booking->adults_count); ?>, K: <?php echo e($booking->kids_count); ?>, V: <?php echo e($booking->vips_count); ?>)</p>
            </div>
        </div>
        <div style="margin-top: 2rem;">
            <p style="font-size: 0.75rem; font-weight: 600; color: var(--text-muted); margin-bottom: 0.25rem; text-transform: uppercase;">Venue Address</p>
            <p style="font-weight: 600;"><?php echo e($booking->venue_address); ?> (<?php echo e(ucfirst($booking->event_setting)); ?>)</p>
        </div>
        <div style="margin-top: 2rem;">
            <p style="font-size: 0.75rem; font-weight: 600; color: var(--text-muted); margin-bottom: 0.25rem; text-transform: uppercase;">Extra Details</p>
            <p style="font-size: 0.875rem; line-height: 1.6; color: var(--text-main);"><?php echo e($booking->event_detail ?: 'No additional instructions provided by the client.'); ?></p>
        </div>
    </div>

    <!-- Management Panels -->
    <div style="display: flex; flex-direction: column; gap: 1.5rem;">
        <!-- Status Card -->
        <div class="card" style="border-top: 4px solid var(--primary);">
            <h4 style="margin: 0 0 1rem;">Update Status</h4>
            <form action="<?php echo e(route('admin.bookings.update_status', $booking)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <select name="status" class="btn btn-outline" style="width: 100%; text-align: left; margin-bottom: 1rem; padding: 0.75rem;">
                    <option value="pending" <?php echo e($booking->status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                    <option value="confirmed" <?php echo e($booking->status == 'confirmed' ? 'selected' : ''); ?>>Confirmed</option>
                    <option value="completed" <?php echo e($booking->status == 'completed' ? 'selected' : ''); ?>>Completed</option>
                    <option value="cancelled" <?php echo e($booking->status == 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
                </select>
                <button type="submit" class="btn btn-primary" style="width: 100%; justify-content: center;">Update Status</button>
            </form>
        </div>

        <!-- Payment Card -->
        <div class="card" style="border-top: 4px solid var(--success);">
            <h4 style="margin: 0 0 1rem;">Payment & Billing</h4>
            <form action="<?php echo e(route('admin.bookings.update_payment', $booking)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <div style="margin-bottom: 1rem;">
                    <label style="font-size: 0.7rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 4px;">Total Quote (Rs.)</label>
                    <input type="number" name="total_amount" value="<?php echo e($booking->total_amount); ?>" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;" required>
                </div>
                <div style="margin-bottom: 1rem;">
                    <label style="font-size: 0.7rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 4px;">Advance Paid (Rs.)</label>
                    <input type="number" name="advance_amount" value="<?php echo e($booking->advance_amount); ?>" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;">
                </div>
                <div style="margin-bottom: 1rem;">
                    <label style="font-size: 0.7rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 4px;">Status</label>
                    <select name="payment_status" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;">
                        <option value="pending" <?php echo e($booking->payment_status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                        <option value="advance_paid" <?php echo e($booking->payment_status == 'advance_paid' ? 'selected' : ''); ?>>Advance Paid</option>
                        <option value="fully_paid" <?php echo e($booking->payment_status == 'fully_paid' ? 'selected' : ''); ?>>Fully Paid</option>
                    </select>
                </div>
                <div style="margin-bottom: 1.5rem;">
                    <label style="font-size: 0.7rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase; display: block; margin-bottom: 4px;">Payment Method</label>
                    <select name="payment_method" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;">
                        <option value="none" <?php echo e($booking->payment_method == 'none' ? 'selected' : ''); ?>>Select Method</option>
                        <option value="online" <?php echo e($booking->payment_method == 'online' ? 'selected' : ''); ?>>Online Payment</option>
                        <option value="offline" <?php echo e($booking->payment_method == 'offline' ? 'selected' : ''); ?>>Cash/Offline</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary" style="width: 100%; justify-content: center; background-color: var(--success);">Save Billing Info</button>
            </form>

            <div style="margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid var(--border);">
                <a href="<?php echo e(route('admin.bookings.receipt', $booking)); ?>" target="_blank" class="btn btn-outline" style="width: 100%; justify-content: center;">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9V2h12v7"></path><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>
                    Print Invoice
                </a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\catering-services-app\resources\views/admin/bookings/show.blade.php ENDPATH**/ ?>