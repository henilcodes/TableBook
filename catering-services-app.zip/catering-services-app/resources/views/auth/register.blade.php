@extends('layouts.app')

@section('title', 'Register')

@section('content')
<div class="auth-page">
    <div class="auth-card reveal">
        <div class="auth-header">
            <h2>Join Us</h2>
            <p class="hero-description" style="font-size: 0.9rem; margin-top: 0.5rem;">Create an account to start planning your events.</p>
        </div>

        <form action="{{ route('register') }}" method="POST" class="space-y-6">
            @csrf
            
            <div class="form-group">
                <label for="name" class="form-label">Full Name</label>
                <input id="name" name="name" type="text" value="{{ old('name') }}" required class="form-input" placeholder="Aasam Valvi">
            </div>

            <div class="form-group">
                <label for="email" class="form-label">Email Address</label>
                <input id="email" name="email" type="email" value="{{ old('email') }}" required class="form-input" placeholder="you@example.com">
                @error('email') <p class="mt-1 text-xs text-[#f53003]">{{ $message }}</p> @enderror
            </div>

            <div class="form-group">
                <label for="password" class="form-label">Password</label>
                <input id="password" name="password" type="password" required class="form-input" placeholder="••••••••">
                @error('password') <p class="mt-1 text-xs text-[#f53003]">{{ $message }}</p> @enderror
            </div>

            <div class="form-group">
                <label for="password_confirmation" class="form-label">Confirm Password</label>
                <input id="password_confirmation" name="password_confirmation" type="password" required class="form-input" placeholder="••••••••">
            </div>

            <div class="mt-8">
                <button type="submit" class="btn-primary w-full">Create Account</button>
            </div>
        </form>

        <div class="mt-8 text-center text-sm">
            <span style="color: var(--text-muted);">Already have an account?</span>
            <a href="{{ route('login') }}" style="color: var(--primary); text-decoration: none; font-weight: 600; margin-left: 0.25rem;">Sign In</a>
        </div>
    </div>
</div>
@endsection
