@extends('layouts.app')

@section('title', 'My Custom Menu Requests')

@section('content')
<div class="container py-24">
    <div class="max-w-4xl mx-auto">
        <div class="flex justify-between items-center mb-10">
            <h2 class="text-3xl font-bold">My <span class="accent">Custom Menus</span></h2>
            <a href="{{ route('custom_menu.create') }}" class="btn-primary-custom px-6 py-2 rounded-lg font-bold text-white transition-all hover:scale-105">
                New Request
            </a>
        </div>

        @if(session('success'))
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-6" role="alert">
                <span class="block sm:inline">{{ session('success') }}</span>
            </div>
        @endif

        <div class="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100 reveal">
            <table class="w-full text-left">
                <thead class="bg-gray-50 border-b border-gray-100 text-sm font-semibold text-gray-600 uppercase tracking-wider">
                    <tr>
                        <th class="px-6 py-4">Date</th>
                        <th class="px-6 py-4">Menu Details</th>
                        <th class="px-6 py-4">Status</th>
                        <th class="px-6 py-4 text-right">Action</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    @forelse($requests as $request)
                        <tr class="hover:bg-gray-50/50 transition-all">
                            <td class="px-6 py-4 text-sm text-gray-600">
                                {{ $request->created_at->format('M d, Y') }}
                            </td>
                            <td class="px-6 py-4">
                                <div class="max-w-xs truncate text-gray-800 font-medium">
                                    {{ $request->menu_details }}
                                </div>
                            </td>
                            <td class="px-6 py-4">
                                @if($request->status == 'pending')
                                    <span class="px-3 py-1 text-xs font-bold rounded-full bg-yellow-100 text-yellow-700">Pending</span>
                                @elseif($request->status == 'provided')
                                    <span class="px-3 py-1 text-xs font-bold rounded-full bg-green-100 text-green-700">Available</span>
                                @elseif($request->status == 'not_available')
                                    <span class="px-3 py-1 text-xs font-bold rounded-full bg-red-100 text-red-700">Not Available</span>
                                @endif
                            </td>
                            <td class="px-6 py-4 text-right">
                                <button onclick="showDetails({{ $request->id }})" class="text-accent hover:underline font-semibold">View Details</button>
                            </td>
                        </tr>
                        
                        <!-- Details Modal/Section Hidden by default -->
                        <div id="details-{{ $request->id }}" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
                            <div class="bg-white rounded-2xl max-w-xl w-full p-8 relative">
                                <button onclick="hideDetails({{ $request->id }})" class="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
                                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                                </button>
                                <h3 class="text-2xl font-bold mb-6">Menu Request Details</h3>
                                <div class="space-y-4">
                                    <div>
                                        <p class="text-sm font-bold text-gray-500 uppercase">Items Requested</p>
                                        <p class="text-gray-800 whitespace-pre-wrap">{{ $request->menu_details }}</p>
                                    </div>
                                    @if($request->additional_notes)
                                    <div>
                                        <p class="text-sm font-bold text-gray-500 uppercase">Additional Notes</p>
                                        <p class="text-gray-800 whitespace-pre-wrap">{{ $request->additional_notes }}</p>
                                    </div>
                                    @endif
                                    @if($request->admin_comment)
                                    <div class="p-4 bg-blue-50 rounded-xl border border-blue-100">
                                        <p class="text-sm font-bold text-blue-800 uppercase">Admin Feedback</p>
                                        <p class="text-blue-900">{{ $request->admin_comment }}</p>
                                    </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                    @empty
                        <tr>
                            <td colspan="4" class="px-6 py-10 text-center text-gray-500 italic">
                                You haven't submitted any custom menu requests yet.
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    function showDetails(id) {
        document.getElementById('details-' + id).classList.remove('hidden');
    }
    function hideDetails(id) {
        document.getElementById('details-' + id).classList.add('hidden');
    }
</script>

<style>
    .btn-primary-custom {
        background: linear-gradient(135deg, #ff6b6b, #ee5253);
    }
    .accent { color: #ff6b6b; }
</style>
@endsection
