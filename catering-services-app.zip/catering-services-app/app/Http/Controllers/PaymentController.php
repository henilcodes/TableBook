<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PaymentController extends Controller
{
    public function index()
    {
        return view('payment');
    }

    public function store(Request $request)
    {
        $status = $request->payment_status;

        return back()->with('success', 'Payment Status: ' . $status);
    }
}
