@extends('layouts.admin')

@section('header', 'Menu Items')

@section('content')
<div class="card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
        <h3 style="margin: 0;">Menu Item List</h3>
        <a href="{{ route('admin.menu_items.create') }}" class="btn btn-primary">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
            Add Menu Item
        </a>
    </div>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Item Name</th>
                    <th>Category</th>
                    <th>Type</th>
                    <th>Price</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach($menuItems as $item)
                <tr>
                    <td>
                        <div style="display: flex; align-items: center; gap: 1rem;">
                            @if($item->image)
                                <img src="{{ asset('storage/' . $item->image) }}" alt="" style="width: 40px; height: 40px; border-radius: 0.5rem; object-fit: cover;">
                            @else
                                <div style="width: 40px; height: 40px; border-radius: 0.5rem; background: #e2e8f0; display: flex; align-items: center; justify-content: center; color: #64748b;">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line></svg>
                                </div>
                            @endif
                            <span style="font-weight: 500;">{{ $item->name }}</span>
                        </div>
                    </td>
                    <td>{{ $item->category->name }}</td>
                    <td><span class="badge badge-success" style="background-color: #f0fdf4; color: #166534; border: 1px solid #bbf7d0;">{{ ucfirst($item->type) }}</span></td>
                    <td>Rs. {{ number_format($item->price) }}</td>
                    <td>
                        <div style="display: flex; gap: 0.5rem;">
                            <a href="{{ route('admin.menu_items.edit', $item) }}" class="btn btn-outline" style="padding: 0.5rem;">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
                            </a>
                            <form action="{{ route('admin.menu_items.destroy', $item) }}" method="POST" onsubmit="return confirm('Are you sure?')">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-outline" style="padding: 0.5rem; color: var(--danger); border-color: #fee2e2;">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    <div style="margin-top: 1.5rem;">
        {{ $menuItems->links() }}
    </div>
</div>
@endsection
