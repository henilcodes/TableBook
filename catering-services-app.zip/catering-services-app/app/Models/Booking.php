<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    protected $fillable = [
        'user_id',
        'full_name',
        'phone',
        'email',
        'event_type',
        'event_detail',
        'event_start_date',
        'event_end_date',
        'start_time',
        'end_time',
        'venue_address',
        'event_setting',
        'guest_count',
        'adults_count',
        'kids_count',
        'vips_count',
        'status',
        'total_amount',
        'advance_amount',
        'payment_status',
        'payment_method',
    ];

    protected $casts = [
        'event_start_date' => 'date',
        'event_end_date' => 'date',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
