<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    use HasFactory;

    protected $fillable = ['name', 'slug', 'description', 'image'];

    public function packages()
    {
        return $this->hasMany(Package::class);
    }

    public function menuItems()
    {
        return $this->hasMany(MenuItem::class);
    }
}
