<?php $__env->startSection('header', 'User Activity Feed'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
        <div>
            <h3 style="margin: 0;">Complete Activity Log</h3>
            <p style="margin: 0.25rem 0 0; color: var(--text-muted); font-size: 0.875rem;">Real-time stream of all platform interactions.</p>
        </div>
        <div style="display: flex; gap: 0.5rem;">
            <button class="btn btn-outline" style="font-size: 0.875rem;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"></polygon></svg>
                Filter
            </button>
            <button class="btn btn-primary" style="font-size: 0.875rem;">Export CSV</button>
        </div>
    </div>

    <div class="activity-timeline">
        <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="timeline-item">
            <div class="timeline-marker">
                <div class="marker-icon" style="background-color: var(--<?php echo e($activity['color']); ?>-light, <?php echo e($activity['color'] == 'green' ? '#dcfce7' : ($activity['color'] == 'blue' ? '#e0f2fe' : '#ffedd5')); ?>); color: var(--<?php echo e($activity['color']); ?>, <?php echo e($activity['color'] == 'green' ? '#16a34a' : ($activity['color'] == 'blue' ? '#0284c7' : '#ea580c')); ?>);">
                    <?php echo e($activity['icon']); ?>

                </div>
                <?php if(!$loop->last): ?>
                <div class="marker-line"></div>
                <?php endif; ?>
            </div>
            <div class="timeline-content">
                <div class="timeline-header">
                    <div class="user-info">
                        <span class="user-name"><?php echo e($activity['user_name']); ?></span>
                        <span class="activity-tag badge-<?php echo e($activity['color']); ?>"><?php echo e(ucfirst($activity['type'])); ?></span>
                    </div>
                    <span class="timeline-time"><?php echo e($activity['time']->format('M d, Y • h:i A')); ?> (<?php echo e($activity['time']->diffForHumans()); ?>)</span>
                </div>
                <div class="timeline-body">
                    <p><?php echo e($activity['description']); ?></p>
                </div>
                <?php if($activity['type'] == 'booking'): ?>
                <div class="timeline-actions">
                    <button class="btn-sm">View Booking Details</button>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<style>
    .activity-timeline {
        padding: 1rem 0;
    }
    .timeline-item {
        display: flex;
        gap: 1.5rem;
        margin-bottom: 0;
    }
    .timeline-marker {
        display: flex;
        flex-direction: column;
        align-items: center;
        width: 40px;
        flex-shrink: 0;
    }
    .marker-icon {
        width: 40px;
        height: 40px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
        z-index: 1;
        box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);
    }
    .marker-line {
        width: 2px;
        flex-grow: 1;
        background: linear-gradient(to bottom, #f1f5f9 0%, #f1f5f9 100%);
        margin: 0.5rem 0;
    }
    .timeline-content {
        flex-grow: 1;
        padding-bottom: 2.5rem;
    }
    .timeline-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 0.5rem;
    }
    .user-info {
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }
    .user-name {
        font-weight: 700;
        color: var(--text-main);
        font-size: 1rem;
    }
    .activity-tag {
        font-size: 0.7rem;
        text-transform: uppercase;
        font-weight: 700;
        letter-spacing: 0.025em;
        padding: 0.2rem 0.6rem;
        border-radius: 6px;
    }
    .badge-blue { background: #e0f2fe; color: #0284c7; }
    .badge-green { background: #dcfce7; color: #16a34a; }
    .badge-orange { background: #ffedd5; color: #ea580c; }
    
    .timeline-time {
        font-size: 0.8125rem;
        color: var(--text-muted);
    }
    .timeline-body p {
        margin: 0;
        color: var(--text-muted);
        line-height: 1.5;
        font-size: 0.9375rem;
    }
    .timeline-actions {
        margin-top: 1rem;
    }
    .btn-sm {
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        padding: 0.4rem 0.8rem;
        border-radius: 6px;
        font-size: 0.8125rem;
        font-weight: 500;
        color: #475569;
        cursor: pointer;
        transition: all 0.2s;
    }
    .btn-sm:hover {
        background: #f1f5f9;
        border-color: #cbd5e1;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\catering-services-app\resources\views/admin/activities/index.blade.php ENDPATH**/ ?>