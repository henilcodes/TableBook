<!DOCTYPE html>
<html>
<head>
    <title>Payment</title>
</head>
<body>

<h2>Catering Payment</h2>

<h3>Scan QR & Pay</h3>

<img src="{{ asset('scanner.jpeg') }}" width="200">

<form method="POST" action="/payment/store">
    @csrf

    <input type="hidden" name="payment_status" value="PAID ONLINE">

    <button type="submit">
        I Have Paid
    </button>
</form>

<br><br>

<form method="POST" action="/payment/store">
    @csrf

    <input type="hidden" name="payment_status" value="CASH PAYMENT">

    <button type="submit">
        Cash Payment
    </button>
</form>

@if(session('success'))
    <h3>{{ session('success') }}</h3>
@endif

</body>
</html>