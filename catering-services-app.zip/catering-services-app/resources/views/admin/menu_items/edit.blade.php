@extends('layouts.admin')

@section('header', 'Edit Menu Item')

@section('content')
<div class="card" style="max-width: 600px;">
    <form action="{{ route('admin.menu_items.update', $menuItem) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <div style="margin-bottom: 1.5rem;">
            <label style="display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5rem;">Category</label>
            <select name="category_id" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;" required>
                @foreach($categories as $category)
                    <option value="{{ $category->id }}" {{ $menuItem->category_id == $category->id ? 'selected' : '' }}>{{ $category->name }}</option>
                @endforeach
            </select>
        </div>

        <div style="margin-bottom: 1.5rem;">
            <label style="display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5rem;">Item Name</label>
            <input type="text" name="name" value="{{ $menuItem->name }}" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;" required>
        </div>

        <div style="margin-bottom: 1.5rem;">
            <label style="display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5rem;">Type</label>
            <select name="type" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;" required>
                <option value="main" {{ $menuItem->type == 'main' ? 'selected' : '' }}>Main Course</option>
                <option value="appetizer" {{ $menuItem->type == 'appetizer' ? 'selected' : '' }}>Appetizer</option>
                <option value="dessert" {{ $menuItem->type == 'dessert' ? 'selected' : '' }}>Dessert</option>
                <option value="drink" {{ $menuItem->type == 'drink' ? 'selected' : '' }}>Drink</option>
                <option value="snack" {{ $menuItem->type == 'snack' ? 'selected' : '' }}>Snack</option>
            </select>
        </div>

        <div style="margin-bottom: 1.5rem;">
            <label style="display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5rem;">Description</label>
            <textarea name="description" rows="3" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;">{{ $menuItem->description }}</textarea>
        </div>

        <div style="margin-bottom: 1.5rem;">
            <label style="display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5rem;">Price (Optional)</label>
            <input type="number" name="price" value="{{ $menuItem->price }}" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;">
        </div>

        <div style="margin-bottom: 2rem;">
            <label style="display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5rem;">Item Image</label>
            @if($menuItem->image)
                <div style="margin-bottom: 1rem;">
                    <img src="{{ asset('storage/' . $menuItem->image) }}" alt="" style="width: 100px; height: 100px; border-radius: 0.5rem; object-fit: cover;">
                </div>
            @endif
            <input type="file" name="image" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;">
        </div>

        <div style="display: flex; gap: 1rem;">
            <button type="submit" class="btn btn-primary">Update Item</button>
            <a href="{{ route('admin.menu_items.index') }}" class="btn btn-outline">Cancel</a>
        </div>
    </form>
</div>
@endsection
