@extends('layouts.admin')

@section('header', 'Edit Package')

@section('content')
<div class="card" style="max-width: 600px;">
    <form action="{{ route('admin.packages.update', $package) }}" method="POST">
        @csrf
        @method('PUT')
        <div style="margin-bottom: 1.5rem;">
            <label style="display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5rem;">Category</label>
            <select name="category_id" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;" required>
                @foreach($categories as $category)
                    <option value="{{ $category->id }}" {{ $package->category_id == $category->id ? 'selected' : '' }}>{{ $category->name }}</option>
                @endforeach
            </select>
        </div>

        <div style="margin-bottom: 1.5rem;">
            <label style="display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5rem;">Package Name</label>
            <input type="text" name="name" value="{{ $package->name }}" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;" required>
        </div>

        <div style="margin-bottom: 1.5rem;">
            <label style="display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5rem;">Description</label>
            <textarea name="description" rows="4" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;">{{ $package->description }}</textarea>
        </div>

        <div style="margin-bottom: 2rem;">
            <label style="display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5rem;">Price Per Plate (Rs.)</label>
            <input type="number" name="price_per_plate" value="{{ $package->price_per_plate }}" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;" required>
        </div>

        <div style="display: flex; gap: 1rem;">
            <button type="submit" class="btn btn-primary">Update Package</button>
            <a href="{{ route('admin.packages.index') }}" class="btn btn-outline">Cancel</a>
        </div>
    </form>
</div>
@endsection
