<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
<div class="auth-page">
    <div class="auth-card reveal">
        <div class="auth-header">
            <h2>Welcome Back</h2>
            <p class="hero-description" style="font-size: 0.9rem; margin-top: 0.5rem;">Sign in to manage your catering events.</p>
        </div>

        <form action="<?php echo e(route('login')); ?>" method="POST" class="space-y-6">
            <?php echo csrf_field(); ?>
            
            <div class="form-group">
                <label for="email" class="form-label">Email Address</label>
                <input id="email" name="email" type="email" required class="form-input" placeholder="you@example.com">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-xs text-[#f53003]"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="password" class="form-label">Password</label>
                <input id="password" name="password" type="password" required class="form-input" placeholder="••••••••">
            </div>

            <div class="flex justify-between items-center text-sm mt-4">
                <label class="flex items-center cursor-pointer">
                    <input id="remember" name="remember" type="checkbox" style="margin-right: 0.5rem;">
                    <span>Remember me</span>
                </label>
                <a href="#" style="color: var(--primary); text-decoration: none; font-weight: 500;">Forgot password?</a>
            </div>

            <div class="mt-8">
                <button type="submit" class="btn-primary w-full">Sign In</button>
            </div>
        </form>

        <div class="mt-8 text-center text-sm">
            <span style="color: var(--text-muted);">Don't have an account?</span>
            <a href="<?php echo e(route('register')); ?>" style="color: var(--primary); text-decoration: none; font-weight: 600; margin-left: 0.25rem;">Create Account</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\catering-services-app\resources\views/auth/login.blade.php ENDPATH**/ ?>