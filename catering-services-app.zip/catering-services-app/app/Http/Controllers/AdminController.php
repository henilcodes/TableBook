<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function index()
    {
        // Real metrics from the database
        $total_bookings = Booking::count();
        $total_revenue = Booking::where('payment_status', 'fully_paid')->sum('total_amount') + Booking::sum('advance_amount');
        
        // Combined Activity Feed
        $recent_users = \App\Models\User::latest()->take(5)->get()->map(function($user) {
            return [
                'type' => 'registration',
                'user_name' => $user->name,
                'description' => 'Registered a new account',
                'time' => $user->created_at,
                'icon' => '👤',
                'color' => 'blue'
            ];
        });

        $recent_bookings_activity = Booking::with('user')->latest()->take(5)->get()->map(function($booking) {
            return [
                'type' => 'booking',
                'user_name' => $booking->user->name ?? 'Guest',
                'description' => 'Placed a new booking: ' . ($booking->event_type ?? 'Catering'),
                'time' => $booking->created_at,
                'icon' => '📅',
                'color' => 'green'
            ];
        });

        $recent_requests = \App\Models\CustomMenuRequest::with('user')->latest()->take(5)->get()->map(function($request) {
            return [
                'type' => 'request',
                'user_name' => $request->user->name ?? 'User',
                'description' => 'Submitted a custom menu request',
                'time' => $request->created_at,
                'icon' => '👨‍🍳',
                'color' => 'orange'
            ];
        });

        $activities = $this->getRecentActivities(8);

        $stats = [
            'total_bookings' => $total_bookings,
            'total_revenue' => $total_revenue,
            'monthly_income' => $total_revenue * 0.4, // Placeholder
            'total_savings' => $total_revenue * 0.15, // Placeholder
            'active_customers' => \App\Models\User::count(),
            'recent_bookings' => Booking::with('user')->latest()->take(5)->get(),
            'activities' => $activities
        ];

        return view('admin.dashboard', compact('stats'));
    }

    public function activities()
    {
        $activities = $this->getRecentActivities(50); // Get more for the full page
        return view('admin.activities.index', compact('activities'));
    }

    private function getRecentActivities($limit = 10)
    {
        $recent_users = \App\Models\User::latest()->take($limit)->get()->map(function($user) {
            return [
                'type' => 'registration',
                'user_name' => $user->name,
                'description' => 'Registered a new account',
                'time' => $user->created_at,
                'icon' => '👤',
                'color' => 'blue'
            ];
        });

        $recent_bookings_activity = Booking::with('user')->latest()->take($limit)->get()->map(function($booking) {
            return [
                'type' => 'booking',
                'user_name' => $booking->user->name ?? 'Guest',
                'description' => 'Placed a new booking: ' . ($booking->event_type ?? 'Catering'),
                'time' => $booking->created_at,
                'icon' => '📅',
                'color' => 'green'
            ];
        });

        $recent_requests = \App\Models\CustomMenuRequest::with('user')->latest()->take($limit)->get()->map(function($request) {
            return [
                'type' => 'request',
                'user_name' => $request->user->name ?? 'User',
                'description' => 'Submitted a custom menu request',
                'time' => $request->created_at,
                'icon' => '👨‍🍳',
                'color' => 'orange'
            ];
        });

        return collect($recent_users)
            ->merge($recent_bookings_activity)
            ->merge($recent_requests)
            ->sortByDesc('time')
            ->take($limit);
    }

    public function payments()
    {
        $bookings = Booking::with('user')->latest()->paginate(15);
        
        $stats = [
            'total_revenue' => Booking::sum('total_amount'),
            'total_received' => Booking::sum('advance_amount'),
            'total_pending' => Booking::sum('total_amount') - Booking::sum('advance_amount'),
        ];

        return view('admin.payments.index', compact('bookings', 'stats'));
    }

    public function bookings()
    {
        $bookings = Booking::latest()->paginate(10);
        return view('admin.bookings.index', compact('bookings'));
    }

    public function showBooking(Booking $booking)
    {
        return view('admin.bookings.show', compact('booking'));
    }

    public function updateBookingStatus(Request $request, Booking $booking)
    {
        $request->validate([
            'status' => 'required|in:pending,confirmed,completed,cancelled'
        ]);

        $booking->update(['status' => $request->status]);

        return back()->with('success', 'Booking status updated successfully!');
    }

    public function updatePayment(Request $request, Booking $booking)
    {
        $request->validate([
            'total_amount' => 'sometimes|required|numeric|min:0',
            'advance_amount' => 'sometimes|nullable|numeric|min:0',
            'payment_status' => 'sometimes|required|in:pending,advance_paid,fully_paid',
            'payment_method' => 'sometimes|required|in:online,offline,none'
        ]);

        $booking->update($request->all());

        return back()->with('success', 'Payment information updated successfully!');
    }

    public function receipt(Booking $booking)
    {
        return view('admin.bookings.receipt', compact('booking'));
    }

    public function customMenus()
    {
        $requests = \App\Models\CustomMenuRequest::with('user')->latest()->paginate(10);
        return view('admin.custom_menus.index', compact('requests'));
    }

    public function updateCustomMenuStatus(Request $request, \App\Models\CustomMenuRequest $request_obj)
    {
        $request->validate([
            'status' => 'required|in:pending,provided,not_available',
            'admin_comment' => 'nullable|string'
        ]);

        // Fix the parameter name issue if needed. The route uses {request} but the variable is $request_obj
        // Actually Laravel usually resolves it by name, but I'll use the variable passed.
        $request_obj->update([
            'status' => $request->status,
            'admin_comment' => $request->admin_comment
        ]);

        return back()->with('success', 'Custom menu request status updated successfully!');
    }
}
