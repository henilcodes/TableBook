@extends('layouts.app')

@section('title', 'Party Packages')

@section('content')
<!-- Hero -->
<section class="about-hero" style="background-image: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url('https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?q=80&w=2070&auto=format&fit=crop');">
    <div class="container text-center reveal">
        <a href="{{ url('/packages') }}" style="color: var(--gala-orange); font-weight: 700; text-decoration: none; margin-bottom: 2rem; display: inline-block;">← Back to All Categories</a>
        <h1 class="text-white mb-6">Party <span class="accent">Event Catering</span></h1>
        <p class="text-white opacity-90 max-w-2xl mx-auto text-lg">
            Experience the joy of open-air dining with our specialized outdoor catering solutions.
        </p>
    </div>
</section>

<div class="container py-24">
    <div class="max-w-5xl mx-auto" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 2rem;">
        <!-- Basic -->
        <div class="package-column reveal">
            <div class="package-column-header tier-basic text-white">
                <h3 class="text-white">Garden Picnic</h3>
                <span class="text-white" style="opacity: 0.8; font-size: 0.9rem;">Casual Fun</span>
            </div>
            <div class="package-column-features">
                <ul class="package-features">
                    <li>Packed Box Meals</li>
                    <li>Fresh Lemonade</li>
                </ul>
                <ul class="package-features">
                    <li>Eco-Friendly Kits</li>
                    <li>Mat Setup Assistance</li>
                </ul>
            </div>
            <div class="package-column-action">
                <div class="price-tag" style="margin:0; color: var(--text-main);">Rs. 300 <span style="font-size: 0.8rem;">/plate</span></div>
                <a href="{{ route('bookings.create') }}" class="btn-secondary-sm">Book Now</a>
            </div>
        </div>

        <!-- Standard -->
        <div class="package-column reveal" style="transition-delay: 0.1s">
            <div class="package-column-header tier-standard text-white">
                <h3 class="text-white">Park Buffet</h3>
                <span class="text-white" style="opacity: 0.8; font-size: 0.9rem;">Themed Outdoor</span>
            </div>
            <div class="package-column-features">
                <ul class="package-features">
                    <li>Hot Food Warmers</li>
                    <li>Street Food Counter</li>
                </ul>
                <ul class="package-features">
                    <li>Shaded Dining Area</li>
                    <li>On-site Cleaning</li>
                </ul>
            </div>
            <div class="package-column-action">
                <div class="price-tag" style="margin:0; color: var(--text-main);">Rs. 550 <span style="font-size: 0.8rem;">/plate</span></div>
                <a href="{{ route('bookings.create') }}" class="btn-secondary-sm">Book Now</a>
            </div>
        </div>

        <!-- Premium -->
        <div class="package-column reveal" style="transition-delay: 0.2s">
            <div class="package-column-header tier-premium text-white">
                <h3 class="text-white">Beach BBQ</h3>
                <span class="text-white" style="opacity: 0.8; font-size: 0.9rem;">Sizzling Fun</span>
            </div>
            <div class="package-column-features">
                <ul class="package-features">
                    <li>Live Grilling Stn</li>
                    <li>Seafood Specialities</li>
                </ul>
                <ul class="package-features">
                    <li>Cooler Bar</li>
                    <li>Ambient Lighting</li>
                </ul>
            </div>
            <div class="package-column-action">
                <div class="price-tag" style="margin:0; color: var(--text-main);">Rs. 950 <span style="font-size: 0.8rem;">/plate</span></div>
                <a href="{{ route('bookings.create') }}" class="btn-secondary-sm">Book Now</a>
            </div>
        </div>

        <!-- Luxury -->
        <div class="package-column reveal" style="transition-delay: 0.3s">
            <div class="package-column-header tier-luxury text-white">
                <h3 class="text-white">Luxury Glamp</h3>
                <span class="text-white" style="opacity: 0.8; font-size: 0.9rem;">Exotic Wilderness</span>
            </div>
            <div class="package-column-features">
                <ul class="package-features">
                    <li>Chef-Selected Menu</li>
                    <li>Sommelier Service</li>
                </ul>
                <ul class="package-features">
                    <li>Full Outdoor Lounge</li>
                    <li>Bonfire Setup</li>
                </ul>
            </div>
            <div class="package-column-action">
                <div class="price-tag" style="margin:0; color: var(--text-main);">Rs. 1800 <span style="font-size: 0.8rem;">/plate</span></div>
                <a href="{{ route('bookings.create') }}" class="btn-secondary-sm">Book Now</a>
            </div>
        </div>
    </div>

    <!-- Comparison Section -->
    <div class="comparison-section reveal">
        <div class="text-center mb-12">
            <h2 class="text-4xl font-bold mb-4">Party Event <span class="accent">Comparison</span></h2>
            <p class="text-gray-600">Compare our Party catering solutions for your next event.</p>
        </div>

        <div class="comparison-table-wrapper">
            <table class="comparison-table">
                <thead>
                    <tr>
                        <th class="feature-label">Features</th>
                        <th>Garden Picnic</th>
                        <th>Park Buffet</th>
                        <th>Beach BBQ</th>
                        <th>Luxury Glamp</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="feature-label">Catering Style</td>
                        <td>Packed Boxes</td>
                        <td>Outdoor Buffet</td>
                        <td>Live BBQ Grill</td>
                        <td>Gourmet Wilderness</td>
                    </tr>
                    <tr>
                        <td class="feature-label">Drink Options</td>
                        <td>Lemonade / Water</td>
                        <td>Soft Drinks Bar</td>
                        <td>Cooler Bar</td>
                        <td>Sommelier Service</td>
                    </tr>
                    <tr>
                        <td class="feature-label">Setup Included</td>
                        <td>Eco-friendly Kits</td>
                        <td>Shaded Dining</td>
                        <td>Ambient Lighting</td>
                        <td>Full Outdoor Lounge</td>
                    </tr>
                    <tr>
                        <td class="feature-label">On-site Staff</td>
                        <td>Assistance Only</td>
                        <td>Full Service</td>
                        <td>BBQ Chefs</td>
                        <td>Private Butler & Chef</td>
                    </tr>
                    <tr>
                        <td class="feature-label">Cleaning</td>
                        <td>Customer Handled</td>
                        <td>Included</td>
                        <td>Included</td>
                        <td>Complete Restoration</td>
                    </tr>
                    <tr>
                        <td class="feature-label">Price per Plate</td>
                        <td class="font-bold">Rs. 300</td>
                        <td class="font-bold">Rs. 550</td>
                        <td class="font-bold">Rs. 950</td>
                        <td class="font-bold">Rs. 1800</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
