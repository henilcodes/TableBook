<?php $__env->startSection('title', 'Catering Packages'); ?>

<?php $__env->startSection('content'); ?>
<!-- Hero Section -->
<section class="hero-section contact-hero" style="background-image: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('<?php echo e(asset('images/slider 2.jfif')); ?>');">
    <div class="container hero-content-overlay reveal">
        <div class="hero-text-box" style="margin: 0 auto; text-align: center;">
            <h1 style="font-size: 3.5rem;">Catering <span class="accent">Packages</span></h1>
            <p style="font-size: 1.25rem;">
                Explore our curated tiers designed for exquisite dining experiences.
            </p>
        </div>
    </div>
</section>


<!--------type of package start----->
<section class="categories-package">
    <div class="package-container">
        <div class="package-birthday">
            <h3>Birthday Package</h3>
            <p>Perfect for birthday celibration package</p>
           <a href="<?php echo e(url('/packages/birthday')); ?>" class="btn">View More Details</a>
        </div>
        <div class="package-wedding">
            <h3>wedding package</h3>
            <p> perfect for weddingcelibration</p>
            <a href="<?php echo e(url('/packages/wedding')); ?>" class="btn">View More Details</a>
        </div>
        <div class="package-corprate">
            <h3>Corporate Package</h3>
            <p>Perfect for corporate event solutions</p>
           <a href="<?php echo e(url('/packages/corporate')); ?>" class="btn">View More Details</a>
        </div>
        <div class="package-private">
            <h3>Private Package</h3>
            <p>Perfect for private celebrations</p>
            <a href="<?php echo e(url('/packages/private')); ?>" class="btn">View More Details</a>
        </div>
        <div class="package-outdoor">
            <h3>Outdoor Package</h3>
            <p>Perfect for outdoor events</p>
            <a href="<?php echo e(url('/packages/outdoor')); ?>" class="btn">View More Details</a>
        </div>
        <div class="package-party">
            <h3>Party Package</h3>
            <p>Perfect for home & social parties</p>
            <a href="<?php echo e(url('/packages/party')); ?>" class="btn">View More Details</a>
        </div>
    </div>
</section>
<!--------type of package end------->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\catering-services-app\resources\views/packages/index.blade.php ENDPATH**/ ?>