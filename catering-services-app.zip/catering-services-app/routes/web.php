<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\AuthController;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/menu', function () {
    return view('menu');
});

Route::get('/services', function () {
    return view('services');
});

Route::get('/gallery', function () {
    return view('gallery');
});

Route::get('/about', function () {
    return view('about');
})->name('about');

Route::get('/package', function () {
    return view('packages.index');
});

Route::get('/packages', function () {
    return view('packages.index');
});

Route::get('/packages/birthday', function () {
    return view('packages.birthday');
});

Route::get('/packages/wedding', function () {
    return view('packages.wedding');
});

Route::get('/packages/corporate', function () {
    return view('packages.corporate');
});

Route::get('/packages/outdoor', function () {
    return view('packages.outdoor');
});

Route::get('/packages/private', function () {
    return view('packages.private');
});
Route::get('/packages/party', function () {
    return view('packages.party');
});

Route::get('/calendar', function () {
    return view('calendar');
});


Route::get('/payment', [PaymentController::class, 'index']);
Route::post('/payment/store', [PaymentController::class, 'store']);

// Authentication Routes
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register']);
});

Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Protected Routes
Route::middleware('auth')->group(function () {
    Route::get('/dashboard', [\App\Http\Controllers\DashboardController::class, 'index'])->name('dashboard');
    Route::post('/bookings/{booking}/pay', [\App\Http\Controllers\DashboardController::class, 'pay'])->name('bookings.pay');
    Route::post('/bookings/{booking}/cancel', [\App\Http\Controllers\DashboardController::class, 'cancel'])->name('bookings.cancel');

    // Customer Profile
    Route::get('/profile', [\App\Http\Controllers\ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [\App\Http\Controllers\ProfileController::class, 'update'])->name('profile.update');

    // Booking Routes
    Route::get('/bookings/create', [\App\Http\Controllers\BookingController::class, 'create'])->name('bookings.create');
    Route::post('/bookings', [\App\Http\Controllers\BookingController::class, 'store'])->name('bookings.store');

    // Custom Menu Routes
    Route::get('/custom-menu/create', [\App\Http\Controllers\CustomMenuController::class, 'create'])->name('custom_menu.create');
    Route::post('/custom-menu', [\App\Http\Controllers\CustomMenuController::class, 'store'])->name('custom_menu.store');
    Route::get('/my-custom-menus', [\App\Http\Controllers\CustomMenuController::class, 'index'])->name('custom_menu.index');
});

// Admin Routes
Route::middleware(['auth', 'admin'])->prefix('admin')->group(function () {
    Route::get('/dashboard', [\App\Http\Controllers\AdminController::class, 'index'])->name('admin.dashboard');
    Route::get('/activities', [\App\Http\Controllers\AdminController::class, 'activities'])->name('admin.activities');

    // Custom Menu Management
    Route::get('/custom-menus', [\App\Http\Controllers\AdminController::class, 'customMenus'])->name('admin.custom_menus.index');
    Route::patch('/custom-menus/{request}/status', [\App\Http\Controllers\AdminController::class, 'updateCustomMenuStatus'])->name('admin.custom_menus.update_status');

    // Booking Management
    Route::get('/bookings', [\App\Http\Controllers\AdminController::class, 'bookings'])->name('admin.bookings.index');
    Route::get('/bookings/{booking}', [\App\Http\Controllers\AdminController::class, 'showBooking'])->name('admin.bookings.show');
    Route::patch('/bookings/{booking}/status', [\App\Http\Controllers\AdminController::class, 'updateBookingStatus'])->name('admin.bookings.update_status');
    Route::patch('/bookings/{booking}/payment', [\App\Http\Controllers\AdminController::class, 'updatePayment'])->name('admin.bookings.update_payment');
    Route::get('/bookings/{booking}/receipt', [\App\Http\Controllers\AdminController::class, 'receipt'])->name('admin.bookings.receipt');

    // Menu & Package Management
    Route::resource('categories', \App\Http\Controllers\Admin\CategoryController::class)->names('admin.categories');
    Route::resource('packages', \App\Http\Controllers\Admin\PackageController::class)->names('admin.packages');
    Route::resource('menu-items', \App\Http\Controllers\Admin\MenuItemController::class)->names('admin.menu_items');
    Route::resource('posts', \App\Http\Controllers\Admin\PostController::class)->names('admin.posts');

    // Payments Management
    Route::get('/payments', [\App\Http\Controllers\AdminController::class, 'payments'])->name('admin.payments.index');

    // Profile Management
    Route::get('/profile', [\App\Http\Controllers\Admin\ProfileController::class, 'edit'])->name('admin.profile.edit');
    Route::patch('/profile', [\App\Http\Controllers\Admin\ProfileController::class, 'update'])->name('admin.profile.update');
});

// Setup First Admin (Visit this once to make yourself admin)
Route::get('/setup-admin', function () {
    $user = \App\Models\User::first();
    if ($user) {
        $user->is_admin = true;
        $user->save();
        return "User {$user->email} is now an ADMIN. You can now login and see the Admin link.";
    }
    return "No users found. Please register first.";
});

Route::get('/contact', function () {
    return view('contact');
});

// Blog Routes
Route::get('/blog', [\App\Http\Controllers\PostsController::class, 'index'])->name('blog.index');
Route::get('/blog/{slug}', [\App\Http\Controllers\PostsController::class, 'show'])->name('blog.show');
