<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('bookings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('full_name');
            $table->string('phone');
            $table->string('email');
            $table->string('event_type');
            $table->text('event_detail')->nullable();
            $table->date('event_date');
            $table->time('start_time');
            $table->time('end_time');
            $table->text('venue_address');
            $table->enum('event_setting', ['indoor', 'outdoor']);
            $table->integer('guest_count');
            $table->integer('adults_count')->default(0);
            $table->integer('kids_count')->default(0);
            $table->integer('vips_count')->default(0);
            $table->string('status')->default('pending');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('bookings');
    }
};
