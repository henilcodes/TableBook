@extends('layouts.app')

@section('title', 'Gallery')

@section('content')
<section class="hero-section">
    <div class="container hero-grid">
        <div class="hero-content reveal">
            <h1>
                Visual Journey of <br>
                <span class="accent">Our Events</span>
            </h1>
            <p class="hero-description">
                Explore the beautiful moments we've helped create through our exquisite food and elegant setups.
            </p>
        </div>
        <div class="hero-image-container reveal" style="transition-delay: 0.2s">
            <img src="{{ asset('images/gallery.png') }}" alt="Elegant Event Setup">
        </div>
    </div>
</section>

<section class="features-section" style="background-color: white;">
    <div class="container">
        <div class="section-header reveal">
            <h2>Recent Celebrations</h2>
        </div>
        <div class="features-grid" style="grid-template-columns: repeat(2, 1fr);">
             <!-- Placeholders for gallery items -->
             <div class="hero-image-container reveal" style="height: 300px;">
                <div style="background: #eee; height: 100%; display: flex; align-items: center; justify-content: center;">Wedding Reception</div>
             </div>
             <div class="hero-image-container reveal" style="height: 300px; transition-delay: 0.1s;">
                <div style="background: #eee; height: 100%; display: flex; align-items: center; justify-content: center;">Corporate Launch</div>
             </div>
        </div>
    </div>
</section>
@endsection
