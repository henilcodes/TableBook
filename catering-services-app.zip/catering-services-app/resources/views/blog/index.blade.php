@extends('layouts.app')

@section('title', 'Our Blog & News')

@section('content')
<!-- Hero -->
<section class="about-hero" style="background-image: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url('https://images.unsplash.com/photo-1499750310107-5fef28a66643?q=80&w=2070&auto=format&fit=crop');">
    <div class="container text-center reveal">
        <h1 class="text-white mb-6">Latest <span class="accent">Stories & Updates</span></h1>
        <p class="text-white opacity-90 max-w-2xl mx-auto text-lg">
            Inside the kitchen, behind the scenes, and everything in between.
        </p>
    </div>
</section>

<!-- Blog Section -->
<section class="py-24 bg-light">
    <div class="container">
        @if($posts->isEmpty())
            <div class="text-center py-20 bg-white rounded-3xl shadow-sm">
                <div class="mb-6">
                    <svg class="w-20 h-20 mx-auto text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10l4 4v10a2 2 0 01-2 2zM14 2v4h4"></path>
                    </svg>
                </div>
                <h3 class="text-2xl font-bold mb-4">No stories yet</h3>
                <p class="text-gray-500 mb-8">We're busy cooking up something special. Check back soon!</p>
                <a href="{{ url('/') }}" class="btn-primary">Back to Home</a>
            </div>
        @else
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                @foreach($posts as $post)
                    <article class="blog-card reveal">
                        <div class="blog-image">
                            <img src="{{ $post->image ?: 'https://images.unsplash.com/photo-1543353071-873f17a7a088?q=80&w=2070&auto=format&fit=crop' }}" alt="{{ $post->title }}">
                        </div>
                        <div class="blog-content">
                            <div class="blog-meta">
                                <span class="date">{{ $post->created_at->format('M d, Y') }}</span>
                                <span class="dot"></span>
                                <span class="author">{{ $post->author->name }}</span>
                            </div>
                            <h3 class="blog-title"><a href="{{ route('blog.show', $post->slug) }}">{{ $post->title }}</a></h3>
                            <p class="blog-excerpt">{{ Str::limit(strip_tags($post->content), 120) }}</p>
                            <a href="{{ route('blog.show', $post->slug) }}" class="read-more">Read Story →</a>
                        </div>
                    </article>
                @endforeach
            </div>
            <div class="mt-12">
                {{ $posts->links() }}
            </div>
        @endif
    </div>
</section>
@endsection
