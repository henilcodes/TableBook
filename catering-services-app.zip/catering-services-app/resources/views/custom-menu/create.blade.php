@extends('layouts.app')

@section('title', 'Request Custom Menu')

@section('content')
<div class="container py-24">
    <div class="max-w-2xl mx-auto bg-white p-8 rounded-2xl shadow-xl border border-gray-100 reveal">
        <div class="text-center mb-10">
            <h2 class="text-3xl font-bold mb-2">Create Your <span class="accent">Custom Menu</span></h2>
            <p class="text-muted">Tell us what you'd like for your special event, and our chefs will review your request.</p>
        </div>

        <form action="{{ route('custom_menu.store') }}" method="POST">
            @csrf
            
            <div class="mb-6">
                <label for="menu_details" class="block text-sm font-semibold mb-2">Desired Menu Items & Description*</label>
                <textarea name="menu_details" id="menu_details" rows="6" class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-accent focus:border-transparent outline-none transition-all" placeholder="E.g., Chicken Biryani, Grilled Fish, Fresh Salad, Custard for 50 people..." required></textarea>
                <p class="text-xs text-gray-500 mt-1">Be as specific as possible about the items and quantities.</p>
            </div>

            <div class="mb-8">
                <label for="additional_notes" class="block text-sm font-semibold mb-2">Additional Notes (Optional)</label>
                <textarea name="additional_notes" id="additional_notes" rows="3" class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-accent focus:border-transparent outline-none transition-all" placeholder="E.g., Dietary restrictions, specific theme, or serving preferences..."></textarea>
            </div>

            <div class="flex items-center justify-between gap-4">
                <a href="{{ route('custom_menu.index') }}" class="px-6 py-3 rounded-xl font-semibold text-gray-600 hover:bg-gray-50 transition-all">My Requests</a>
                <button type="submit" class="btn-action px-8 py-3 rounded-xl text-white font-bold transition-all hover:scale-105 active:scale-95 shadow-lg shadow-accent/30">
                    Submit Request
                </button>
            </div>
        </form>
    </div>
</div>

<style>
    .btn-action {
        background: linear-gradient(135deg, var(--accent, #ff6b6b), #ee5253);
    }
    .accent {
        color: #ff6b6b;
    }
</style>
@endsection
