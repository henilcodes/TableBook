@extends('layouts.app')

@section('title', 'Welcome to Exquisite Catering')

@section('content')
<!-- Hero Section -->
<section class="hero-section gala-hero">
    <div class="hero-slider-container" id="heroSlider">
        <!-- Slide 1 -->
        <div class="hero-slide active">
            <img src="{{asset('images/slider 1.jfif')}}" alt="A.V Event Decoration 1" class="hero-bg-img">
            <div class="hero-overlay-content container">
                <div class="hero-text-box reveal">
                    <h1>Tasty Catering  <br> for Every Event</h1>
                    <p>A.V Caterers helps make your moments special and stress-free.</p>
                    <div class="flex" style="gap: 1rem;">
                        <a href="{{ url('/menu') }}" class="btn-gala">Our Specialties</a>
                        <a href="{{ url('/contact') }}" class="btn-gala-outline">Inquiry Now</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Slide 2 -->
        <div class="hero-slide">
            <img src="{{asset('images/slider 2.jfif')}}" alt="A.V Event Decoration 2" class="hero-bg-img">
            <div class="hero-overlay-content container">
                <div class="hero-text-box">
                    <h1>Primium  Catering <br> for Every Celibration</h1>
                    <p>Serving delicious food with style and care.</p>
                    <div class="flex" style="gap: 1rem;">
                        <a href="{{ url('/menu') }}" class="btn-gala">Explorer Menu</a>
                        <a href="{{ url('/gallery') }}" class="btn-gala-outline">View Gallery</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Slide 3 -->
        <div class="hero-slide">
            <img src="{{asset('images/slider 3.jfif')}}" alt="A.V Event Decoration 3" class="hero-bg-img">
            <div class="hero-overlay-content container">
                <div class="hero-text-box">
                    <h1>Professional Service <br> You Can Trust</h1>
                    <p>Professional catering staff providing timely service, elegant presentation, 
and complete event support for weddings, parties, and corporate functions.</p>
                    <div class="flex" style="gap: 1rem;">
                        <a href="{{ url('/services') }}" class="btn-gala">Our Services</a>
                        <a href="{{ url('/contact') }}" class="btn-gala-outline">Contact Us</a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Slider Controls -->
        <div class="slider-controls">
            <button class="slider-btn prev" onclick="moveSlide(-1)">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"></polyline></svg>
            </button>
            <button class="slider-btn next" onclick="moveSlide(1)">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>
            </button>
        </div>

        <!-- Progress Indicators -->
        <div class="slider-dots">
            <span class="dot active" onclick="setSlide(0)"></span>
            <span class="dot" onclick="setSlide(1)"></span>
            <span class="dot" onclick="setSlide(2)"></span>
        </div>
    </div>
</section>

<script>
    let currentSlide = 0;
    const slides = document.querySelectorAll('.hero-slide');
    const dots = document.querySelectorAll('.dot');
    
    function showSlide(n) {
        slides[currentSlide].classList.remove('active');
        dots[currentSlide].classList.remove('active');
        
        currentSlide = (n + slides.length) % slides.length;
        
        slides[currentSlide].classList.add('active');
        dots[currentSlide].classList.add('active');
    }
    
    function moveSlide(n) {
        showSlide(currentSlide + n);
    }
    
    function setSlide(n) {
        showSlide(n);
    }
    
    // Auto-slide every 5 seconds
    setInterval(() => moveSlide(1), 5000);
</script>
<!----about section start----->
<!-- About Section -->
<section class="about py-5 bg-white">
  <div class="container">
    <div class="row align-items-center">
      
      
      
      <!-- About Content -->
      <div class="col-md-6">
        <h2 class="mb-3">About Us</h2>
        <p>
          <strong >A.V Caterers</strong> is committed to providing high-quality catering services for all types of events. 
We specialize in preparing delicious food using fresh ingredients and maintaining the highest standards of hygiene. 
Our team works closely with clients to understand their needs and create customized menus. 
From small gatherings to large celebrations, we ensure smooth and professional service. 
We focus on both taste and presentation to make every event special. 
Our goal is to create memorable experiences through great food and service.
        </p>
        <a href="{{ route('about') }}" class="btn btn-primary mt-3">Learn More</a>
      </div>
      
    </div>
  </div>
</section>

<!---abouth section end----->


<!---services section start ----->

<section class="services-section">
  <div class="container">
    <div class="section-header reveal">
      <h2>Our Premium Services</h2>
      <p>Tailored catering solutions to make every occasion unforgettable.</p>
    </div>
    <div class="services-flex-container">
      
      <!-- Service 1 -->
      <div class="service-box reveal">
        <div class="service-box-icon">
          <i class="fas fa-utensils"></i>
        </div>
        <h3>Wedding Catering</h3>
        <p>Elegant menus and full-service catering for weddings and receptions.</p>
      </div>

      <!-- Service 2 -->
      <div class="service-box reveal" style="transition-delay: 0.1s">
        <div class="service-box-icon">
          <i class="fas fa-glass-cheers"></i>
        </div>
        <h3>Corporate Events</h3>
        <p>Professional catering solutions for conferences, meetings, and office parties.</p>
      </div>

      <!-- Service 3 -->
      <div class="service-box reveal" style="transition-delay: 0.2s">
        <div class="service-box-icon">
          <i class="fas fa-birthday-cake"></i>
        </div>
        <h3>Private Parties</h3>
        <p>Delicious food and drinks tailored for birthdays, anniversaries, and family gatherings.</p>
      </div>

    </div>
  </div>
</section>

<!-----services section end----->


<!------menu section start----->
<section class="menu-home-section">
    <div class="container">
        <div class="section-header reveal">
            <h2>Our Specialties</h2>
            <p>Explore our Premium Menu Categories</p>
        </div>
        
        <div class="menu-category-grid">
            <!-- Category 1 -->
            <div class="menu-cat-card reveal">
                <div class="menu-cat-overlay"></div>
                <img src="{{ asset('images/slider 1.jfif') }}" alt="Marriage Related Parties">
                <div class="menu-cat-content">
                    <h3>Marriage Related Parties</h3>
                </div>
            </div>

            <!-- Category 2 -->
            <div class="menu-cat-card reveal" style="transition-delay: 0.1s">
                <div class="menu-cat-overlay"></div>
                <img src="{{ asset('images/slider 2.jfif') }}" alt="Lunch & Dinner Parties">
                <div class="menu-cat-content">
                    <h3>Lunch & Dinner Parties</h3>
                </div>
            </div>

            <!-- Category 3 -->
            <div class="menu-cat-card reveal" style="transition-delay: 0.2s">
                <div class="menu-cat-overlay"></div>
                <img src="{{ asset('images/slider 3.jfif') }}" alt="Anniversary Celebration Parties">
                <div class="menu-cat-content">
                    <h3>Anniversary Celebration</h3>
                </div>
            </div>

            <!-- Category 4 -->
            <div class="menu-cat-card reveal" style="transition-delay: 0.3s">
                <div class="menu-cat-overlay"></div>
                <img src="{{ asset('images/images 2.jfif') }}" alt="Corporate Services">
                <div class="menu-cat-content">
                    <h3>Corporate Services</h3>
                </div>
            </div>

            <!-- Category 5 -->
            <div class="menu-cat-card reveal" style="transition-delay: 0.4s">
                <div class="menu-cat-overlay"></div>
                <img src="{{ asset('images/slider 1.jfif') }}" alt="Family Get-Together">
                <div class="menu-cat-content">
                    <h3>Family Get-Together</h3>
                </div>
            </div>

            <!-- Category 6 -->
            <div class="menu-cat-card reveal" style="transition-delay: 0.5s">
                <div class="menu-cat-overlay"></div>
                <img src="{{ asset('images/slider 2.jfif') }}" alt="Festival Celebrations">
                <div class="menu-cat-content">
                    <h3>Festival Celebrations</h3>
                </div>
            </div>
        </div>

        <div class="text-center mt-5 reveal">
            <a href="{{ url('/menu') }}" class="btn-gala-large">View Full Menu</a>
        </div>
    </div>
</section>
<!-------menu section end----->





<!-- Features / Why Choose us Section -->
<section class="features-section">
    <div class="container">
        <div class="section-header reveal">
            <h2>Why Choose Us?</h2>
        </div>
        <div class="features-grid">
            <div class="feature-card reveal">
                <span class="feature-icon">🏆</span>
                <h3>Quality Guaranteed</h3>
                <p>Fresh ingredients sourced from the finest local producers and suppliers.</p>
            </div>
            <div class="feature-card reveal" style="transition-delay: 0.1s">
                <span class="feature-icon">👨‍🍳</span>
                <h3>Master Chefs</h3>
                <p>An expert culinary team with decades of experience in diverse cuisines.</p>
            </div>
            <div class="feature-card reveal" style="transition-delay: 0.2s">
                <span class="feature-icon">✨</span>
                <h3>Impeccable Service</h3>
                <p>Professional staff dedicated to ensuring every detail of your event is perfect.</p>
            </div>
        </div>
    </div>
</section>
@endsection
