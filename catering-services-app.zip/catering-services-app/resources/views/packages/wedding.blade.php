@extends('layouts.app')

@section('title', 'Wedding Packages')

@section('content')
<!-- Hero -->
<section class="about-hero" style="background-image: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url('https://images.unsplash.com/photo-1519741497674-611481863552?q=80&w=2070&auto=format&fit=crop');">
    <div class="container text-center reveal">
        <a href="{{ url('/packages') }}" style="color: var(--gala-orange); font-weight: 700; text-decoration: none; margin-bottom: 2rem; display: inline-block;">← Back to All Categories</a>
        <h1 class="text-white mb-6">Wedding <span class="accent">Catering Excellence</span></h1>
        <p class="text-white opacity-90 max-w-2xl mx-auto text-lg">
            Your special day deserves nothing but the finest culinary experience. Explore our tiered wedding collections.
        </p>
    </div>
</section>

<div class="container py-24">
    <div class="max-w-5xl mx-auto" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 2rem;">
        <!-- Basic -->
        <div class="package-column reveal">
            <div class="package-column-header tier-basic text-white">
                <h3 class="text-white">Engagement</h3>
                <span class="text-white" style="opacity: 0.8; font-size: 0.9rem;">The Perfect Beginning</span>
            </div>
            <div class="package-column-features">
                <ul class="package-features">
                    <li>Traditional Starters</li>
                    <li>Core Gujarati Menu</li>
                </ul>
                <ul class="package-features">
                    <li>Standard Seating</li>
                    <li>Uniformed Staff</li>
                </ul>
            </div>
            <div class="package-column-action">
                <div class="price-tag" style="margin:0; color: var(--text-main);">Rs. 500 <span style="font-size: 0.8rem;">/plate</span></div>
                <a href="{{ route('bookings.create') }}" class="btn-secondary-sm">Book Now</a>
            </div>
        </div>

        <!-- Standard -->
        <div class="package-column reveal" style="transition-delay: 0.1s">
            <div class="package-column-header tier-standard text-white">
                <h3 class="text-white">Classic Shadi</h3>
                <span class="text-white" style="opacity: 0.8; font-size: 0.9rem;">Traditional Splendor</span>
            </div>
            <div class="package-column-features">
                <ul class="package-features">
                    <li>Multi-Cuisine Buffet</li>
                    <li>Live Mithai Counter</li>
                </ul>
                <ul class="package-features">
                    <li>Fruit Display</li>
                    <li>Standard Crockery</li>
                </ul>
            </div>
            <div class="package-column-action">
                <div class="price-tag" style="margin:0; color: var(--text-main);">Rs. 850 <span style="font-size: 0.8rem;">/plate</span></div>
                <a href="{{ route('bookings.create') }}" class="btn-secondary-sm">Book Now</a>
            </div>
        </div>

        <!-- Premium -->
        <div class="package-column reveal" style="transition-delay: 0.2s">
            <div class="package-column-header tier-premium text-white">
                <h3 class="text-white">Grand Utsav</h3>
                <span class="text-white" style="opacity: 0.8; font-size: 0.9rem;">Exquisite Celebration</span>
            </div>
            <div class="package-column-features">
                <ul class="package-features">
                    <li>Continental & Pan Asian</li>
                    <li>Live Pasta Counter</li>
                </ul>
                <ul class="package-features">
                    <li>Cold Pressed Juices</li>
                    <li>Premium Silver Service</li>
                </ul>
            </div>
            <div class="package-column-action">
                <div class="price-tag" style="margin:0; color: var(--text-main);">Rs. 1500 <span style="font-size: 0.8rem;">/plate</span></div>
                <a href="{{ route('bookings.create') }}" class="btn-secondary-sm">Book Now</a>
            </div>
        </div>

        <!-- Luxury -->
        <div class="package-column reveal" style="transition-delay: 0.3s">
            <div class="package-column-header tier-luxury text-white">
                <h3 class="text-white">Royal Heritage</h3>
                <span class="text-white" style="opacity: 0.8; font-size: 0.9rem;">VVIP Heritage Dining</span>
            </div>
            <div class="package-column-features">
                <ul class="package-features">
                    <li>Bespoke Global Menu</li>
                    <li>Interactive Food Art</li>
                </ul>
                <ul class="package-features">
                    <li>VVIP Waiter Service</li>
                    <li>Royal Table Decor</li>
                </ul>
            </div>
            <div class="package-column-action">
                <div class="price-tag" style="margin:0; color: var(--text-main);">Rs. 2500 <span style="font-size: 0.8rem;">/plate</span></div>
                <a href="{{ route('bookings.create') }}" class="btn-secondary-sm">Book Now</a>
            </div>
        </div>
    </div>

    <!-- Comparison Section -->
    <div class="comparison-section reveal">
        <div class="text-center mb-12">
            <h2 class="text-4xl font-bold mb-4">Wedding Package <span class="accent">Comparison</span></h2>
            <p class="text-gray-600">Explore our signature wedding collections for your perfect day.</p>
        </div>

        <div class="comparison-table-wrapper">
            <table class="comparison-table">
                <thead>
                    <tr>
                        <th class="feature-label">Features</th>
                        <th>Engagement</th>
                        <th>Classic Shadi</th>
                        <th>Grand Utsav</th>
                        <th>Royal Heritage</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="feature-label">Cuisine Philosophy</td>
                        <td>Traditional Local</td>
                        <td>Regional Grandeur</td>
                        <td>Pan-Asian & Continental</td>
                        <td>Bespoke Global Cuisines</td>
                    </tr>
                    <tr>
                        <td class="feature-label">Live Counters</td>
                        <td>None</td>
                        <td>Live Mithai Corner</td>
                        <td>Live Pasta & Grills</td>
                        <td>Food Art Stations</td>
                    </tr>
                    <tr>
                        <td class="feature-label">Welcome Drinks</td>
                        <td>Standard Refreshments</td>
                        <td>Fruit Display</td>
                        <td>Cold Pressed Juices</td>
                        <td>Signature Mocktail Bar</td>
                    </tr>
                    <tr>
                        <td class="feature-label">Service Standard</td>
                        <td>Uniformed Buffet</td>
                        <td>Enhanced Hospitality</td>
                        <td>Premium Silver Service</td>
                        <td>VVIP Butler Service</td>
                    </tr>
                    <tr>
                        <td class="feature-label">Table Decor</td>
                        <td>Standard Setup</td>
                        <td>Themed Elements</td>
                        <td>Elegant Floral</td>
                        <td>Royal Table Decor</td>
                    </tr>
                    <tr>
                        <td class="feature-label">Staff Ratio</td>
                        <td>1:30 Guests</td>
                        <td>1:20 Guests</td>
                        <td>1:15 Guests</td>
                        <td>1:8 Guests</td>
                    </tr>
                    <tr>
                        <td class="feature-label">Price per Plate</td>
                        <td class="font-bold">Rs. 500</td>
                        <td class="font-bold">Rs. 850</td>
                        <td class="font-bold">Rs. 1500</td>
                        <td class="font-bold">Rs. 2500</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
