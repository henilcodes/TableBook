<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use App\Models\CustomMenuRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function index()
    {
        $user = Auth::user();
        
        $bookings = Booking::where('user_id', $user->id)
            ->latest()
            ->get();
            
        $customMenuRequests = CustomMenuRequest::where('user_id', $user->id)
            ->latest()
            ->get();

        return view('dashboard', compact('bookings', 'customMenuRequests'));
    }

    public function pay(Request $request, Booking $booking)
    {
        // Ensure user owns the booking
        if ($booking->user_id !== Auth::id()) {
            abort(403);
        }

        // Only allowed if confirmed by admin
        if ($booking->status !== 'confirmed') {
            return back()->with('error', 'Booking must be confirmed by admin before payment.');
        }

        $request->validate([
            'payment_method' => 'required|in:online,offline,qr_scan'
        ]);

        $updateData = [
            'payment_method' => $request->payment_method,
        ];

        if ($request->payment_method === 'online') {
            $updateData['payment_status'] = 'fully_paid';
            $message = 'Payment successful! Your event is now fully booked.';
        } elseif ($request->payment_method === 'qr_scan') {
            $updateData['payment_status'] = 'pending';
            $message = 'Thank you! We have received your payment confirmation. Our team will verify the transaction soon.';
        } else {
            $updateData['payment_status'] = 'pending';
            $message = 'Offline payment request received. Please visit our office to settle the amount.';
        }

        $booking->update($updateData);

        return back()->with('success', $message);
    }

    public function cancel(Booking $booking)
    {
        // Ensure user owns the booking
        if ($booking->user_id !== Auth::id()) {
            abort(403);
        }

        // Only allowed if pending
        if ($booking->status !== 'pending') {
            return back()->with('error', 'Only pending bookings can be cancelled.');
        }

        $booking->update(['status' => 'cancelled']);

        return back()->with('success', 'Booking cancelled successfully.');
    }
}
