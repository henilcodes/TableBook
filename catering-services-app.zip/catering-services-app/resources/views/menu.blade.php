@extends('layouts.app')

@section('title', 'Our Menu')

@section('content')
@section('content')
<!-- Menu Hero Section -->
<section class="menu-hero" style="background-image: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url('https://images.unsplash.com/photo-1504674900247-0877df9cc836?q=80&w=2070&auto=format&fit=crop');">
    <div class="container text-center reveal">
        <h1 class="text-white mb-6">Exquisite <span class="accent">Flavor Journey</span></h1>
        <p class="text-white opacity-90 max-w-2xl mx-auto text-lg">
            A curated selection of gourmet offerings for every time of day. 
            Crafted with passion, served with excellence.
        </p>
    </div>
</section>

<!-- Menu Category Navigation -->
    <div class="menu-tabs flex flex-wrap justify-center gap-4 bg-white p-4 rounded-xl shadow-xl border border-gray-100">
        <button class="menu-tab-btn active" onclick="showCategory('breakfast')">Breakfast</button>
        <button class="menu-tab-btn" onclick="showCategory('lunch')">Lunch</button>
        <button class="menu-tab-btn" onclick="showCategory('dinner')">Dinner</button>
        <button class="menu-tab-btn" onclick="showCategory('other')">Other</button>
        <a href="{{ route('custom_menu.create') }}" class="btn-primary-custom px-6 py-2 rounded-lg font-bold transition-all hover:scale-105 active:scale-95 flex items-center gap-2">
            <span>✨</span> Create Own Menu
        </a>
    </div>
</div>

<style>
    .btn-primary-custom {
        background: linear-gradient(135deg, #ff6b6b, #ee5253);
        color: white;
        box-shadow: 0 4px 15px rgba(238, 82, 83, 0.3);
    }
    .btn-primary-custom:hover {
        background: linear-gradient(135deg, #ee5253, #ff6b6b);
        color: white;
    }
</style>

<section id="menu-content" class="pb-24">
    <div class="container">
        
        <!-- BREAKFAST CATEGORY -->
        <div id="category-breakfast" class="menu-category-content active">
            <div class="section-header text-center mb-16">
                <h2 class="text-4xl font-bold mb-4">Breakfast Spread</h2>
                <p class="text-muted">Start your day with our artisanal morning selections.</p>
            </div>

            <!-- EAT Section -->
            <div class="menu-type-section mb-20">
                <div class="flex items-center gap-4 mb-8">
                    <span class="text-2xl">🥐</span>
                    <h3 class="text-2xl font-bold">Delicious Food</h3>
                    <div class="flex-grow border-t border-gray-200"></div>
                </div>
                <div class="menu-grid">
                    <div class="menu-item-card reveal">
                        <img src="https://images.unsplash.com/photo-1525351484163-7529414344d8?q=80&w=800&auto=format&fit=crop" alt="Classic Omelette">
                        <div class="p-6">
                            <h4>Artisanal Omelette</h4>
                            <p>Organic eggs with aged cheddar, fresh herbs, and seasonal vegetables.</p>
                        </div>
                    </div>
                    <div class="menu-item-card reveal" style="transition-delay: 0.1s">
                        <img src="https://images.unsplash.com/photo-1506084868730-342363bca84e?q=80&w=800&auto=format&fit=crop" alt="Fluffy Pancakes">
                        <div class="p-6">
                            <h4>Signature Buttermilk Pancakes</h4>
                            <p>Hand-crafted pancakes served with maple syrup and fresh berries.</p>
                        </div>
                    </div>
                    <div class="menu-item-card reveal" style="transition-delay: 0.2s">
                        <img src="https://images.unsplash.com/photo-1490645935967-10de6ba17061?q=80&w=800&auto=format&fit=crop" alt="Avocado Toast">
                        <div class="p-6">
                            <h4>Avocado Bliss Toast</h4>
                            <p>Sourdough topped with smashed avocado, poached egg, and chili flakes.</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- DRINK Section -->
            <div class="menu-type-section">
                <div class="flex items-center gap-4 mb-8">
                    <span class="text-2xl">☕</span>
                    <h3 class="text-2xl font-bold">Refreshing Drinks</h3>
                    <div class="flex-grow border-t border-gray-200"></div>
                </div>
                <div class="menu-grid">
                    <div class="menu-item-card reveal">
                        <img src="https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?q=80&w=800&auto=format&fit=crop" alt="Specialty Coffee">
                        <div class="p-6">
                            <h4>Aromatic Coffee Selection</h4>
                            <p>House blend, cappuccino, and latte crafted by expert baristas.</p>
                        </div>
                    </div>
                    <div class="menu-item-card reveal" style="transition-delay: 0.1s">
                        <img src="https://images.unsplash.com/photo-1595981267035-7b04ca84a82d?q=80&w=800&auto=format&fit=crop" alt="Fresh Juice">
                        <div class="p-6">
                            <h4>Fresh Cold-Pressed Juices</h4>
                            <p>Orange, Green detox, and Tropical sunrise blends.</p>
                        </div>
                    </div>
                    <div class="menu-item-card reveal" style="transition-delay: 0.2s">
                        <img src="https://images.unsplash.com/photo-1544787210-22bb6bc05f2a?q=80&w=800&auto=format&fit=crop" alt="Assorted Teas">
                        <div class="p-6">
                            <h4>Premium Tea Collection</h4>
                            <p>Earl Grey, Masala Chai, and Calming Chamomile.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Placeholder for LUNCH, DINNER, OTHER (Similar logic but hidden) -->
        <div id="category-lunch" class="menu-category-content hidden">
            <div class="section-header text-center mb-16">
                <h2 class="text-4xl font-bold mb-4">Gourmet Lunch</h2>
                <p class="text-muted">Vibrant midday flavors to energize your event.</p>
            </div>
            <!-- Sub-sections like Eat/Drink would go here -->
             <p class="text-center italic opacity-70">Full lunch menu details appearing soon...</p>
        </div>

        <div id="category-dinner" class="menu-category-content hidden">
            <div class="section-header text-center mb-16">
                <h2 class="text-4xl font-bold mb-4">Grand Dinner</h2>
                <p class="text-muted">Elegant dining experiences for your most special evenings.</p>
            </div>
             <p class="text-center italic opacity-70">Full dinner menu details appearing soon...</p>
        </div>

        <div id="category-other" class="menu-category-content hidden">
            <div class="section-header text-center mb-16">
                <h2 class="text-4xl font-bold mb-4">Delightful Extras</h2>
                <p class="text-muted">Appetizers, snacks, and specialty custom requests.</p>
            </div>
             <p class="text-center italic opacity-70">Custom menu options appearing soon...</p>
        </div>
    </div>
</section>

<script>
    function showCategory(categoryId) {
        // Hide all categories
        document.querySelectorAll('.menu-category-content').forEach(cat => {
            cat.classList.remove('active');
            cat.classList.add('hidden');
        });
        
        // Show selected category
        const selected = document.getElementById('category-' + categoryId);
        selected.classList.remove('hidden');
        selected.classList.add('active');
        
        // Update tab buttons
        document.querySelectorAll('.menu-tab-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        event.currentTarget.classList.add('active');
    }
</script>
@endsection
@endsection

