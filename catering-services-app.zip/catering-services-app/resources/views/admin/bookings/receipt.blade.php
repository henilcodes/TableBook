<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Receipt - A.V Caterers</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 40px; color: #333; }
        .receipt-box { max-width: 800px; margin: auto; border: 1px solid #eee; padding: 40px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.05); }
        .header { display: flex; justify-content: space-between; border-bottom: 2px solid var(--gala-red, #e53e3e); padding-bottom: 20px; }
        .logo { font-size: 24px; font-weight: 800; color: #e53e3e; }
        .details { margin-top: 40px; display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .details h2 { font-size: 14px; text-transform: uppercase; margin-bottom: 10px; color: #888; }
        .table { width: 100%; margin-top: 40px; border-collapse: collapse; }
        .table th, .table td { padding: 12px; border-bottom: 1px solid #eee; text-align: left; }
        .table th { background: #f9f9f9; }
        .total-box { margin-top: 20px; text-align: right; font-size: 18px; }
        .stamp { font-family: 'Playfair Display', serif; font-style: italic; font-size: 24px; color: rgba(229, 62, 62, 0.4); text-align: right; margin-top: 40px; }
        @media print { .no-print { display: none; } }
    </style>
</head>
<body>
    <div class="no-print" style="text-align: center; margin-bottom: 20px;">
        <button onclick="window.print()" style="padding: 10px 20px; cursor: pointer; background: #e53e3e; color: white; border: none; border-radius: 4px;">Print Receipt</button>
    </div>

    <div class="receipt-box">
        <div class="header">
            <div>
                <div class="logo">A.V CATERERS</div>
                <div style="font-size: 0.9rem; color: #666; margin-top: 5px;">Surat's Premium Event Catering</div>
            </div>
            <div style="text-align: right;">
                <div style="font-weight: 700;">INVOICE #{{ 1000 + $booking->id }}</div>
                <div style="font-size: 0.9rem; color: #666;">Date: {{ now()->format('M d, Y') }}</div>
            </div>
        </div>

        <div class="details">
            <div>
                <h2>Billed To:</h2>
                <strong>{{ $booking->full_name }}</strong><br>
                {{ $booking->phone }}<br>
                {{ $booking->email }}
            </div>
            <div style="text-align: right;">
                <h2>Event Details:</h2>
                <strong>{{ ucfirst($booking->event_type) }}</strong><br>
                Date: {{ \Carbon\Carbon::parse($booking->event_start_date)->format('M d, Y') }}<br>
                Venue: {{ $booking->venue_address }}
            </div>
        </div>

        <table class="table">
            <thead>
                <tr>
                    <th>Description</th>
                    <th style="text-align: right;">Amount (Rs.)</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Catering Services for {{ $booking->guest_count }} Guests ({{ ucfirst($booking->event_setting) }})</td>
                    <td style="text-align: right;">{{ number_format($booking->total_amount, 2) }}</td>
                </tr>
                <tr>
                    <td>Advance Payment (Recieved)</td>
                    <td style="text-align: right;">-{{ number_format($booking->advance_amount, 2) }}</td>
                </tr>
                <tr style="font-weight: 800; font-size: 1.1rem;">
                    <td>Remaining Balance</td>
                    <td style="text-align: right;">{{ number_format($booking->total_amount - $booking->advance_amount, 2) }}</td>
                </tr>
            </tbody>
        </table>

        <div class="total-box">
            <p>Payment Status: <span style="color: #38a169; font-weight: 700;">{{ strtoupper(str_replace('_', ' ', $booking->payment_status)) }}</span></p>
            <p style="font-size: 0.8rem; color: #888;">Method: {{ ucfirst($booking->payment_method) }}</p>
        </div>

        <div class="stamp">
            Thank you for choosing A.V Caterers!
        </div>
    </div>
</body>
</html>
