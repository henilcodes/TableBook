@extends('layouts.app')

@section('title', 'Book Our Services')

@section('content')
<div class="container py-12">
    <div class="max-w-4xl mx-auto">
        <div class="auth-card" style="max-width: none; border-radius: 16px;">
            <div class="auth-header" style="margin-bottom: 3rem;">
                <h2 style="color: var(--gala-red);">Book Your Event</h2>
                <p class="text-muted">Tell us about your special occasion and we'll make it unforgettable.</p>
            </div>

            @if ($errors->any())
                <div class="alert alert-danger mb-6" style="background: #fee2e2; color: #b91c1c; padding: 1rem; border-radius: 8px; border: 1px solid #fecaca;">
                    <ul class="mb-0">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form action="{{ url('/bookings') }}" method="POST" class="booking-form">
                @csrf
                <div class="form-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
                    
                    <!-- Contact Information -->
                    <div class="form-section">
                        <h3 class="mb-4 font-bold text-lg border-b pb-2">Contact Information</h3>
                        <div class="form-group mb-4">
                            <label class="form-label">Full Name</label>
                            <input type="text" name="full_name" class="form-input" required value="{{ old('full_name', auth()->user()->name) }}">
                        </div>
                        <div class="form-group mb-4">
                            <label class="form-label">Phone Number</label>
                            <input type="text" name="phone" class="form-input" required value="{{ old('phone') }}">
                        </div>
                        <div class="form-group mb-4">
                            <label class="form-label">Email Address</label>
                            <input type="email" name="email" class="form-input" required value="{{ old('email', auth()->user()->email) }}">
                        </div>
                    </div>

                    <!-- Event Details -->
                    <div class="form-section">
                        <h3 class="mb-4 font-bold text-lg border-b pb-2">Event Details</h3>
                        <div class="form-group mb-4">
                            <label class="form-label">Event Type</label>
                            <select name="event_type" class="form-input" required>
                                <option value="">Select Event Type</option>
                                <option value="Wedding">Wedding</option>
                                <option value="Birthday">Birthday</option>
                                <option value="Corporate">Corporate Event</option>
                                <option value="Engagement">Engagement</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="flex gap-4">
                            <div class="form-group mb-4 flex-grow">
                                <label class="form-label">Event Start Date</label>
                                <input type="date" name="event_start_date" class="form-input" required value="{{ old('event_start_date') }}">
                            </div>
                            <div class="form-group mb-4 flex-grow">
                                <label class="form-label">Event End Date</label>
                                <input type="date" name="event_end_date" class="form-input" required value="{{ old('event_end_date') }}">
                            </div>
                        </div>
                        <div class="flex gap-4">
                            <div class="form-group mb-4 flex-grow">
                                <label class="form-label">Start Time</label>
                                <input type="time" name="start_time" class="form-input" required value="{{ old('start_time') }}">
                            </div>
                            <div class="form-group mb-4 flex-grow">
                                <label class="form-label">End Time</label>
                                <input type="time" name="end_time" class="form-input" required value="{{ old('end_time') }}">
                            </div>
                        </div>
                    </div>

                    <!-- Location & Setting -->
                    <div class="form-section">
                        <h3 class="mb-4 font-bold text-lg border-b pb-2">Venue & Location</h3>
                        <div class="form-group mb-4">
                            <label class="form-label">Venue Address / Location</label>
                            <textarea name="venue_address" class="form-input" style="height: 100px;" required>{{ old('venue_address') }}</textarea>
                        </div>
                        <div class="form-group mb-4">
                            <label class="form-label">Event Setting</label>
                            <div class="flex gap-6 mt-2">
                                <label class="flex items-center gap-2 cursor-pointer">
                                    <input type="radio" name="event_setting" value="indoor" checked> Indoor
                                </label>
                                <label class="flex items-center gap-2 cursor-pointer">
                                    <input type="radio" name="event_setting" value="outdoor"> Outdoor
                                </label>
                            </div>
                        </div>
                    </div>

                    <!-- Guest Information -->
                    <div class="form-section">
                        <h3 class="mb-4 font-bold text-lg border-b pb-2">Guest Information</h3>
                        <div class="form-group mb-4">
                            <label class="form-label">Total Number of Guests</label>
                            <input type="number" name="guest_count" class="form-input" required value="{{ old('guest_count') }}">
                        </div>
                        <div class="grid grid-cols-3 gap-2">
                            <div class="form-group">
                                <label class="form-label" style="font-size: 0.75rem;">Adults</label>
                                <input type="number" name="adults_count" class="form-input" value="{{ old('adults_count', 0) }}">
                            </div>
                            <div class="form-group">
                                <label class="form-label" style="font-size: 0.75rem;">Kids</label>
                                <input type="number" name="kids_count" class="form-input" value="{{ old('kids_count', 0) }}">
                            </div>
                            <div class="form-group">
                                <label class="form-label" style="font-size: 0.75rem;">VIPs</label>
                                <input type="number" name="vips_count" class="form-input" value="{{ old('vips_count', 0) }}">
                            </div>
                        </div>
                    </div>

                    <div class="form-section" style="grid-column: span 2;">
                        <h3 class="mb-4 font-bold text-lg border-b pb-2">Additional Details</h3>
                        <div class="form-group mb-4">
                            <label class="form-label">Any specific requirements or details?</label>
                            <textarea name="event_detail" class="form-input" style="height: 120px;" placeholder="Menu preferences, special requests, etc.">{{ old('event_detail') }}</textarea>
                        </div>
                    </div>
                </div>

                <div class="mt-8 flex justify-center">
                    <button type="submit" class="btn-primary" style="width: 300px; padding: 1rem; font-size: 1.1rem;">Submit Booking Request</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
