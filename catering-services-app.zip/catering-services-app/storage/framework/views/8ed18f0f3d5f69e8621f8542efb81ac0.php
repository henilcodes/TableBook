<?php $__env->startSection('title', 'Manage Blog Posts'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Blog Posts</h1>
        <a href="<?php echo e(route('admin.posts.create')); ?>" class="btn btn-primary">Add New Post</a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body p-0">
            <table class="table table-hover mb-0">
                <thead class="bg-light">
                    <tr>
                        <th>Title</th>
                        <th>Author</th>
                        <th>Status</th>
                        <th>Created At</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <strong><?php echo e($post->title); ?></strong>
                                <br>
                                <small class="text-muted"><?php echo e($post->slug); ?></small>
                            </td>
                            <td><?php echo e($post->author->name); ?></td>
                            <td>
                                <?php if($post->is_published): ?>
                                    <span class="badge bg-success">Published</span>
                                <?php else: ?>
                                    <span class="badge bg-warning text-dark">Draft</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($post->created_at->format('M d, Y')); ?></td>
                            <td class="text-end">
                                <div class="btn-group">
                                    <a href="<?php echo e(route('blog.show', $post->slug)); ?>" class="btn btn-sm btn-outline-info" target="_blank">View</a>
                                    <a href="<?php echo e(route('admin.posts.edit', $post->id)); ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                                    <form action="<?php echo e(route('admin.posts.destroy', $post->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this post?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center py-5">No posts found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($posts->hasPages()): ?>
            <div class="card-footer">
                <?php echo e($posts->links()); ?>

            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\catering-services-app\resources\views/admin/posts/index.blade.php ENDPATH**/ ?>