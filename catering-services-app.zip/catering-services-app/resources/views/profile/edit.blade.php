@extends('layouts.app')

@section('title', 'Account Settings')

@section('content')
<section class="hero-section" style="padding: 60px 0;">
    <div class="container reveal">
        <h1>
            Account <span class="accent">Settings</span>
        </h1>
        <p class="hero-description" style="max-width: 100%;">Update your personal information and security details.</p>
    </div>
</section>

<div class="container py-12 reveal">
    <div style="max-width: 600px; margin: 0 auto;">
        @if(session('success'))
            <div class="alert alert-success" style="margin-bottom: 2rem;">
                {{ session('success') }}
            </div>
        @endif

        <div class="feature-card" style="padding: 2.5rem; background: white;">
            <form action="{{ route('profile.update') }}" method="POST">
                @csrf
                @method('PATCH')

                <div class="mb-4" style="margin-bottom: 1.5rem;">
                    <label for="name" style="display: block; font-weight: 700; margin-bottom: 0.5rem; color: var(--text-main);">Full Name</label>
                    <input type="text" name="name" id="name" style="width: 100%; padding: 0.75rem 1rem; border: 1px solid var(--border-color); border-radius: 8px; font-family: inherit;" value="{{ old('name', $user->name) }}" required>
                    @error('name')
                        <p style="color: #ef4444; font-size: 0.75rem; margin-top: 0.25rem;">{{ $message }}</p>
                    @enderror
                </div>

                <div class="mb-4" style="margin-bottom: 1.5rem;">
                    <label for="email" style="display: block; font-weight: 700; margin-bottom: 0.5rem; color: var(--text-main);">Email Address</label>
                    <input type="email" name="email" id="email" style="width: 100%; padding: 0.75rem 1rem; border: 1px solid var(--border-color); border-radius: 8px; font-family: inherit;" value="{{ old('email', $user->email) }}" required>
                    @error('email')
                        <p style="color: #ef4444; font-size: 0.75rem; margin-top: 0.25rem;">{{ $message }}</p>
                    @enderror
                </div>

                <hr style="border: 0; border-top: 1px solid #f1f5f9; margin: 2.5rem 0;">

                <div class="mb-4" style="margin-bottom: 1.5rem;">
                    <label for="password" style="display: block; font-weight: 700; margin-bottom: 0.5rem; color: var(--text-main);">New Password</label>
                    <input type="password" name="password" id="password" style="width: 100%; padding: 0.75rem 1rem; border: 1px solid var(--border-color); border-radius: 8px; font-family: inherit;" placeholder="Leave blank to keep current">
                    @error('password')
                        <p style="color: #ef4444; font-size: 0.75rem; margin-top: 0.25rem;">{{ $message }}</p>
                    @enderror
                </div>

                <div class="mb-5" style="margin-bottom: 2rem;">
                    <label for="password_confirmation" style="display: block; font-weight: 700; margin-bottom: 0.5rem; color: var(--text-main);">Confirm New Password</label>
                    <input type="password" name="password_confirmation" id="password_confirmation" style="width: 100%; padding: 0.75rem 1rem; border: 1px solid var(--border-color); border-radius: 8px; font-family: inherit;">
                </div>

                <div style="display: flex; gap: 1rem;">
                    <button type="submit" class="btn-primary" style="flex: 1; padding: 0.875rem;">Save Changes</button>
                    <a href="{{ route('dashboard') }}" class="btn-outline" style="padding: 0.875rem 1.5rem; text-decoration: none;">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
