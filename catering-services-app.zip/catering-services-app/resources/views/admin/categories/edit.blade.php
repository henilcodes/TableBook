@extends('layouts.admin')

@section('header', 'Edit Category')

@section('content')
<div class="card" style="max-width: 600px;">
    <form action="{{ route('admin.categories.update', $category) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <div style="margin-bottom: 1.5rem;">
            <label style="display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5rem;">Category Name</label>
            <input type="text" name="name" value="{{ $category->name }}" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;" required>
        </div>

        <div style="margin-bottom: 1.5rem;">
            <label style="display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5rem;">Description</label>
            <textarea name="description" rows="4" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;">{{ $category->description }}</textarea>
        </div>

        <div style="margin-bottom: 2rem;">
            <label style="display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.5rem;">Category Image</label>
            @if($category->image)
                <div style="margin-bottom: 1rem;">
                    <img src="{{ asset('storage/' . $category->image) }}" alt="" style="width: 100px; height: 100px; border-radius: 0.5rem; object-fit: cover;">
                </div>
            @endif
            <input type="file" name="image" class="btn btn-outline" style="width: 100%; text-align: left; padding: 0.75rem;">
        </div>

        <div style="display: flex; gap: 1rem;">
            <button type="submit" class="btn btn-primary">Update Category</button>
            <a href="{{ route('admin.categories.index') }}" class="btn btn-outline">Cancel</a>
        </div>
    </form>
</div>
@endsection
