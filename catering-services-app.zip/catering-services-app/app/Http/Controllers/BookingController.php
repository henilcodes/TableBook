<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Booking;
use Illuminate\Support\Facades\Auth;

class BookingController extends Controller
{
    /**
     * Show the form for creating a new booking.
     */
    public function create()
    {
        return view('bookings.create');
    }

    /**
     * Store a newly created booking in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'full_name' => 'required|string|max:255',
            'phone' => 'required|string|max:20',
            'email' => 'required|email|max:255',
            'event_type' => 'required|string|max:100',
            'event_detail' => 'nullable|string',
            'event_start_date' => 'required|date|after_or_equal:today',
            'event_end_date' => 'required|date|after_or_equal:event_start_date',
            'start_time' => 'required',
            'end_time' => 'required',
            'venue_address' => 'required|string',
            'event_setting' => 'required|in:indoor,outdoor',
            'guest_count' => 'required|integer|min:1',
            'adults_count' => 'required|integer|min:0',
            'kids_count' => 'required|integer|min:0',
            'vips_count' => 'required|integer|min:0',
        ]);

        $validated['user_id'] = Auth::id();

        Booking::create($validated);

        return redirect()->route('dashboard')->with('success', 'Your booking request has been submitted successfully!');
    }
}
