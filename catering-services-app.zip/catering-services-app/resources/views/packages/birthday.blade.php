@extends('layouts.app')

@section('title', 'Birthday Packages')

@section('content')
<!-- Hero -->
<section class="about-hero" style="background-image: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url('https://images.unsplash.com/photo-1530103043960-ef38714abb15?q=80&w=2069&auto=format&fit=crop');">
    <div class="container text-center reveal">
        <a href="{{ url('/packages') }}" style="color: var(--gala-orange); font-weight: 700; text-decoration: none; margin-bottom: 2rem; display: inline-block;">← Back to All Categories</a>
        <h1 class="text-white mb-6">Birthday <span class="accent">Celebration Packages</span></h1>
        <p class="text-white opacity-90 max-w-2xl mx-auto text-lg">
            From playful kids' parties to sophisticated milestone galas, we have the perfect menu to make your birthday special.
        </p>
    </div>
</section>

<div class="container py-24">
    <div class="max-w-5xl mx-auto" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 2rem;">
        <!-- Basic -->
        <div class="package-column reveal">
            <div class="package-column-header tier-basic">
                <h3>Kids Party</h3>
                <span style="opacity: 0.8; font-size: 0.9rem;">Perfect for Under-12s</span>
            </div>
            <div class="package-column-features">
                <ul class="package-features">
                    <li>Mini Burgers & Fries</li>
                    <li>Fruit Punches</li>
                </ul>
                <ul class="package-features">
                    <li>Standard Cake Setup</li>
                    <li>Paper Plates/Cutlery</li>
                </ul>
            </div>
            <div class="package-column-action">
                <div class="price-tag" style="margin:0; color: var(--text-main);">Rs. 250 <span style="font-size: 0.8rem;">/plate</span></div>
                <a href="{{ route('bookings.create') }}" class="btn-secondary-sm">Book Now</a>
            </div>
        </div>

        <!-- Standard -->
        <div class="package-column reveal" style="transition-delay: 0.1s">
            <div class="package-column-header tier-standard">
                <h3>Teen Bash</h3>
                <span style="opacity: 0.8; font-size: 0.9rem;">Modern & Trendy</span>
            </div>
            <div class="package-column-features">
                <ul class="package-features">
                    <li>Italian & Chinese Starters</li>
                    <li>Mocktail Bar</li>
                </ul>
                <ul class="package-features">
                    <li>Pasta & Pizza Station</li>
                    <li>Selfie Booth Decor</li>
                </ul>
            </div>
            <div class="package-column-action">
                <div class="price-tag" style="margin:0; color: var(--text-main);">Rs. 450 <span style="font-size: 0.8rem;">/plate</span></div>
                <a href="{{ route('bookings.create') }}" class="btn-secondary-sm">Book Now</a>
            </div>
        </div>

        <!-- Premium -->
        <div class="package-column reveal" style="transition-delay: 0.2s">
            <div class="package-column-header tier-premium">
                <h3>Adult Gala</h3>
                <span style="opacity: 0.8; font-size: 0.9rem;">Sophisticated Dining</span>
            </div>
            <div class="package-column-features">
                <ul class="package-features">
                    <li>International Appetizers</li>
                    <li>Full Course Buffet</li>
                </ul>
                <ul class="package-features">
                    <li>Live BBQ Counter</li>
                    <li>Premium Ceramic Ware</li>
                </ul>
            </div>
            <div class="package-column-action">
                <div class="price-tag" style="margin:0; color: var(--text-main);">Rs. 750 <span style="font-size: 0.8rem;">/plate</span></div>
                <a href="{{ route('bookings.create') }}" class="btn-secondary-sm">Book Now</a>
            </div>
        </div>

        <!-- Luxury -->
        <div class="package-column reveal" style="transition-delay: 0.3s">
            <div class="package-column-header tier-luxury">
                <h3>Dream Milestone</h3>
                <span style="opacity: 0.8; font-size: 0.9rem;">VVIP Celebration</span>
            </div>
            <div class="package-column-features">
                <ul class="package-features">
                    <li>Exotic Global Cuinsine</li>
                    <li>Mixologist on Site</li>
                </ul>
                <ul class="package-features">
                    <li>Dessert Extravaganza</li>
                    <li>Full Theme Decor</li>
                </ul>
            </div>
            <div class="package-column-action">
                <div class="price-tag" style="margin:0; color: var(--text-main);">Rs. 1200 <span style="font-size: 0.8rem;">/plate</span></div>
                <a href="{{ route('bookings.create') }}" class="btn-secondary-sm">Book Now</a>
            </div>
        </div>
    </div>

    <!-- Comparison Section -->
    <div class="comparison-section reveal">
        <div class="text-center mb-12">
            <h2 class="text-4xl font-bold mb-4">Package <span class="accent">Comparison</span></h2>
            <p class="text-gray-600">Choose the perfect tier for your celebration needs.</p>
        </div>

        <div class="comparison-table-wrapper">
            <table class="comparison-table">
                <thead>
                    <tr>
                        <th class="feature-label">Features</th>
                        <th>Kids Party</th>
                        <th>Teen Bash</th>
                        <th>Adult Gala</th>
                        <th>Dream Milestone</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="feature-label">Cuisine Type</td>
                        <td>Kid-Friendly Classics</td>
                        <td>Indo-Chinese Fusion</td>
                        <td>Multi-Cuisine Buffet</td>
                        <td>Exotic Global Menu</td>
                    </tr>
                    <tr>
                        <td class="feature-label">Starters</td>
                        <td>2 Items</td>
                        <td>4 Items</td>
                        <td>6 Items</td>
                        <td>Unlimited</td>
                    </tr>
                    <tr>
                        <td class="feature-label">Main Course</td>
                        <td>Mini Meals</td>
                        <td>Pizza & Pasta Station</td>
                        <td>Full Course Buffet</td>
                        <td>Gourmet Experience</td>
                    </tr>
                    <tr>
                        <td class="feature-label">Drinks</td>
                        <td>Fruit Punches</td>
                        <td>Mocktail Bar</td>
                        <td>Premium Drinks</td>
                        <td>Mixologist on Site</td>
                    </tr>
                    <tr>
                        <td class="feature-label">Decor</td>
                        <td>Standard Cake Setup</td>
                        <td>Selfie Booth</td>
                        <td>Elegant Floral</td>
                        <td>Full Theme Decor</td>
                    </tr>
                    <tr>
                        <td class="feature-label">Service</td>
                        <td>Buffet Style</td>
                        <td>Interactive Stations</td>
                        <td>Fine Dining Service</td>
                        <td>VVIP Butler Service</td>
                    </tr>
                    <tr>
                        <td class="feature-label">Price per Plate</td>
                        <td class="font-bold">Rs. 250</td>
                        <td class="font-bold">Rs. 450</td>
                        <td class="font-bold">Rs. 750</td>
                        <td class="font-bold">Rs. 1200</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
