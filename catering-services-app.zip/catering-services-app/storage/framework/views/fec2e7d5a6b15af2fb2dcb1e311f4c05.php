<?php $__env->startSection('title', 'Booking Availability'); ?>

<?php $__env->startSection('content'); ?>
<section class="py-20 bg-gray-50 dark:bg-gray-900/50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center reveal">
        <h1 class="text-4xl font-extrabold tracking-tight sm:text-5xl">
            Booking <span class="text-[#f53003]">Calendar</span>
        </h1>
        <p class="mt-6 text-xl text-gray-500">Check our general availability for your next event.</p>
    </div>
</section>

<div class="py-12 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 reveal">
    <div class="bg-white dark:bg-[#161615] rounded-2xl shadow-xl p-8 border border-[#19140015] dark:border-[#3E3E3A]">
        <!-- Simple Calendar Simulation -->
        <div class="grid grid-cols-7 gap-2 text-center text-sm mb-4 font-bold uppercase tracking-wider text-gray-400">
            <span>Sun</span><span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span>
        </div>
        <div class="grid grid-cols-7 gap-2">
            <?php for($i = 1; $i <= 31; $i++): ?>
                <?php $isReserved = in_array($i, [5, 12, 18, 19, 25, 26]); ?>
                <div class="aspect-square flex items-center justify-center rounded-lg border <?php echo e($isReserved ? 'bg-red-50 text-red-500 border-red-100' : 'bg-green-50 text-green-600 border-green-100'); ?>">
                    <span class="text-lg font-bold"><?php echo e($i); ?></span>
                    <?php if($isReserved): ?>
                        <span class="absolute text-[8px] mt-8 uppercase font-black">Reserved</span>
                    <?php endif; ?>
                </div>
            <?php endfor; ?>
        </div>
        <div class="mt-8 flex justify-center gap-8 text-sm">
            <div class="flex items-center gap-2"><span class="w-4 h-4 rounded bg-green-50 border border-green-100"></span> Available</div>
            <div class="flex items-center gap-2"><span class="w-4 h-4 rounded bg-red-50 border border-red-100"></span> Fully Booked</div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\catering-services-app\resources\views/calendar.blade.php ENDPATH**/ ?>