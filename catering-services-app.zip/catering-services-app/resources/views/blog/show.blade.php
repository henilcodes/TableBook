@extends('layouts.app')

@section('title', $post->title)

@section('content')
<!-- Article Detail -->
<article class="py-24">
    <div class="container maxWidth-3xl mx-auto">
        <div class="reveal mb-12">
            <a href="{{ route('blog.index') }}" class="text-accent font-bold mb-8 display-block">← Back to Blog</a>
            <div class="flex items-center gap-4 mb-6">
                <span class="bg-accent-light text-accent px-4 py-1 rounded-full text-sm font-bold">Catering Life</span>
                <span class="text-gray-500">{{ $post->created_at->format('M d, Y') }}</span>
            </div>
            <h1 class="text-5xl font-extrabold mb-8 leading-tight">{{ $post->title }}</h1>
            <div class="flex items-center gap-4 py-6 border-b border-t border-gray-100">
                <div class="w-12 h-12 rounded-full overflow-hidden">
                    <img src="https://ui-avatars.com/api/?name={{ urlencode($post->author->name) }}&background=f05025&color=fff" alt="{{ $post->author->name }}">
                </div>
                <div>
                    <p class="font-bold">{{ $post->author->name }}</p>
                    <p class="text-gray-500 text-sm">Expert at A.V Catering</p>
                </div>
            </div>
        </div>

        @if($post->image)
            <div class="reveal mb-12 rounded-3xl overflow-hidden shadow-xl">
                <img src="{{ $post->image }}" alt="{{ $post->title }}" style="width: 100%; height: 500px; object-fit: cover;">
            </div>
        @endif

        <div class="reveal content-rich">
            {!! nl2br(e($post->content)) !!}
        </div>

        <div class="reveal mt-16 pt-12 border-t border-gray-100">
            <h3 class="text-2xl font-bold mb-8">Share this story</h3>
            <div class="flex gap-4">
                <button class="btn-secondary-sm">Twitter</button>
                <button class="btn-secondary-sm">Facebook</button>
                <button class="btn-secondary-sm">LinkedIn</button>
            </div>
        </div>
    </div>
</article>
@endsection

@push('styles')
<style>
.content-rich {
    font-size: 1.25rem;
    line-height: 1.8;
    color: #4a5568;
}
.content-rich p {
    margin-bottom: 2rem;
}
.maxWidth-3xl {
    max-width: 800px;
}
</style>
@endpush
