<?php

namespace App\Http\Controllers;

use App\Models\CustomMenuRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CustomMenuController extends Controller
{
    public function index()
    {
        $requests = CustomMenuRequest::where('user_id', Auth::id())
            ->orderBy('created_at', 'desc')
            ->get();
        return view('custom-menu.index', compact('requests'));
    }

    public function create()
    {
        return view('custom-menu.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'menu_details' => 'required|string',
            'additional_notes' => 'nullable|string',
        ]);

        CustomMenuRequest::create([
            'user_id' => Auth::id(),
            'menu_details' => $request->menu_details,
            'additional_notes' => $request->additional_notes,
            'status' => 'pending',
        ]);

        return redirect()->route('custom_menu.index')->with('success', 'Your custom menu request has been submitted successfully!');
    }
}
