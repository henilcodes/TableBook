<?php $__env->startSection('header', 'Booking Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
        <h3 style="margin: 0;">Order History</h3>
    </div>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Client</th>
                    <th>Event Date</th>
                    <th>Type</th>
                    <th>Status</th>
                    <th>Payment</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>#<?php echo e($booking->id); ?></td>
                    <td>
                        <div style="font-weight: 600;"><?php echo e($booking->full_name); ?></div>
                        <div style="font-size: 0.75rem; color: var(--text-muted);"><?php echo e($booking->phone); ?></div>
                    </td>
                    <td><?php echo e(\Carbon\Carbon::parse($booking->event_start_date)->format('M d, Y')); ?></td>
                    <td><span class="badge badge-outline" style="border: 1px solid var(--border);"><?php echo e(ucfirst($booking->event_type)); ?></span></td>
                    <td>
                        <span class="badge badge-<?php echo e($booking->status == 'confirmed' ? 'success' : ($booking->status == 'pending' ? 'warning' : 'danger')); ?>">
                            <?php echo e(ucfirst($booking->status)); ?>

                        </span>
                    </td>
                    <td>
                        <form action="<?php echo e(route('admin.bookings.update_payment', $booking)); ?>" method="POST" style="display: flex; align-items: center; gap: 0.25rem;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <select name="payment_status" onchange="this.form.submit()" style="font-size: 0.8rem; border: none; background: <?php echo e($booking->payment_status == 'fully_paid' ? '#dcfce7' : ($booking->payment_status == 'advance_paid' ? '#e0f2fe' : '#fef9c3')); ?>; color: <?php echo e($booking->payment_status == 'fully_paid' ? '#166534' : ($booking->payment_status == 'advance_paid' ? '#0369a1' : '#854d0e')); ?>; padding: 0.3rem 0.6rem; border-radius: 8px; font-weight: 700; cursor: pointer;">
                                <option value="pending" <?php echo e($booking->payment_status == 'pending' ? 'selected' : ''); ?>>PENDING</option>
                                <option value="advance_paid" <?php echo e($booking->payment_status == 'advance_paid' ? 'selected' : ''); ?>>ADVANCE PAID</option>
                                <option value="fully_paid" <?php echo e($booking->payment_status == 'fully_paid' ? 'selected' : ''); ?>>FULLY PAID</option>
                            </select>
                        </form>
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.bookings.show', $booking)); ?>" class="btn btn-outline" style="padding: 0.5rem; font-size: 0.75rem;">Details</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div style="margin-top: 1.5rem;">
        <?php echo e($bookings->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\catering-services-app\resources\views/admin/bookings/index.blade.php ENDPATH**/ ?>