<?php $__env->startSection('header', 'Payments Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="stats-grid" style="margin-bottom: 2rem;">
    <div class="card stat-card" style="border-left: 4px solid var(--primary);">
        <span class="stat-label">Total Revenue</span>
        <h3 class="stat-value">Rs. <?php echo e(number_format($stats['total_revenue'])); ?></h3>
        <p style="margin: 0; color: #64748b; font-size: 0.8125rem;">Cumulative booking value</p>
    </div>
    <div class="card stat-card" style="border-left: 4px solid var(--success);">
        <span class="stat-label">Received Amount</span>
        <h3 class="stat-value" style="color: var(--success);">Rs. <?php echo e(number_format($stats['total_received'])); ?></h3>
        <p style="margin: 0; color: var(--success); font-size: 0.8125rem; font-weight: 600;"><?php echo e(number_format(($stats['total_received'] / max($stats['total_revenue'], 1)) * 100, 1)); ?>% Secured</p>
    </div>
    <div class="card stat-card" style="border-left: 4px solid var(--gala-orange);">
        <span class="stat-label">Pending Balance</span>
        <h3 class="stat-value" style="color: var(--gala-orange);">Rs. <?php echo e(number_format($stats['total_pending'])); ?></h3>
        <p style="margin: 0; color: #64748b; font-size: 0.8125rem;">Remaining collectibles</p>
    </div>
</div>

<div class="card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
        <h3 style="margin: 0;">Invoices & Billing</h3>
        <div style="display: flex; gap: 0.5rem;">
            <button class="btn btn-outline" style="font-size: 0.875rem;">Download All Reports</button>
        </div>
    </div>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Booking</th>
                    <th>Full Quote</th>
                    <th>Paid</th>
                    <th>Remaining</th>
                    <th>Payment Status</th>
                    <th>Method</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <div style="font-weight: 700;">#<?php echo e($booking->id); ?> - <?php echo e($booking->full_name); ?></div>
                        <div style="font-size: 0.75rem; color: var(--text-muted);"><?php echo e(\Carbon\Carbon::parse($booking->event_start_date)->format('M d, Y')); ?></div>
                    </td>
                    <td style="font-weight: 600;">Rs. <?php echo e(number_format($booking->total_amount)); ?></td>
                    <td style="color: var(--success); font-weight: 600;">Rs. <?php echo e(number_format($booking->advance_amount)); ?></td>
                    <td style="color: <?php echo e(($booking->total_amount - $booking->advance_amount) > 0 ? 'var(--gala-orange)' : 'var(--success)'); ?>; font-weight: 600;">
                        Rs. <?php echo e(number_format($booking->total_amount - $booking->advance_amount)); ?>

                    </td>
                    <td>
                        <form action="<?php echo e(route('admin.bookings.update_payment', $booking)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <select name="payment_status" onchange="this.form.submit()" class="status-select" style="background: <?php echo e($booking->payment_status == 'fully_paid' ? '#dcfce7' : ($booking->payment_status == 'advance_paid' ? '#e0f2fe' : '#fef9c3')); ?>; color: <?php echo e($booking->payment_status == 'fully_paid' ? '#166534' : ($booking->payment_status == 'advance_paid' ? '#0369a1' : '#854d0e')); ?>;">
                                <option value="pending" <?php echo e($booking->payment_status == 'pending' ? 'selected' : ''); ?>>PENDING</option>
                                <option value="advance_paid" <?php echo e($booking->payment_status == 'advance_paid' ? 'selected' : ''); ?>>ADVANCE</option>
                                <option value="fully_paid" <?php echo e($booking->payment_status == 'fully_paid' ? 'selected' : ''); ?>>FULLY PAID</option>
                            </select>
                        </form>
                    </td>
                    <td>
                        <form action="<?php echo e(route('admin.bookings.update_payment', $booking)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <select name="payment_method" onchange="this.form.submit()" class="method-select">
                                <option value="none" <?php echo e($booking->payment_method == 'none' ? 'selected' : ''); ?>>NOT SET</option>
                                <option value="online" <?php echo e($booking->payment_method == 'online' ? 'selected' : ''); ?>>ONLINE</option>
                                <option value="offline" <?php echo e($booking->payment_method == 'offline' ? 'selected' : ''); ?>>OFFLINE</option>
                            </select>
                        </form>
                    </td>
                    <td>
                        <div style="display: flex; gap: 0.5rem;">
                            <a href="<?php echo e(route('admin.bookings.show', $booking)); ?>" class="btn btn-outline" style="padding: 0.4rem; font-size: 0.75rem;" title="Edit Amounts">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
                            </a>
                            <a href="<?php echo e(route('admin.bookings.receipt', $booking)); ?>" target="_blank" class="btn btn-outline" style="padding: 0.4rem; font-size: 0.75rem;" title="Invoices">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9V2h12v7"></path><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div style="margin-top: 1.5rem;">
        <?php echo e($bookings->links()); ?>

    </div>
</div>

<style>
    .status-select, .method-select {
        border: none;
        padding: 0.35rem 0.7rem;
        border-radius: 8px;
        font-size: 0.75rem;
        font-weight: 700;
        cursor: pointer;
        width: 100%;
    }
    .method-select {
        background: #f1f5f9;
        color: #475569;
    }
    .method-select:hover {
        background: #e2e8f0;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\project\catering-services-app\resources\views/admin/payments/index.blade.php ENDPATH**/ ?>